# SignBridge — Multi-Model Sign Language Recognition

SignBridge is a real-time sign language recognition application that supports multiple sign languages through TensorFlow.js models running entirely in the browser.

## Supported Languages

This enhanced version of SignBridge now supports **three sign languages**:

### 🇺🇸 American Sign Language (ASL)
- **Status:** Available
- **Alphabet:** One-handed fingerspelling (A-Z + space/del)
- **Features:** 78-feature vector (63 landmark coordinates + 15 engineered features)
- **Model:** Pre-trained and ready to use

### 🇮🇳 Indian Sign Language (ISL)
- **Status:** Available
- **Alphabet:** Two-handed fingerspelling (A-Z)
- **Features:** 126-feature vector (dual-hand landmark coordinates)
- **Model:** Pre-trained and ready to use
- **Accuracy:** 99.88% test accuracy

### 🇬🇧 British Sign Language (BSL)
- **Status:** Available
- **Alphabet:** Two-handed fingerspelling (A-G)
- **Features:** 126-feature vector (dual-hand landmark coordinates)
- **Model:** Pre-trained and ready to use
- **Accuracy:** 99.07% test accuracy

## Project Structure

```
signBridge/
├── react-app/
│   ├── public/
│   │   └── model/
│   │       ├── asl/          # ASL model files
│   │       ├── isl/          # ISL model files (NEW!)
│   │       └── bsl/          # BSL model files (NEW!)
│   ├── src/
│   │   ├── components/       # React UI components
│   │   ├── hooks/            # Custom React hooks
│   │   │   ├── useMediaPipe.js    # MediaPipe hand tracking
│   │   │   └── useSignModel.js    # TF.js model inference
│   │   ├── config/
│   │   │   └── languages.js       # Language registry
│   │   └── utils/
│   │       └── normalize.js       # Feature preprocessing pipelines
│   └── package.json
└── README.md
```

## Key Features

1. **Multi-Language Support:** Seamlessly switch between ASL, ISL, and BSL
2. **Real-Time Inference:** ~30 FPS prediction with MediaPipe hand tracking
3. **Browser-Based:** No server required — runs entirely client-side
4. **Stability Filtering:** 8-frame buffer prevents flickering predictions
5. **Two-Hand Tracking:** Supports both single-hand (ASL) and two-hand (ISL/BSL) alphabets

## Getting Started

### Prerequisites
- Node.js 18+ and npm
- A webcam for real-time detection

### Installation

```bash
cd react-app
npm install
npm run dev
```

### Usage

1. Open the app in your browser (default: http://localhost:5173)
2. Grant camera permissions when prompted
3. Select your desired sign language from the language picker
4. Position your hand(s) in the camera view
5. The app will recognize your signs in real-time

## Model Information

### ASL Model
- Input: 78 features (single hand)
- Classes: 29 (A-Z + del, nothing, space)
- Pipeline: `single-hand-78`

### ISL Model
- Input: 126 features (two hands)
- Classes: 26 (A-Z)
- Pipeline: `two-hand-126`
- Training accuracy: 99.88%

### BSL Model
- Input: 126 features (two hands)
- Classes: 7 (A-G)
- Pipeline: `two-hand-126`
- Training accuracy: 99.07%

## Architecture

The application uses the following pipeline:

1. **MediaPipe Hands** → Detects hand landmarks from webcam
2. **Feature Extraction** → Normalizes landmarks based on selected language pipeline
3. **TensorFlow.js Model** → Predicts sign letter from features
4. **Stability Buffer** → Filters predictions over 8 frames for consistency
5. **UI Display** → Shows recognized letter with confidence score

## Adding New Languages

To add a new sign language:

1. Train a TensorFlow.js model with matching feature preprocessing
2. Place model files in `public/model/<lang-id>/`
3. Add entry in `src/config/languages.js`
4. Ensure preprocessing pipeline exists in `src/utils/normalize.js`

## License

Open source — feel free to use and extend for your sign language projects!
