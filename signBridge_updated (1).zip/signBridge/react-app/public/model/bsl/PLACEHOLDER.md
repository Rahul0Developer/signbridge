# BSL (British Sign Language) model — not yet trained

Same deal as `../isl/PLACEHOLDER.md` — the registry in
`src/config/languages.js` already points here, so this activates the
moment real files land in this folder.

## Important BSL-specific note
BSL fingerspelling is two-handed for the whole alphabet (unlike ASL,
which is one-handed). That means:
1. `numHands: 2` in the language's config entry.
2. A feature pipeline that consumes landmarks for *two* hands, not
   one — `src/utils/normalize.js`'s functions assume a single 21-point
   hand. You'll need a two-hand variant (e.g. 2 × 21 × 3 = 126 raw
   values, normalized per-hand or relative to a shared origin) and a
   matching training pipeline.
3. `useMediaPipe`'s `onLandmarks` callback currently only forwards
   `multiHandLandmarks[0]` (the first detected hand) — that call site
   in `useSignModel`/screens needs to pass both hands through for any
   two-hand language.

## Good starting points for a real BSL dataset / model
- BSL Corpus (UCL) and BSL SignBank — reference dictionaries, useful
  for vocabulary/labels rather than ready-to-use classifiers.
- BslCorpus / "British Sign Language fingerspelling alphabet dataset"
  on Kaggle — several community image datasets exist for the
  two-handed BSL alphabet.
- Search GitHub for "BSL fingerspelling recognition mediapipe" for
  reference training pipelines — again, re-train against this app's
  exact feature format rather than reusing foreign weights.

Once trained, set `status: 'available'` and `numHands: 2` for the
`bsl` entry in `src/config/languages.js`.
