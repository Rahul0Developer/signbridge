# ISL (Indian Sign Language) model — not yet trained

This folder is where the ISL fingerspelling model goes once it exists.
SignBridge's language registry (`src/config/languages.js`) already
points here, so dropping in real files activates ISL app-wide — no
other code changes needed.

## Why there's nothing here yet
There is no ready-made pretrained model that "just works" with this
app's pipeline. SignBridge's ASL model was trained on a specific
78-value feature vector (63 wrist-normalized landmark coordinates +
15 hand-crafted features — see `src/utils/normalize.js`). A model
has to be trained *against that exact feature function* (or you add
a new feature function and point this language entry at it). Also
note: ISL fingerspelling is traditionally two-handed for several
letters, so `numHands` in the language config and the feature
pipeline both need updating to match whatever dataset you train on.

## What to drop in here
Export a TF.js **layers model** (Keras `model.save()` →
`tensorflowjs_converter --input_format=keras`) with:

- `model.json` + `group1-shard1of1.bin` (or however many shards)
- `label_encoder.json` — `{ "classes": [...] }` in output-index order
- `model_metadata.json` — `num_features`, `num_classes`, `class_names`,
  `input_shape` (used by the loader for sanity-checking, optional but
  recommended)

## Good starting points for a real ISL dataset / model
- INCLUDE / INCLUDE-50 (Indian Institute of Science) — ISL word-level
  video dataset, commonly used as a research baseline.
- ISL-CSLRT and other academic ISL alphabet/digit datasets on Kaggle —
  search "Indian Sign Language alphabet dataset".
- Several MediaPipe-landmark ISL fingerspelling notebooks exist on
  GitHub; they're a good reference for the training pipeline shape,
  but re-train rather than reuse their weights directly unless they
  publish the exact same 78-feature preprocessing this app uses.

Once you have a trained model, set `status: 'available'` for the
`isl` entry in `src/config/languages.js`.
