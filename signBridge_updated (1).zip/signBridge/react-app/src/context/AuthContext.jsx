// src/context/AuthContext.jsx
import { createContext, useContext, useState, useEffect } from 'react'
import {
  onAuthStateChanged,
  getRedirectResult,
  signOut,
} from 'firebase/auth'
import { auth } from '../firebase'

const AuthContext = createContext({
  user:          null,
  loading:       true,
  redirecting:   false,
  logout:        () => {},
})

export function AuthProvider({ children }) {
  const [user,        setUser]        = useState(null)
  const [loading,     setLoading]     = useState(true)
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    // Step 1: Check if we're returning from a Google redirect
    // This must run before onAuthStateChanged so we can show
    // a "redirecting" state instead of flashing the landing page
    getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          console.log('[SignBridge] Google redirect success:', result.user.email)
          // onAuthStateChanged will fire next and set the user
        }
      })
      .catch((err) => {
        console.error('[SignBridge] Redirect error:', err.code)
      })

    // Step 2: Listen for auth state changes (login, logout, token refresh)
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser ?? null)
      setLoading(false)
      setRedirecting(false)
    })

    return () => unsubscribe()
  }, [])

  const logout = async () => {
    await signOut(auth)
    setUser(null)
  }

  // Called in AuthPage just before signInWithRedirect
  // so we can show spinner instead of landing page flash
  const markRedirecting = () => setRedirecting(true)

  return (
    <AuthContext.Provider value={{ user, loading, redirecting, logout, markRedirecting }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)