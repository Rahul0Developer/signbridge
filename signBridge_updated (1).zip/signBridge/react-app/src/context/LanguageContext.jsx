// src/context/LanguageContext.jsx
// ─────────────────────────────────────────────
// Holds which sign language (ASL / ISL / BSL / ...) the whole app
// is currently using. Persists to localStorage like ThemeContext.
// Falls back to the default language if a saved id is unusable
// (e.g. localStorage had 'isl' from before it lost its model files).
// ─────────────────────────────────────────────
import { createContext, useContext, useState, useEffect } from 'react'
import { LANGUAGES, LANGUAGE_LIST, DEFAULT_LANGUAGE_ID, getLanguage, isLanguageUsable } from '../config/languages'

const LanguageContext = createContext(null)

export function LanguageProvider({ children }) {
  const [languageId, setLanguageIdState] = useState(() => {
    const saved = localStorage.getItem('sb-language')
    return saved && isLanguageUsable(saved) ? saved : DEFAULT_LANGUAGE_ID
  })

  useEffect(() => {
    localStorage.setItem('sb-language', languageId)
  }, [languageId])

  const setLanguageId = (id) => {
    if (!isLanguageUsable(id)) return  // guard: can't select a comingSoon language
    setLanguageIdState(id)
  }

  const value = {
    languageId,
    language: getLanguage(languageId),
    languages: LANGUAGE_LIST,
    setLanguageId,
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  )
}

export const useLanguage = () => useContext(LanguageContext)
