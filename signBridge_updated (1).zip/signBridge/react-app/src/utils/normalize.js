// src/utils/normalize.js
// ─────────────────────────────────────────────
// CRITICAL: This must be IDENTICAL to Python preprocessing
// If normalization differs → model gets wrong input → bad predictions
//
// Python did:
//   pts = pts - pts[0]          (subtract wrist)
//   pts = pts / max(abs(pts))   (scale to -1..1)
//
// We do exactly the same here
// ─────────────────────────────────────────────

// ── Step 1: Normalize raw 21 landmarks ──
// Input:  array of 21 objects {x, y, z} from MediaPipe
// Output: Float32Array of 63 normalized numbers
export function normalizeLandmarks(landmarks) {
  // Extract raw coordinates into a flat array
  // landmarks[0] = wrist
  const pts = landmarks.map(lm => [lm.x, lm.y, lm.z])

  // Subtract wrist position from all points
  // After this: wrist = [0, 0, 0]
  // All other points are RELATIVE to wrist
  const wrist = pts[0]
  const centered = pts.map(([x, y, z]) => [
    x - wrist[0],
    y - wrist[1],
    z - wrist[2],
  ])

  // Find max absolute value across all coordinates
  // Used for scaling
  let maxVal = 0
  for (const [x, y, z] of centered) {
    maxVal = Math.max(maxVal, Math.abs(x), Math.abs(y), Math.abs(z))
  }

  // Divide all by maxVal → range becomes -1.0 to 1.0
  const scaled = maxVal > 0
    ? centered.map(([x, y, z]) => [x/maxVal, y/maxVal, z/maxVal])
    : centered

  // Flatten (21, 3) → (63,)
  return new Float32Array(scaled.flat())
}

// ── Step 2: Add engineered features ──
// MUST match Python's add_engineered_features exactly
// Input:  Float32Array of 63 normalized values
// Output: Float32Array of 78 values (63 + 15)
export function addEngineeredFeatures(landmarks63) {
  // Reshape flat 63 values back to (21, 3)
  const pts = []
  for (let i = 0; i < 21; i++) {
    pts.push([
      landmarks63[i * 3],
      landmarks63[i * 3 + 1],
      landmarks63[i * 3 + 2],
    ])
  }

  // MediaPipe landmark indices — same as Python
  const WRIST      = 0
  const THUMB_TIP  = 4
  const INDEX_TIP  = 8
  const MIDDLE_TIP = 12
  const RING_TIP   = 16
  const PINKY_TIP  = 20
  const INDEX_MCP  = 5
  const MIDDLE_MCP = 9
  const RING_MCP   = 13
  const PINKY_MCP  = 17

  const engineered = []

  // ── Features 1-5: Fingertip heights ──
  const tips = [THUMB_TIP, INDEX_TIP, MIDDLE_TIP, RING_TIP, PINKY_TIP]
  for (const tip of tips) {
    engineered.push(pts[tip][1] - pts[WRIST][1])
  }

  // ── Features 6-9: Finger curl ──
  const curls = [
    [INDEX_TIP,  INDEX_MCP],
    [MIDDLE_TIP, MIDDLE_MCP],
    [RING_TIP,   RING_MCP],
    [PINKY_TIP,  PINKY_MCP],
  ]
  for (const [tip, base] of curls) {
    const dx = pts[tip][0] - pts[base][0]
    const dy = pts[tip][1] - pts[base][1]
    const dz = pts[tip][2] - pts[base][2]
    engineered.push(Math.sqrt(dx*dx + dy*dy + dz*dz))
  }

  // ── Feature 10: Thumb-index distance ──
  const tiDx = pts[THUMB_TIP][0] - pts[INDEX_TIP][0]
  const tiDy = pts[THUMB_TIP][1] - pts[INDEX_TIP][1]
  const tiDz = pts[THUMB_TIP][2] - pts[INDEX_TIP][2]
  engineered.push(Math.sqrt(tiDx*tiDx + tiDy*tiDy + tiDz*tiDz))

  // ── Feature 11: Hand openness ──
  let totalDist = 0
  for (const tip of tips) {
    const dx = pts[tip][0] - pts[WRIST][0]
    const dy = pts[tip][1] - pts[WRIST][1]
    const dz = pts[tip][2] - pts[WRIST][2]
    totalDist += Math.sqrt(dx*dx + dy*dy + dz*dz)
  }
  engineered.push(totalDist / tips.length)

  // ── Feature 12: Finger spread ──
  const fsDx = pts[INDEX_TIP][0] - pts[PINKY_TIP][0]
  const fsDy = pts[INDEX_TIP][1] - pts[PINKY_TIP][1]
  const fsDz = pts[INDEX_TIP][2] - pts[PINKY_TIP][2]
  engineered.push(Math.sqrt(fsDx*fsDx + fsDy*fsDy + fsDz*fsDz))

  // ── Feature 13: Thumb crossing ──
  engineered.push(pts[THUMB_TIP][0] - pts[MIDDLE_MCP][0])

  // ── Feature 14: Index-middle gap ──
  const imDx = pts[INDEX_TIP][0] - pts[MIDDLE_TIP][0]
  const imDy = pts[INDEX_TIP][1] - pts[MIDDLE_TIP][1]
  const imDz = pts[INDEX_TIP][2] - pts[MIDDLE_TIP][2]
  engineered.push(Math.sqrt(imDx*imDx + imDy*imDy + imDz*imDz))

  // ── Feature 15: Palm direction ──
  engineered.push(pts[MIDDLE_TIP][2])

  // ── Combine: 63 landmarks + 15 engineered = 78 ──
  const combined = new Float32Array(78)
  combined.set(landmarks63, 0)
  combined.set(engineered,  63)

  return combined
}

// ── Helper: euclidean distance between two 3D points ──
export function dist3d(a, b) {
  return Math.sqrt(
    Math.pow(a[0]-b[0], 2) +
    Math.pow(a[1]-b[1], 2) +
    Math.pow(a[2]-b[2], 2)
  )
}

// ─────────────────────────────────────────────
// PIPELINE REGISTRY
// ─────────────────────────────────────────────
// Each language in src/config/languages.js declares a `pipeline` id.
// useSignModel() looks it up here to know how to turn raw MediaPipe
// landmarks into the feature vector its model expects. Adding a
// language with a *different* feature shape (e.g. a two-handed
// alphabet) means adding a new entry here — not touching the ASL
// pipeline, which must stay byte-for-byte identical to what the
// existing model was trained on.
// ─────────────────────────────────────────────

// One hand, 63 landmark values + 15 engineered = 78 features.
// This is what the shipped ASL model was trained on.
function buildSingleHand78(landmarks) {
  const normalized = normalizeLandmarks(landmarks)
  return addEngineeredFeatures(normalized)
}

// Two hands, 126 raw values (2 × 63), each hand normalized to its
// own wrist independently, concatenated. No engineered features yet
// — add them here once a two-hand model + matching Python training
// pipeline exist. This is a placeholder shape for ISL/BSL, not wired
// to a trained model (see public/model/isl|bsl/PLACEHOLDER.md).
function buildTwoHand126(landmarksPerHand) {
  const [hand0, hand1] = landmarksPerHand
  const a = hand0 ? normalizeLandmarks(hand0) : new Float32Array(63)
  const b = hand1 ? normalizeLandmarks(hand1) : new Float32Array(63)
  const combined = new Float32Array(126)
  combined.set(a, 0)
  combined.set(b, 63)
  return combined
}

export const PIPELINES = {
  'single-hand-78': {
    numHands:    1,
    numFeatures: 78,
    // landmarks: single hand's 21 {x,y,z} points
    build: (landmarks) => buildSingleHand78(landmarks),
  },
  'two-hand-126': {
    numHands:    2,
    numFeatures: 126,
    // landmarksPerHand: [hand0Landmarks|null, hand1Landmarks|null]
    build: (landmarksPerHand) => buildTwoHand126(landmarksPerHand),
  },
}

export function getPipeline(pipelineId) {
  return PIPELINES[pipelineId] || PIPELINES['single-hand-78']
}