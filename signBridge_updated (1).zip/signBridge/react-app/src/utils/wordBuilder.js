// src/utils/wordBuilder.js
// ─────────────────────────────────────────────
// Converts stream of letters → words → sentences
// Handles: duplicates, spaces, timing, corrections
// ─────────────────────────────────────────────

// How long (ms) a sign must be held to register
export const SIGN_HOLD_MS = 800

// How long (ms) of "nothing" = end of letter
export const LETTER_GAP_MS = 600

// How long (ms) of "nothing" = space between words
export const WORD_GAP_MS = 2000

export class WordBuilder {
  constructor(onUpdate) {
    this.onUpdate     = onUpdate  // callback when text changes
    this.currentWord  = ''        // word being built
    this.sentence     = ''        // full sentence so far
    this.lastLetter   = null      // last accepted letter
    this.lastSignTime = null      // when last sign was detected
    this.holdStart    = null      // when current sign started
    this.holdLetter   = null      // letter being held
    this.nothingStart = null      // when "nothing" started
    this.spaceAdded   = false     // prevent double spaces
  }

  // ── Process each frame's prediction ──
  process(prediction) {
    const now = Date.now()

    if (!prediction) return

    if (prediction.isNothing || !prediction.isValid) {
      // ── No valid sign ──
      if (!this.nothingStart) {
        this.nothingStart = now
      }

      const nothingDuration = now - this.nothingStart

      // Long nothing gap = word boundary
      if (nothingDuration >= WORD_GAP_MS &&
          this.currentWord.length > 0 &&
          !this.spaceAdded) {
        this.sentence    += this.currentWord + ' '
        this.currentWord  = ''
        this.spaceAdded   = true
        this.onUpdate?.(this.getState())
      }

      // Reset hold tracking
      this.holdLetter = null
      this.holdStart  = null
      return
    }

    // ── Valid sign detected ──
    this.nothingStart = null
    this.spaceAdded   = false

    if (prediction.isSpace) {
      // Explicit space sign
      if (this.currentWord.length > 0) {
        this.sentence   += this.currentWord + ' '
        this.currentWord = ''
        this.onUpdate?.(this.getState())
      }
      return
    }

    const letter = prediction.letter

    // ── Hold detection ──
    // User must hold same sign for SIGN_HOLD_MS
    // to prevent accidental letter registration
    if (letter !== this.holdLetter) {
      // New letter started
      this.holdLetter = letter
      this.holdStart  = now
      return
    }

    // Same letter — check hold duration
    const holdDuration = now - (this.holdStart || now)

    if (holdDuration >= SIGN_HOLD_MS) {
      // Letter held long enough!

      // Don't add same letter twice in a row
      // unless user released and re-signed
      if (letter !== this.lastLetter ||
          now - (this.lastSignTime || 0) > SIGN_HOLD_MS * 2) {

        this.currentWord  += letter
        this.lastLetter    = letter
        this.lastSignTime  = now
        this.holdStart     = now // reset so same letter can be added again
        this.onUpdate?.(this.getState())
      }
    }
  }

  // ── Delete last character ──
  deleteLastChar() {
    if (this.currentWord.length > 0) {
      this.currentWord = this.currentWord.slice(0, -1)
    } else if (this.sentence.length > 0) {
      // Remove last word from sentence back to currentWord
      const words       = this.sentence.trim().split(' ')
      this.currentWord  = words.pop() || ''
      this.sentence     = words.join(' ') + (words.length ? ' ' : '')
    }
    this.onUpdate?.(this.getState())
  }

  // ── Clear everything ──
  clear() {
    this.currentWord = ''
    this.sentence    = ''
    this.lastLetter  = null
    this.holdLetter  = null
    this.holdStart   = null
    this.nothingStart = null
    this.onUpdate?.(this.getState())
  }

  // ── Get current state ──
  getState() {
    return {
      currentWord:  this.currentWord,
      sentence:     this.sentence,
      fullText:     (this.sentence + this.currentWord).trim(),
      // fullText = complete readable sentence
    }
  }
}