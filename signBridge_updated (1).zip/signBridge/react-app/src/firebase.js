import { initializeApp } from "firebase/app"
import {
  getAuth,
  GoogleAuthProvider,
  setPersistence,
  browserLocalPersistence
} from "firebase/auth"

const firebaseConfig = {
  apiKey: "AIzaSyDP2lhG3__cflfvYZlSBx327kWFfKmR4uQ",
  authDomain: "signbridge-1704a.firebaseapp.com",
  projectId: "signbridge-1704a",
  storageBucket: "signbridge-1704a.appspot.com",
  messagingSenderId: "1057481811825",
  appId: "1:1057481811825:web:18f5d2321a52664c1378d0",
  measurementId: "G-0YFZNGNHZF",
}

const app = initializeApp(firebaseConfig)

export const auth = getAuth(app)

// keep users logged in
setPersistence(auth, browserLocalPersistence)

export const googleProvider = new GoogleAuthProvider()