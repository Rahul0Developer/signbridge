// src/config/languages.js
// ─────────────────────────────────────────────
// Central registry of sign languages SignBridge can recognise.
// Add a new language by adding an entry here — every screen that
// uses useSignModel() / LanguageSelector picks it up automatically.
//
// status:
//   'available'  → model files exist in public/model/<id>/, selectable
//   'comingSoon' → shown in the picker but disabled (no trained model yet)
// ─────────────────────────────────────────────

export const LANGUAGES = {
  asl: {
    id:          'asl',
    name:        'American Sign Language',
    shortName:   'ASL',
    flag:        '🇺🇸',
    status:      'available',
    modelDir:    '/model/asl',
    numHands:    1,
    // Which feature pipeline this model was trained against —
    // see src/utils/normalize.js. One-hand models use 'single-hand-78'.
    pipeline:    'single-hand-78',
    description: 'One-handed fingerspelling alphabet, A–Z + space/del.',
  },
  isl: {
    id:          'isl',
    name:        'Indian Sign Language',
    shortName:   'ISL',
    flag:        '🇮🇳',
    status:      'comingSoon',
    modelDir:    '/model/isl',
    numHands:    2,
    pipeline:    'two-hand-126',
    description: 'Two-handed fingerspelling — model not trained yet. See public/model/isl/PLACEHOLDER.md',
  },
  bsl: {
    id:          'bsl',
    name:        'British Sign Language',
    shortName:   'BSL',
    flag:        '🇬🇧',
    status:      'comingSoon',
    modelDir:    '/model/bsl',
    numHands:    2,
    pipeline:    'two-hand-126',
    description: 'Two-handed fingerspelling — model not trained yet. See public/model/bsl/PLACEHOLDER.md',
  },
}

export const LANGUAGE_LIST = Object.values(LANGUAGES)

export const DEFAULT_LANGUAGE_ID = 'asl'

export function getLanguage(id) {
  return LANGUAGES[id] || LANGUAGES[DEFAULT_LANGUAGE_ID]
}

export function isLanguageUsable(id) {
  return LANGUAGES[id]?.status === 'available'
}
