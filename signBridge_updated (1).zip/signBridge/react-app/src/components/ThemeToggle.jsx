// src/components/ThemeToggle.jsx
import { useTheme } from '../context/ThemeContext'

export default function ThemeToggle() {
  const { isDark, toggleTheme } = useTheme()

  return (
    <button
      onClick={toggleTheme}
      title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
      className="relative w-14 h-7 rounded-full transition-all duration-300
                 flex items-center px-1 flex-shrink-0"
      style={{
        background: isDark
          ? 'linear-gradient(135deg, #1C1C1E, #2C2C2E)'
          : 'linear-gradient(135deg, #E0F0FF, #BAE0FF)',
        border: `1px solid ${isDark ? '#38383A' : '#93C5FD'}`,
        boxShadow: isDark
          ? 'inset 0 1px 3px rgba(0,0,0,0.4)'
          : 'inset 0 1px 3px rgba(0,0,0,0.08)',
      }}
    >
      {/* Track icons */}
      <span className="absolute left-1.5 text-xs" style={{ opacity: isDark ? 0.3 : 0.8 }}>☀️</span>
      <span className="absolute right-1.5 text-xs" style={{ opacity: isDark ? 0.8 : 0.3 }}>🌙</span>

      {/* Thumb */}
      <div
        className="w-5 h-5 rounded-full shadow-md transition-all duration-300
                   flex items-center justify-center text-xs z-10"
        style={{
          transform:  isDark ? 'translateX(28px)' : 'translateX(0)',
          background: isDark
            ? 'linear-gradient(135deg, #48484A, #636366)'
            : 'linear-gradient(135deg, #ffffff, #F0F8FF)',
          boxShadow: isDark
            ? '0 1px 4px rgba(0,0,0,0.5)'
            : '0 1px 4px rgba(0,0,0,0.15)',
        }}
      />
    </button>
  )
}