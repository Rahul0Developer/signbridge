// src/components/ToastContainer.jsx

export default function ToastContainer({ toasts, onDismiss }) {
  if (!toasts?.length) return null

  const icons = {
    success: '✓',
    error:   '✕',
    warning: '⚠',
    info:    'ℹ',
  }

  const colors = {
    success: { bg: '#30D15820', border: '#30D15850', text: '#30D158', icon: '#30D158' },
    error:   { bg: '#FF453A20', border: '#FF453A50', text: '#FF453A', icon: '#FF453A' },
    warning: { bg: '#FF9F0A20', border: '#FF9F0A50', text: '#FF9F0A', icon: '#FF9F0A' },
    info:    { bg: '#0A84FF20', border: '#0A84FF50', text: '#F2F2F7', icon: '#0A84FF' },
  }

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[100]
                    flex flex-col items-center gap-2 pointer-events-none"
         style={{ minWidth: '280px' }}>
      {toasts.map(toast => {
        const c = colors[toast.type] || colors.info
        return (
          <div
            key={toast.id}
            className="pointer-events-auto flex items-center gap-3
                       px-4 py-3 rounded-2xl shadow-2xl
                       animate-slide-up cursor-pointer"
            style={{
              background:   c.bg,
              border:       `1px solid ${c.border}`,
              backdropFilter: 'blur(12px)',
              minWidth: '260px',
            }}
            onClick={() => onDismiss(toast.id)}
          >
            {/* Icon */}
            <div className="w-6 h-6 rounded-full flex items-center justify-center
                            text-xs font-bold flex-shrink-0"
                 style={{ background: `${c.icon}25`, color: c.icon }}>
              {icons[toast.type] || 'ℹ'}
            </div>

            {/* Message */}
            <p className="text-sm flex-1" style={{ color: c.text }}>
              {toast.message}
            </p>

            {/* Dismiss */}
            <span className="text-xs opacity-50 hover:opacity-100 transition-opacity">
              ✕
            </span>
          </div>
        )
      })}
    </div>
  )
}