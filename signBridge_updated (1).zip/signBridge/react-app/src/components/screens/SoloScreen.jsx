// src/components/screens/SoloScreen.jsx
import { useState, useEffect, useRef, useCallback } from 'react'
import { useCamera }    from '../../hooks/useCamera'
import { useMediaPipe } from '../../hooks/useMediaPipe'
import { useSignModel } from '../../hooks/useSignModel'
import { useLanguage }  from '../../context/LanguageContext'
import LanguageSelector from '../LanguageSelector'
import { useSpeech }    from '../../hooks/useSpeech'
import { WordBuilder }  from '../../utils/wordBuilder'
import SignDisplay      from '../SignDisplay'
import ThemeToggle      from '../ThemeToggle'
import { useTheme }     from '../../context/ThemeContext'

export default function SoloScreen({ role, onGoHome }) {
  const { isDark } = useTheme()
  const camera    = useCamera()
  const { languageId } = useLanguage()
  const signModel = useSignModel(languageId)
  const speech    = useSpeech()

  const [messages,       setMessages]       = useState([])
  const [currentWord,    setCurrentWord]    = useState('')
  const [currentSent,    setCurrentSent]    = useState('')
  const [isSigning,      setIsSigning]      = useState(false)
  const [detectedLetter, setDetectedLetter] = useState(null)
  const [landmarks,      setLandmarks]      = useState(null)
  const [isListening,    setIsListening]    = useState(false)
  const [showTopPreds,   setShowTopPreds]   = useState(false)
  const [lastSpokenText, setLastSpokenText] = useState('')

  const wordBuilderRef = useRef(null)
  const canvasRef      = useRef(null)
  const chatBottomRef  = useRef(null)
  const signingRef     = useRef(false)

  useEffect(() => {
    wordBuilderRef.current = new WordBuilder((state) => {
      setCurrentWord(state.currentWord)
      setCurrentSent(state.sentence)
    })
  }, [])

  useEffect(() => { signModel.loadModel() }, [])

  const handleLandmarks = useCallback((lms) => {
    setLandmarks(lms)
    drawLandmarks(lms)
    if (!signingRef.current || !signModel.isLoaded) return
    const result = signModel.predict(lms)
    if (!result) return
    setDetectedLetter({
      letter:     result.letter,
      confidence: result.confidence,
      isValid:    result.isValid,
      isNothing:  result.isNothing,
    })
    if (wordBuilderRef.current) wordBuilderRef.current.process(result)
    if (result.isDel && result.isStable) wordBuilderRef.current?.deleteLastChar()
  }, [signModel.isLoaded, signModel.predict])

  const handleNoHand = useCallback(() => {
    setLandmarks(null)
    setDetectedLetter(null)
    clearCanvas()
    wordBuilderRef.current?.process({ isNothing: true, isValid: false })
  }, [])

  const mediapipe = useMediaPipe({ onLandmarks: handleLandmarks, onNoHand: handleNoHand, numHands: signModel.numHands || 1 })

  const startEverything = useCallback(async () => {
    await Promise.all([camera.startCamera(), mediapipe.loadMediaPipe()])
  }, [camera.startCamera, mediapipe.loadMediaPipe])

  useEffect(() => { startEverything() }, [])

  useEffect(() => {
    if (camera.isActive && mediapipe.isLoaded && camera.videoRef.current)
      mediapipe.startDetection(camera.videoRef.current)
  }, [camera.isActive, mediapipe.isLoaded])

  useEffect(() => () => { camera.cleanup(); mediapipe.stopDetection() }, [])

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Draws one hand's 21-point skeleton onto an already-sized canvas.
  // Extracted so multi-hand languages (ISL/BSL) can call it once per
  // detected hand — single-hand languages (ASL) still draw exactly
  // the same pixels as before via the one-hand branch below.
  const drawHandSkeleton = (ctx, hand, W, H) => {
    const connections = [
      [0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],
      [0,9],[9,10],[10,11],[11,12],[0,13],[13,14],[14,15],[15,16],
      [0,17],[17,18],[18,19],[19,20],[5,9],[9,13],[13,17],
    ]
    ctx.strokeStyle = '#0A84FF88'; ctx.lineWidth = 2
    for (const [a, b] of connections) {
      ctx.beginPath()
      ctx.moveTo((1-hand[a].x)*W, hand[a].y*H)
      ctx.lineTo((1-hand[b].x)*W, hand[b].y*H)
      ctx.stroke()
    }
    for (let i = 0; i < hand.length; i++) {
      const isTip = [4,8,12,16,20].includes(i)
      ctx.fillStyle = isTip ? '#0A84FF' : '#0A84FF88'
      ctx.beginPath()
      ctx.arc((1-hand[i].x)*W, hand[i].y*H, isTip ? 5 : 3, 0, Math.PI*2)
      ctx.fill()
    }
  }

  const drawLandmarks = (lms) => {
    const canvas = canvasRef.current
    const video  = camera.videoRef.current
    if (!canvas || !video || !lms) return
    const ctx = canvas.getContext('2d')
    canvas.width  = video.videoWidth  || 640
    canvas.height = video.videoHeight || 480
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    const W = canvas.width, H = canvas.height

    // Two-hand languages (numHands > 1) receive an array of hands from
    // useMediaPipe; single-hand languages (ASL) receive one hand's
    // 21-point array directly — same shape/behavior as before.
    if (signModel.numHands > 1 && Array.isArray(lms[0])) {
      for (const hand of lms) {
        if (hand) drawHandSkeleton(ctx, hand, W, H)
      }
    } else {
      drawHandSkeleton(ctx, lms, W, H)
    }
  }

  const clearCanvas = () => {
    const c = canvasRef.current
    if (c) c.getContext('2d')?.clearRect(0, 0, c.width, c.height)
  }

  const toggleSigning = () => {
    const next = !isSigning
    setIsSigning(next)
    signingRef.current = next
    if (!next) {
      const state = wordBuilderRef.current?.getState()
      if (state?.fullText) sendMessage()
    }
  }

  const sendMessage = () => {
    const state = wordBuilderRef.current?.getState()
    const text  = state?.fullText?.trim()
    if (!text) return
    setMessages(prev => [...prev, {
      id: Date.now(), role: 'deaf', text,
      timestamp: new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
    }])
    speech.speak(text)
    wordBuilderRef.current?.clear()
    setCurrentWord(''); setCurrentSent('')
    signModel.resetBuffer()
  }

  const toggleListening = () => {
    if (isListening) {
      speech.stopListening()
      setIsListening(false)
      const text = speech.transcript?.trim()
      if (text) {
        setMessages(prev => [...prev, {
          id: Date.now(), role: 'hearing', text,
          timestamp: new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
        }])
        setLastSpokenText(text)
        speech.clearTranscript()
      }
    } else {
      speech.startListening()
      setIsListening(true)
    }
  }

  const confColor = (c) => c >= 0.9 ? '#30D158' : c >= 0.7 ? '#FF9F0A' : '#FF453A'
  const isReady   = camera.isActive && mediapipe.isLoaded && signModel.isLoaded

  // ── Theme-aware style helpers ──
  const headerBg    = isDark ? 'rgba(28,28,30,0.95)'  : 'rgba(255,255,255,0.95)'
  const panelBg     = isDark ? 'rgba(28,28,30,0.98)'  : 'rgba(248,250,255,0.98)'
  const controlBg   = isDark ? 'rgba(28,28,30,0.98)'  : 'rgba(255,255,255,0.98)'
  const signBtnIdle = isDark ? '#2C2C2E'               : '#F3F4F6'
  const signBtnText = isDark ? '#F2F2F7'               : '#374151'

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden"
         style={{ background: 'var(--bg-primary)', transition: 'background 0.3s ease' }}>

      {/* ── HEADER ── */}
      <header className="flex items-center justify-between px-4 py-3
                         border-b flex-shrink-0"
              style={{ background: headerBg, borderColor: 'var(--header-border)',
                       backdropFilter: 'blur(12px)' }}>
        <div className="flex items-center gap-3">
          <button
            onClick={onGoHome}
            className="w-10 h-10 rounded-full flex items-center justify-center
                       transition-all hover:scale-110 active:scale-95 text-lg font-bold"
            style={{ background: isDark ? 'rgba(99,99,102,0.2)' : 'rgba(0,0,0,0.06)',
                     color: 'var(--text-primary)',
                     border: `1px solid ${isDark ? 'rgba(99,99,102,0.3)' : 'rgba(0,0,0,0.1)'}` }}
          >
            ←
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xl">{role === 'deaf' ? '🤟' : '🎤'}</span>
            <div>
              <h1 className="font-semibold text-sm leading-none"
                  style={{ color: 'var(--text-primary)' }}>
                {role === 'deaf' ? 'Deaf Mode' : 'Hearing Mode'}
              </h1>
              <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>In-Person</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {[
            { label: 'AI',  active: signModel.isLoaded },
            { label: 'CAM', active: camera.isActive    },
            { label: 'MP',  active: mediapipe.isLoaded },
          ].map(({ label, active }) => (
            <div key={label}
                 className="flex items-center gap-1.5 px-2 py-1 rounded-full text-xs"
                 style={{ background: 'var(--pill-bg)', border: '1px solid var(--pill-border)' }}>
              <div className={active
                ? 'w-2 h-2 rounded-full bg-[#30D158]'
                : 'w-2 h-2 rounded-full bg-[#FF9F0A] animate-pulse'} />
              <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
            </div>
          ))}

          <button
            onClick={() => setMessages([])}
            className="w-10 h-10 rounded-full flex items-center justify-center
                       transition-all hover:scale-110 active:scale-95 text-base"
            style={{ background: 'rgba(255,69,58,0.15)', color: '#FF453A',
                     border: '1px solid rgba(255,69,58,0.3)' }}
            title="Clear chat"
          >
            🗑
          </button>

          <LanguageSelector />
          <ThemeToggle />
        </div>
      </header>

      {/* ── LOADING OVERLAY ── */}
      {!isReady && (
        <div className="absolute inset-0 z-50 flex items-center justify-center
                        backdrop-blur-sm"
             style={{ top: '57px', background: isDark ? 'rgba(10,10,12,0.95)' : 'rgba(255,255,255,0.95)' }}>
          <div className="text-center space-y-4 p-8">
            <div className="text-5xl animate-bounce-subtle">🤟</div>
            <h2 className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>
              Getting Ready...
            </h2>
            <div className="space-y-2 text-left">
              {[
                { label: 'Camera',        done: camera.isActive,    loading: camera.isLoading    },
                { label: 'Hand Detector', done: mediapipe.isLoaded, loading: !mediapipe.isLoaded },
                { label: 'AI Model',      done: signModel.isLoaded, loading: signModel.isLoading },
              ].map(({ label, done, loading }) => (
                <div key={label}
                     className="flex items-center gap-3 px-4 py-2 rounded-xl"
                     style={{ background: 'var(--bg-secondary)',
                              border: '1px solid var(--border)' }}>
                  <div className="w-5 h-5 flex items-center justify-center">
                    {done
                      ? <span className="text-[#30D158] text-sm">✓</span>
                      : loading
                      ? <div className="w-3 h-3 border-2 border-[#0A84FF]
                                        border-t-transparent rounded-full animate-spin" />
                      : <div className="w-2 h-2 rounded-full"
                             style={{ background: 'var(--text-muted)' }} />
                    }
                  </div>
                  <span className="text-sm"
                        style={{ color: done ? 'var(--text-primary)' : 'var(--text-muted)' }}>
                    {label}
                  </span>
                  {done && <span className="text-[#30D158] text-xs ml-auto">Ready</span>}
                </div>
              ))}
            </div>
            {camera.error && (
              <div className="mt-4 space-y-2">
                <p className="text-[#FF453A] text-sm">{camera.error}</p>
                <button onClick={startEverything}
                        className="px-5 py-2 rounded-xl text-white text-sm font-semibold"
                        style={{ background: '#0A84FF' }}>
                  Retry
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── MAIN ── */}
      <div className="flex-1 flex overflow-hidden">

        {/* LEFT: Camera */}
        <div className="w-[45%] flex flex-col flex-shrink-0"
             style={{ borderRight: '1px solid var(--border)',
                      background: isDark ? '#000' : '#1a1a1a' }}>

          {/* Video */}
          <div className={`relative overflow-hidden transition-all duration-300
            ${role === 'hearing' && lastSpokenText ? 'h-36 flex-shrink-0' : 'flex-1'}`}>
            <video ref={camera.videoRef}
                   className="w-full h-full object-cover"
                   playsInline muted
                   style={{ transform: 'scaleX(-1)' }} />
            <canvas ref={canvasRef}
                    className="absolute inset-0 w-full h-full pointer-events-none" />

            {isSigning && (
              <div className="absolute top-3 left-3 flex items-center gap-2
                              px-3 py-1.5 rounded-full bg-black/70
                              border border-[#0A84FF]/50 animate-fade-in">
                <div className="w-2 h-2 rounded-full bg-[#30D158] animate-pulse" />
                <span className="text-white text-xs font-medium">Detecting...</span>
              </div>
            )}

            {isSigning && !landmarks && camera.isActive && (
              <div className="absolute top-3 right-3 px-3 py-1.5 rounded-full
                              bg-black/70 border border-[#FF9F0A]/50">
                <span className="text-[#FF9F0A] text-xs">✋ Show hand</span>
              </div>
            )}
          </div>

          {/* SignDisplay — hearing mode */}
          {role === 'hearing' && lastSpokenText && (
            <div className="flex-1 overflow-y-auto p-3"
                 style={{ background: isDark ? 'rgba(18,18,20,0.98)' : 'rgba(248,250,255,0.98)' }}>
              <SignDisplay text={lastSpokenText} autoPlay={true} />
            </div>
          )}

          {/* Detection badge — deaf mode */}
          {role === 'deaf' && (
            <div className="flex-shrink-0 p-3 space-y-2"
                 style={{ background: panelBg, borderTop: '1px solid var(--border)' }}>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl flex items-center
                                  justify-center text-3xl font-bold border-2
                                  transition-all duration-150"
                       style={{
                         background:  detectedLetter?.isValid ? '#0A84FF15' : 'var(--bg-tertiary)',
                         borderColor: detectedLetter?.isValid ? '#0A84FF'   : 'var(--border)',
                         color:       detectedLetter?.isValid ? '#0A84FF'   : 'var(--text-muted)',
                         transform:   detectedLetter?.isValid ? 'scale(1.05)' : 'scale(1)',
                       }}>
                    {!detectedLetter || detectedLetter.isNothing ? '—' : detectedLetter.letter}
                  </div>

                  <div className="space-y-1">
                    <p className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>
                      {detectedLetter?.isValid   ? 'Detected'
                       : detectedLetter?.isNothing ? 'No sign'
                       : isSigning ? 'Waiting...' : 'Inactive'}
                    </p>
                    {detectedLetter && !detectedLetter.isNothing && (
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-20 rounded-full overflow-hidden"
                             style={{ background: 'var(--confidence-bg)' }}>
                          <div className="h-full rounded-full transition-all duration-150"
                               style={{ width: `${detectedLetter.confidence*100}%`,
                                        background: confColor(detectedLetter.confidence) }} />
                        </div>
                        <span className="text-xs font-mono"
                              style={{ color: confColor(detectedLetter.confidence) }}>
                          {(detectedLetter.confidence*100).toFixed(0)}%
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => setShowTopPreds(!showTopPreds)}
                  className="text-xs px-2 py-1 rounded-lg transition-colors"
                  style={{ color: 'var(--text-muted)',
                           background: showTopPreds ? 'var(--bg-tertiary)' : 'transparent' }}
                >
                  {showTopPreds ? 'Hide' : 'Top 3'}
                </button>
              </div>

              {showTopPreds && signModel.prediction?.allProbs && (
                <div className="flex gap-2">
                  {signModel.prediction.allProbs.slice(0, 3).map(({ letter, prob }) => (
                    <div key={letter}
                         className="flex-1 rounded-xl p-2 text-center"
                         style={{ background: 'var(--bg-tertiary)',
                                  border: '1px solid var(--border)' }}>
                      <p className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>
                        {letter}
                      </p>
                      <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                        {(prob*100).toFixed(0)}%
                      </p>
                    </div>
                  ))}
                </div>
              )}

              <div className="rounded-xl px-3 py-2 min-h-[36px] flex items-center gap-2"
                   style={{ background: 'var(--bg-tertiary)',
                            border: '1px solid var(--border)' }}>
                <span className="text-xs flex-shrink-0" style={{ color: 'var(--text-muted)' }}>
                  Building:
                </span>
                <span className="text-sm font-mono font-semibold tracking-widest
                                 flex-1 overflow-hidden">
                  <span style={{ color: 'var(--text-secondary)' }}>{currentSent}</span>
                  <span style={{ color: '#0A84FF' }}>{currentWord}</span>
                  {isSigning && <span className="animate-pulse" style={{ color: '#0A84FF' }}>|</span>}
                </span>
                {(currentWord || currentSent) && (
                  <button onClick={() => wordBuilderRef.current?.deleteLastChar()}
                          className="text-xs flex-shrink-0 transition-colors
                                     hover:text-[#FF453A]"
                          style={{ color: 'var(--text-muted)' }}>
                    ⌫
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* RIGHT: Chat */}
        <div className="flex-1 flex flex-col overflow-hidden">

          <div className="px-4 py-2.5 border-b flex items-center
                          justify-between flex-shrink-0"
               style={{ background: panelBg, borderColor: 'var(--border)' }}>
            <div className="flex items-center gap-2">
              <span className="text-base">💬</span>
              <span className="font-medium text-sm" style={{ color: 'var(--text-primary)' }}>
                Conversation
              </span>
            </div>
            <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
              {messages.length} messages
            </span>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center
                              justify-center gap-3 text-center py-16">
                <div className="text-5xl opacity-20">💬</div>
                <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                  No messages yet
                </p>
                <p className="text-xs max-w-[180px] leading-relaxed"
                   style={{ color: 'var(--text-muted)' }}>
                  {role === 'deaf'
                    ? 'Press Start Signing, hold a sign until the letter appears, then Send'
                    : 'Press the mic button and speak your message'}
                </p>
              </div>
            )}

            {messages.map(msg => (
              <div key={msg.id}
                   className={`flex flex-col gap-1
                     ${msg.role === 'hearing' ? 'items-end' : 'items-start'}`}>
                <div className="flex items-center gap-1.5 px-1">
                  <span className="text-xs">
                    {msg.role === 'deaf' ? '🤟' : '🎤'}
                  </span>
                  <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                    {msg.role === 'deaf' ? 'Signed' : 'Spoken'}
                  </span>
                </div>

                <div className="px-3 py-2 rounded-2xl text-sm max-w-[85%]"
                     style={msg.role === 'deaf'
                       ? { background: 'var(--bubble-deaf-bg)',
                           border: '1px solid var(--bubble-deaf-border)',
                           color: 'var(--bubble-deaf-text)' }
                       : { background: 'var(--bubble-hearing-bg)',
                           border: '1px solid var(--bubble-hearing-border)',
                           color: 'var(--bubble-hearing-text)' }
                     }>
                  <p className="leading-relaxed">{msg.text}</p>
                </div>

                {msg.role === 'hearing' && (
                  <button
                    onClick={() => setLastSpokenText(msg.text)}
                    className="text-xs transition-colors px-1 flex items-center gap-1
                               hover:text-[#0A84FF]"
                    style={{ color: 'var(--text-muted)' }}
                  >
                    🤟 Show signs again
                  </button>
                )}
                <span className="text-xs px-1" style={{ color: 'var(--text-muted)' }}>
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {isListening && speech.interim && (
              <div className="flex flex-col items-end gap-1">
                <div className="px-3 py-2 rounded-2xl text-sm opacity-60 italic"
                     style={{ background: 'var(--bubble-hearing-bg)',
                              border: '1px solid var(--bubble-hearing-border)',
                              color: 'var(--bubble-hearing-text)' }}>
                  <p>{speech.interim}...</p>
                </div>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>
        </div>
      </div>

      {/* ── CONTROL BAR ── */}
      <div className="flex-shrink-0 border-t px-4 py-3 flex items-center gap-3"
           style={{ background: controlBg, borderColor: 'var(--border)' }}>

        {role === 'deaf' && (
          <>
            <button
              onClick={toggleSigning}
              disabled={!isReady}
              className="flex items-center gap-2 px-5 py-2.5 rounded-2xl
                         font-semibold text-sm transition-all duration-200
                         hover:scale-105 active:scale-95
                         disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: isSigning
                  ? 'linear-gradient(135deg,#0A84FF,#0066CC)'
                  : signBtnIdle,
                color: isSigning ? '#ffffff' : signBtnText,
                boxShadow: isSigning ? '0 0 20px #0A84FF44' : 'none',
              }}
            >
              <span>{isSigning ? '⏹' : '🤟'}</span>
              <span>{isSigning ? 'Stop' : 'Start Signing'}</span>
              {isSigning && <div className="w-2 h-2 rounded-full bg-white animate-pulse" />}
            </button>

            <button
              onClick={sendMessage}
              disabled={!currentWord && !currentSent}
              className="w-11 h-11 rounded-full flex items-center justify-center
                         text-white text-lg transition-all
                         hover:scale-110 active:scale-95
                         disabled:opacity-40 disabled:cursor-not-allowed"
              style={{ background: 'linear-gradient(135deg,#0A84FF,#0066CC)',
                       boxShadow: '0 4px 12px #0A84FF44' }}
            >
              ↑
            </button>
          </>
        )}

        {role === 'hearing' && (
          <button
            onClick={toggleListening}
            disabled={!speech.supported.stt}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl
                       font-semibold text-sm transition-all duration-200
                       hover:scale-105 active:scale-95
                       disabled:opacity-40 disabled:cursor-not-allowed"
            style={{
              background: isListening
                ? 'linear-gradient(135deg,#30D158,#25A244)'
                : signBtnIdle,
              color: isListening ? '#ffffff' : signBtnText,
              boxShadow: isListening ? '0 0 20px #30D15844' : 'none',
            }}
          >
            {isListening ? (
              <>
                <div className="flex items-end gap-0.5 h-4">
                  {[1,2,3,2,1].map((_,i) => (
                    <div key={i} className="w-0.5 bg-white rounded-full animate-bounce"
                         style={{ height:`${6+i*3}px`, animationDelay:`${i*0.1}s` }} />
                  ))}
                </div>
                <span>Listening...</span>
              </>
            ) : (
              <><span>🎤</span><span>Speak</span></>
            )}
          </button>
        )}

        <div className="flex-1" />

        <button
          onClick={onGoHome}
          className="text-xs px-2 py-1 rounded-lg transition-colors"
          style={{ color: 'var(--text-muted)' }}
        >
          Switch role
        </button>
      </div>
    </div>
  )
}