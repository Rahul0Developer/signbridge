// src/components/screens/PracticeScreen.jsx
// ─────────────────────────────────────────────
// Small Duolingo-style learning mode:
//   1. Lesson map — a path of bite-sized units, locked in order
//   2. Lesson runner — one sign at a time, live webcam quiz using
//      the SAME model/camera/mediapipe hooks as Solo mode
//   3. Summary — XP earned + streak, back to the map
//
// Reuses useCamera / useMediaPipe / useSignModel exactly like
// SoloScreen so behavior (thresholds, stability, normalization)
// is identical to the rest of the app — this is a new UI on top of
// the same recognition pipeline, not a separate one.
// ─────────────────────────────────────────────
import { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import { useCamera }    from '../../hooks/useCamera'
import { useMediaPipe }  from '../../hooks/useMediaPipe'
import { useSignModel }  from '../../hooks/useSignModel'
import { useLanguage }   from '../../context/LanguageContext'
import { HandSVG }       from '../SignDisplay'
import LanguageSelector  from '../LanguageSelector'
import ThemeToggle       from '../ThemeToggle'
import { getLessons, loadProgress, completeUnit } from '../../data/lessons'
import { isLanguageUsable } from '../../config/languages'

const XP_PER_SIGN = 10
const HOLD_MS_TO_PASS = 700 // how long a correct, stable sign must be held

export default function PracticeScreen({ onGoHome }) {
  const { language, languageId } = useLanguage()

  const [view, setView]           = useState('map') // 'map' | 'lesson' | 'summary'
  const [activeUnit, setActiveUnit] = useState(null)
  const [progress, setProgress]   = useState(() => loadProgress(languageId))
  const [sessionXp, setSessionXp] = useState(0)

  useEffect(() => { setProgress(loadProgress(languageId)) }, [languageId])

  const lessons = useMemo(() => getLessons(languageId), [languageId])
  const usable  = isLanguageUsable(languageId)

  const startUnit = (unit) => { setActiveUnit(unit); setSessionXp(0); setView('lesson') }

  const finishUnit = () => {
    const updated = completeUnit(languageId, activeUnit.id, sessionXp)
    setProgress(updated)
    setView('summary')
  }

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden"
         style={{ background: 'var(--bg-primary)' }}>

      {/* ── HEADER ── */}
      <header className="flex items-center justify-between px-5 py-3 border-b flex-shrink-0"
              style={{ background: 'var(--header-bg)', borderColor: 'var(--header-border)', backdropFilter: 'blur(12px)' }}>
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => view === 'lesson' ? setView('map') : onGoHome()}
            className="w-9 h-9 rounded-full flex items-center justify-center transition-all hover:scale-110"
            style={{ background: 'var(--pill-bg)', color: 'var(--text-secondary)' }}
          >←</button>
          <div>
            <h1 className="font-bold text-base leading-none" style={{ color: 'var(--text-primary)' }}>
              🎓 Learn {language.shortName}
            </h1>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
              {view === 'lesson' ? activeUnit?.title : 'Bite-sized signing lessons'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* XP + streak pills */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border"
               style={{ background: 'var(--pill-bg)', borderColor: 'var(--pill-border)' }}>
            <span className="text-xs">⚡</span>
            <span className="text-xs font-semibold" style={{ color: 'var(--text-secondary)' }}>
              {progress.xp || 0} XP
            </span>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border"
               style={{ background: 'var(--pill-bg)', borderColor: 'var(--pill-border)' }}>
            <span className="text-xs">🔥</span>
            <span className="text-xs font-semibold" style={{ color: 'var(--text-secondary)' }}>
              {progress.streak || 0}
            </span>
          </div>
          <LanguageSelector />
          <ThemeToggle />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        {!usable && <NotAvailableState language={language} />}

        {usable && view === 'map' && (
          <LessonMap lessons={lessons} progress={progress} onStart={startUnit} />
        )}

        {usable && view === 'lesson' && activeUnit && (
          <LessonRunner
            key={activeUnit.id + languageId}
            unit={activeUnit}
            languageId={languageId}
            onXpEarned={(xp) => setSessionXp(prev => prev + xp)}
            onDone={finishUnit}
            onExit={() => setView('map')}
          />
        )}

        {usable && view === 'summary' && (
          <SummaryScreen unit={activeUnit} sessionXp={sessionXp} onContinue={() => setView('map')} />
        )}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────
// Not-available state — language picked has no trained model
// ─────────────────────────────────────────────
function NotAvailableState({ language }) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 text-center gap-3">
      <div className="text-5xl">🚧</div>
      <h2 className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>
        {language.name} lessons aren't ready yet
      </h2>
      <p className="text-sm max-w-xs" style={{ color: 'var(--text-secondary)' }}>
        There's no trained recognition model for {language.shortName} yet. Switch to ASL from the
        picker above to start practicing now.
      </p>
    </div>
  )
}

// ─────────────────────────────────────────────
// Lesson map — path of unit cards, locked in order
// ─────────────────────────────────────────────
function LessonMap({ lessons, progress, onStart }) {
  if (lessons.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full px-6 text-center gap-2">
        <div className="text-4xl">📭</div>
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>No lessons for this language yet.</p>
      </div>
    )
  }

  return (
    <div className="px-5 py-6 max-w-sm mx-auto space-y-3">
      {lessons.map((unit, i) => {
        const isDone   = progress.completedUnits?.includes(unit.id)
        const isLocked = i > 0 && !progress.completedUnits?.includes(lessons[i - 1].id)
        return (
          <button
            key={unit.id}
            disabled={isLocked}
            onClick={() => onStart(unit)}
            className="w-full flex items-center gap-3 p-4 rounded-2xl border transition-all duration-200
                       hover:scale-[1.02] active:scale-95 text-left"
            style={{
              background:  isDone ? '#30D15810' : 'var(--bg-card)',
              borderColor: isDone ? '#30D15850' : 'var(--border)',
              boxShadow:   'var(--shadow)',
              opacity:     isLocked ? 0.5 : 1,
              cursor:      isLocked ? 'not-allowed' : 'pointer',
            }}
          >
            <div className="w-11 h-11 rounded-full flex items-center justify-center text-lg flex-shrink-0"
                 style={{ background: isDone ? '#30D15825' : 'linear-gradient(135deg,#7C5CFF,#0A84FF)', color: isDone ? '#30D158' : '#fff' }}>
              {isLocked ? '🔒' : isDone ? '✓' : i + 1}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>{unit.title}</p>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {unit.letters.map(l => l === 'space' ? '␣' : l === 'del' ? '⌫' : l).join('  ·  ')}
              </p>
            </div>
            {!isLocked && <span style={{ color: 'var(--text-muted)' }}>›</span>}
          </button>
        )
      })}
    </div>
  )
}

// ─────────────────────────────────────────────
// Summary — shown after finishing a unit
// ─────────────────────────────────────────────
function SummaryScreen({ unit, sessionXp, onContinue }) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 text-center gap-4">
      <div className="text-6xl">🎉</div>
      <h2 className="font-bold text-xl" style={{ color: 'var(--text-primary)' }}>
        Unit complete!
      </h2>
      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
        You finished <strong>{unit?.title}</strong>
      </p>
      <div className="flex items-center gap-2 px-4 py-2 rounded-full border"
           style={{ background: 'var(--pill-bg)', borderColor: 'var(--pill-border)' }}>
        <span>⚡</span>
        <span className="font-bold" style={{ color: 'var(--text-primary)' }}>+{sessionXp} XP</span>
      </div>
      <button
        onClick={onContinue}
        className="mt-2 px-6 py-3 rounded-xl font-semibold text-sm text-white transition-all hover:scale-105 active:scale-95"
        style={{ background: 'linear-gradient(135deg,#7C5CFF,#0A84FF)' }}
      >
        Back to lessons
      </button>
    </div>
  )
}

// ─────────────────────────────────────────────
// Lesson runner — live webcam quiz, one sign at a time
// ─────────────────────────────────────────────
function LessonRunner({ unit, languageId, onXpEarned, onDone, onExit }) {
  const camera    = useCamera()
  const signModel = useSignModel(languageId)

  const [stepIndex, setStepIndex]   = useState(0)
  const [status, setStatus]         = useState('waiting') // waiting | holding | correct
  const [holdProgress, setHoldProgress] = useState(0)

  const holdStartRef = useRef(null)
  const advancingRef = useRef(false)

  const target = unit.letters[stepIndex]

  useEffect(() => { signModel.loadModel() }, [])

  const handleLandmarks = useCallback((lms) => {
    if (advancingRef.current || !signModel.isLoaded) return
    const result = signModel.predict(lms)
    if (!result) return

    const isMatch =
      target === 'space' ? result.isSpace :
      target === 'del'   ? result.isDel :
      (result.letter === target && result.isValid)

    if (isMatch && result.isStable) {
      const now = Date.now()
      if (!holdStartRef.current) holdStartRef.current = now
      const held = now - holdStartRef.current
      setStatus('holding')
      setHoldProgress(Math.min(100, (held / HOLD_MS_TO_PASS) * 100))

      if (held >= HOLD_MS_TO_PASS && !advancingRef.current) {
        advancingRef.current = true
        setStatus('correct')
        onXpEarned(XP_PER_SIGN)
        setTimeout(() => {
          advancingRef.current = false
          holdStartRef.current = null
          setHoldProgress(0)
          if (stepIndex + 1 >= unit.letters.length) {
            onDone()
          } else {
            setStatus('waiting')
            setStepIndex(i => i + 1)
          }
        }, 700)
      }
    } else {
      holdStartRef.current = null
      setHoldProgress(0)
      if (!advancingRef.current) setStatus('waiting')
    }
  }, [target, signModel.isLoaded, signModel.predict, stepIndex, unit.letters.length, onXpEarned, onDone])

  const handleNoHand = useCallback(() => {
    holdStartRef.current = null
    setHoldProgress(0)
    if (!advancingRef.current) setStatus('waiting')
  }, [])

  const mediapipe = useMediaPipe({ onLandmarks: handleLandmarks, onNoHand: handleNoHand, numHands: signModel.numHands || 1 })

  useEffect(() => {
    (async () => { await Promise.all([camera.startCamera(), mediapipe.loadMediaPipe()]) })()
    return () => { camera.cleanup(); mediapipe.stopDetection() }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (camera.isActive && mediapipe.isLoaded && camera.videoRef.current) {
      mediapipe.startDetection(camera.videoRef.current)
    }
  }, [camera.isActive, mediapipe.isLoaded])

  const isReady = camera.isActive && mediapipe.isLoaded && signModel.isLoaded

  const skipStep = () => {
    holdStartRef.current = null
    setHoldProgress(0)
    if (stepIndex + 1 >= unit.letters.length) onDone()
    else { setStatus('waiting'); setStepIndex(i => i + 1) }
  }

  const displayTarget = target === 'space' ? '␣ SPACE' : target === 'del' ? '⌫ DELETE' : target

  return (
    <div className="px-5 py-5 max-w-sm mx-auto space-y-4">
      {/* Progress bar across the whole unit */}
      <div className="flex items-center gap-1.5">
        {unit.letters.map((_, i) => (
          <div key={i} className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--bg-tertiary)' }}>
            <div className="h-full rounded-full transition-all duration-300"
                 style={{
                   width: i < stepIndex ? '100%' : i === stepIndex ? `${holdProgress}%` : '0%',
                   background: 'linear-gradient(90deg,#7C5CFF,#0A84FF)',
                 }} />
          </div>
        ))}
      </div>

      {/* Target sign card */}
      <div className="rounded-2xl border p-5 flex flex-col items-center gap-2"
           style={{ background: 'var(--bg-card)', borderColor: 'var(--border)', boxShadow: 'var(--shadow)' }}>
        <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: 'var(--text-muted)' }}>
          Show this sign
        </p>
        {target.length === 1 ? <HandSVG letter={target} size={100} /> : (
          <div className="text-4xl h-[100px] flex items-center justify-center">
            {target === 'space' ? '␣' : '⌫'}
          </div>
        )}
        <h2 className="text-2xl font-black" style={{ color: 'var(--text-primary)' }}>{displayTarget}</h2>
      </div>

      {/* Camera feed */}
      <div className="relative rounded-2xl overflow-hidden border aspect-[4/3]"
           style={{ background: 'var(--cam-bg)', borderColor: status === 'correct' ? '#30D158' : 'var(--border)' }}>
        <video ref={camera.videoRef} muted playsInline
               className="w-full h-full object-cover" style={{ transform: 'scaleX(-1)' }} />
        {!isReady && (
          <div className="absolute inset-0 flex items-center justify-center flex-col gap-2"
               style={{ background: 'var(--overlay-bg)' }}>
            <div className="w-7 h-7 border-2 rounded-full animate-spin"
                 style={{ borderColor: '#0A84FF', borderTopColor: 'transparent' }} />
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Getting camera + model ready…</p>
          </div>
        )}
        {isReady && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-full text-xs font-semibold"
               style={{
                 background: status === 'correct' ? '#30D158' : status === 'holding' ? '#0A84FF' : 'rgba(0,0,0,0.55)',
                 color: '#fff',
               }}>
            {status === 'correct' ? '✓ Nice!' : status === 'holding' ? 'Hold it…' : 'Show your hand'}
          </div>
        )}
      </div>

      <button
        onClick={skipStep}
        className="w-full py-2.5 rounded-xl text-xs font-medium transition-all"
        style={{ color: 'var(--text-muted)', border: '1px solid var(--border)' }}
      >
        Skip this sign
      </button>
      <button
        onClick={onExit}
        className="w-full py-2 rounded-xl text-xs font-medium transition-all"
        style={{ color: 'var(--text-muted)' }}
      >
        Exit lesson
      </button>
    </div>
  )
}
