// src/components/screens/MobileSoloScreen.jsx
// ─────────────────────────────────────────────
// Mobile layout for Solo screen
// Stacked vertically instead of side-by-side
// Camera top, chat bottom, controls fixed at bottom
// ─────────────────────────────────────────────

import { useState, useEffect, useRef, useCallback } from 'react'
import { useCamera }    from '../../hooks/useCamera'
import { useMediaPipe } from '../../hooks/useMediaPipe'
import { useSignModel } from '../../hooks/useSignModel'
import { useLanguage }  from '../../context/LanguageContext'
import LanguageSelector from '../LanguageSelector'
import { useSpeech }    from '../../hooks/useSpeech'
import { WordBuilder }  from '../../utils/wordBuilder'
import { useToast }     from '../../hooks/useToast'
import ToastContainer   from '../ToastContainer'
import { useKeyboardShortcuts, ShortcutsHelp } from '../../hooks/useKeyboardShortcuts.jsx'

export default function MobileSoloScreen({ role, onGoHome }) {
  const camera    = useCamera()
  const { languageId } = useLanguage()
  const signModel = useSignModel(languageId)
  const speech    = useSpeech()
  const toast     = useToast()

  const [messages,       setMessages]       = useState([])
  const [currentWord,    setCurrentWord]    = useState('')
  const [currentSent,    setCurrentSent]    = useState('')
  const [isSigning,      setIsSigning]      = useState(false)
  const [detectedLetter, setDetectedLetter] = useState(null)
  const [landmarks,      setLandmarks]      = useState(null)
  const [isListening,    setIsListening]    = useState(false)
  const [showChat,       setShowChat]       = useState(false)
  const [showHelp,       setShowHelp]       = useState(false)

  const wordBuilderRef = useRef(null)
  const canvasRef      = useRef(null)
  const chatBottomRef  = useRef(null)
  const signingRef     = useRef(false)

  useEffect(() => {
    wordBuilderRef.current = new WordBuilder((state) => {
      setCurrentWord(state.currentWord)
      setCurrentSent(state.sentence)
    })
    signModel.loadModel()
  }, [])

  const handleLandmarks = useCallback((lms) => {
    setLandmarks(lms)
    drawLandmarks(lms)
    if (!signingRef.current || !signModel.isLoaded) return
    const result = signModel.predict(lms)
    if (!result) return
    setDetectedLetter({ letter: result.letter, confidence: result.confidence,
                        isValid: result.isValid, isNothing: result.isNothing })
    wordBuilderRef.current?.process(result)
    if (result.isDel && result.isStable) wordBuilderRef.current?.deleteLastChar()
  }, [signModel.isLoaded, signModel.predict])

  const handleNoHand = useCallback(() => {
    setLandmarks(null)
    setDetectedLetter(null)
    clearCanvas()
    wordBuilderRef.current?.process({ isNothing: true, isValid: false })
  }, [])

  const mediapipe = useMediaPipe({ onLandmarks: handleLandmarks, onNoHand: handleNoHand, numHands: signModel.numHands || 1 })

  const startEverything = useCallback(async () => {
    try {
      await Promise.all([camera.startCamera(), mediapipe.loadMediaPipe()])
    } catch (err) {
      toast.error('Could not start camera. Please allow camera access.')
    }
  }, [])

  useEffect(() => { startEverything() }, [])

  useEffect(() => {
    if (camera.isActive && mediapipe.isLoaded && camera.videoRef.current)
      mediapipe.startDetection(camera.videoRef.current)
  }, [camera.isActive, mediapipe.isLoaded])

  useEffect(() => () => { camera.cleanup(); mediapipe.stopDetection() }, [])

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Draws one hand's 21-point skeleton onto an already-sized canvas.
  // Extracted so multi-hand languages (ISL/BSL) can call it once per
  // detected hand — single-hand languages (ASL) still draw exactly
  // the same pixels as before via the one-hand branch below.
  const drawHandSkeleton = (ctx, hand, W, H) => {
    const connections = [
      [0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],
      [0,9],[9,10],[10,11],[11,12],[0,13],[13,14],[14,15],[15,16],
      [0,17],[17,18],[18,19],[19,20],[5,9],[9,13],[13,17],
    ]
    ctx.strokeStyle = '#0A84FF88'; ctx.lineWidth = 2
    for (const [a, b] of connections) {
      ctx.beginPath()
      ctx.moveTo((1-hand[a].x)*W, hand[a].y*H)
      ctx.lineTo((1-hand[b].x)*W, hand[b].y*H)
      ctx.stroke()
    }
    for (let i = 0; i < hand.length; i++) {
      const isTip = [4,8,12,16,20].includes(i)
      ctx.fillStyle = isTip ? '#0A84FF' : '#0A84FF88'
      ctx.beginPath()
      ctx.arc((1-hand[i].x)*W, hand[i].y*H, isTip ? 5 : 3, 0, Math.PI*2)
      ctx.fill()
    }
  }

  const drawLandmarks = (lms) => {
    const canvas = canvasRef.current
    const video  = camera.videoRef.current
    if (!canvas || !video || !lms) return
    const ctx = canvas.getContext('2d')
    canvas.width  = video.videoWidth  || 640
    canvas.height = video.videoHeight || 480
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    const W = canvas.width, H = canvas.height

    // Two-hand languages (numHands > 1) receive an array of hands from
    // useMediaPipe; single-hand languages (ASL) receive one hand's
    // 21-point array directly — same shape/behavior as before.
    if (signModel.numHands > 1 && Array.isArray(lms[0])) {
      for (const hand of lms) {
        if (hand) drawHandSkeleton(ctx, hand, W, H)
      }
    } else {
      drawHandSkeleton(ctx, lms, W, H)
    }
  }

  const clearCanvas = () => {
    const c = canvasRef.current
    if (c) c.getContext('2d')?.clearRect(0, 0, c.width, c.height)
  }

  const toggleSigning = useCallback(() => {
    const next = !isSigning
    setIsSigning(next)
    signingRef.current = next
    toast.info(next ? '🤟 Signing started — show your hand' : '⏹ Signing stopped')
    if (!next) {
      const state = wordBuilderRef.current?.getState()
      if (state?.fullText) sendMessage()
    }
  }, [isSigning])

  const sendMessage = useCallback(() => {
    const state = wordBuilderRef.current?.getState()
    const text  = state?.fullText?.trim()
    if (!text) { toast.warning('Nothing to send yet'); return }
    setMessages(prev => [...prev, {
      id: Date.now(), role: 'deaf', text,
      timestamp: new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
    }])
    speech.speak(text)
    toast.success('Message sent!')
    wordBuilderRef.current?.clear()
    setCurrentWord(''); setCurrentSent('')
    signModel.resetBuffer()
    setShowChat(true)
  }, [])

  const toggleListening = useCallback(() => {
    if (isListening) {
      speech.stopListening()
      setIsListening(false)
      const text = speech.transcript?.trim()
      if (text) {
        setMessages(prev => [...prev, {
          id: Date.now(), role: 'hearing', text,
          timestamp: new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
        }])
        toast.success('Message sent!')
        speech.clearTranscript()
        setShowChat(true)
      } else {
        toast.warning('No speech detected')
      }
    } else {
      speech.startListening()
      setIsListening(true)
      toast.info('🎤 Listening... speak now')
    }
  }, [isListening, speech])

  const deleteChar = useCallback(() => {
    wordBuilderRef.current?.deleteLastChar()
  }, [])

  // Keyboard shortcuts
  useKeyboardShortcuts({
    role, isSigning, isListening,
    onToggleSigning:   toggleSigning,
    onToggleListening: toggleListening,
    onSend:            sendMessage,
    onDeleteChar:      deleteChar,
    onShowHelp:        () => setShowHelp(true),
    enabled:           true,
  })

  const isReady    = camera.isActive && mediapipe.isLoaded && signModel.isLoaded
  const confColor  = (c) => c >= 0.9 ? '#30D158' : c >= 0.7 ? '#FF9F0A' : '#FF453A'

  return (
    <div className="h-screen w-screen bg-surface-primary flex flex-col overflow-hidden">

      {/* HEADER */}
      <header className="flex items-center justify-between px-4 py-3
                         border-b border-surface-border flex-shrink-0"
              style={{ background: 'rgba(28,28,30,0.95)' }}>
        <div className="flex items-center gap-3">
          <button onClick={onGoHome}
                  className="w-9 h-9 rounded-full flex items-center justify-center
                             text-[#636366] hover:text-[#F2F2F7] hover:bg-surface-tertiary transition-all">
            ←
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xl">{role === 'deaf' ? '🤟' : '🎤'}</span>
            <h1 className="text-[#F2F2F7] font-semibold text-sm">
              {role === 'deaf' ? 'Deaf Mode' : 'Hearing Mode'}
            </h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Status dot */}
          <div className={`w-2 h-2 rounded-full ${isReady ? 'bg-[#30D158]' : 'bg-[#FF9F0A] animate-pulse'}`} />

          {/* Chat toggle with badge */}
          <button onClick={() => setShowChat(!showChat)}
                  className="relative w-9 h-9 rounded-full flex items-center justify-center
                             transition-all text-sm"
                  style={{ background: showChat ? '#0A84FF20' : 'rgba(44,44,46,0.8)',
                           color: showChat ? '#0A84FF' : '#636366' }}>
            💬
            {messages.length > 0 && !showChat && (
              <div className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full
                              bg-brand-500 text-white text-xs flex items-center justify-center">
                {messages.length > 9 ? '9+' : messages.length}
              </div>
            )}
          </button>

          {/* Help */}
          <button onClick={() => setShowHelp(true)}
                  className="w-9 h-9 rounded-full flex items-center justify-center
                             text-[#636366] hover:text-[#F2F2F7] hover:bg-surface-tertiary
                             transition-all text-sm">
            ?
          </button>
        </div>
      </header>

      {/* MAIN — camera OR chat depending on toggle */}
      <div className="flex-1 flex flex-col overflow-hidden relative">

        {/* Camera view */}
        <div className={`relative bg-black transition-all duration-300
          ${showChat ? 'h-40 flex-shrink-0' : 'flex-1'}`}>
          <video ref={camera.videoRef} className="w-full h-full object-cover"
                 playsInline muted style={{ transform: 'scaleX(-1)' }} />
          <canvas ref={canvasRef}
                  className="absolute inset-0 w-full h-full pointer-events-none" />

          {/* Loading overlay */}
          {!isReady && (
            <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
              <div className="text-center space-y-2">
                <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent
                                rounded-full animate-spin mx-auto" />
                <p className="text-white text-xs">
                  {!camera.isActive ? 'Starting camera...'
                   : !mediapipe.isLoaded ? 'Loading hand detector...'
                   : 'Loading AI...'}
                </p>
              </div>
            </div>
          )}

          {/* Signing indicator */}
          {isSigning && (
            <div className="absolute top-2 left-2 flex items-center gap-1.5
                            px-2.5 py-1 rounded-full bg-black/70 border border-brand-500/50">
              <div className="status-dot-active" />
              <span className="text-white text-xs">Detecting</span>
            </div>
          )}

          {/* No hand warning */}
          {isSigning && !landmarks && (
            <div className="absolute top-2 right-2 px-2.5 py-1 rounded-full
                            bg-black/70 border border-[#FF9F0A]/50">
              <span className="text-[#FF9F0A] text-xs">✋ Show hand</span>
            </div>
          )}

          {/* Detection badge — shown in camera view */}
          {role === 'deaf' && isReady && (
            <div className="absolute bottom-2 left-2 right-2 flex items-center gap-3
                            px-3 py-2 rounded-xl bg-black/75 border border-white/10">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center
                              text-2xl font-bold border-2 flex-shrink-0 transition-all"
                   style={{
                     background:  detectedLetter?.isValid ? '#0A84FF15' : '#1C1C1E',
                     borderColor: detectedLetter?.isValid ? '#0A84FF'   : '#38383A',
                     color:       detectedLetter?.isValid ? '#0A84FF'   : '#636366',
                   }}>
                {!detectedLetter || detectedLetter.isNothing ? '—' : detectedLetter.letter}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white text-xs font-mono truncate">
                  <span className="text-white/50">{currentSent}</span>
                  <span className="text-brand-500">{currentWord}</span>
                  {isSigning && <span className="animate-pulse text-brand-500">|</span>}
                </p>
                {detectedLetter && !detectedLetter.isNothing && (
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <div className="confidence-bar w-16">
                      <div className="h-full rounded-full"
                           style={{ width:`${detectedLetter.confidence*100}%`,
                                    background: confColor(detectedLetter.confidence) }} />
                    </div>
                    <span className="text-xs" style={{ color: confColor(detectedLetter.confidence) }}>
                      {(detectedLetter.confidence*100).toFixed(0)}%
                    </span>
                  </div>
                )}
              </div>
              {(currentWord || currentSent) && (
                <button onClick={deleteChar}
                        className="text-white/50 hover:text-white text-sm flex-shrink-0">⌫</button>
              )}
            </div>
          )}
        </div>

        {/* Chat panel */}
        {showChat && (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center
                              h-full gap-3 text-center py-8">
                <div className="text-4xl opacity-20">💬</div>
                <p className="text-[#636366] text-sm">No messages yet</p>
              </div>
            )}
            {messages.map(msg => (
              <div key={msg.id}
                   className={`flex flex-col gap-1 animate-slide-up
                     ${msg.role === 'hearing' ? 'items-end' : 'items-start'}`}>
                <div className="flex items-center gap-1 px-1">
                  <span className="text-xs">{msg.role === 'deaf' ? '🤟' : '🎤'}</span>
                  <span className="text-[#636366] text-xs">
                    {msg.role === 'deaf' ? 'Signed' : 'Spoken'} · {msg.timestamp}
                  </span>
                </div>
                <div className={msg.role === 'deaf' ? 'bubble-deaf' : 'bubble-hearing'}>
                  <p className="leading-relaxed text-sm">{msg.text}</p>
                </div>
              </div>
            ))}
            <div ref={chatBottomRef} />
          </div>
        )}
      </div>

      {/* CONTROL BAR */}
      <div className="flex-shrink-0 border-t border-surface-border px-4 py-3
                      flex items-center gap-3"
           style={{ background: 'rgba(28,28,30,0.98)' }}>

        {role === 'deaf' && (
          <>
            <button onClick={toggleSigning} disabled={!isReady}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-2xl
                               font-semibold text-sm transition-all duration-200
                               hover:scale-105 active:scale-95
                               disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{
                      background: isSigning ? 'linear-gradient(135deg,#0A84FF,#0066CC)' : '#2C2C2E',
                      color: '#F2F2F7',
                      boxShadow: isSigning ? '0 0 20px #0A84FF44' : 'none',
                    }}>
              <span>{isSigning ? '⏹' : '🤟'}</span>
              <span className="hidden sm:inline">{isSigning ? 'Stop' : 'Start Signing'}</span>
              {isSigning && <div className="w-2 h-2 rounded-full bg-white animate-pulse" />}
            </button>

            <button onClick={sendMessage} disabled={!currentWord && !currentSent}
                    className="w-11 h-11 rounded-full flex items-center justify-center
                               bg-brand-500 hover:bg-brand-600 text-white text-lg
                               transition-all hover:scale-110 active:scale-95
                               disabled:opacity-40 disabled:cursor-not-allowed">
              ↑
            </button>
          </>
        )}

        {role === 'hearing' && (
          <button onClick={toggleListening} disabled={!speech.supported.stt}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-2xl
                             font-semibold text-sm transition-all duration-200
                             hover:scale-105 active:scale-95
                             disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{
                    background: isListening ? 'linear-gradient(135deg,#30D158,#25A244)' : '#2C2C2E',
                    color: '#F2F2F7',
                    boxShadow: isListening ? '0 0 20px #30D15844' : 'none',
                  }}>
            <span>🎤</span>
            <span className="hidden sm:inline">{isListening ? 'Listening...' : 'Speak'}</span>
            {isListening && <div className="w-2 h-2 rounded-full bg-white animate-pulse" />}
          </button>
        )}

        <div className="flex-1" />

        {/* Clear */}
        <button onClick={() => { setMessages([]); toast.info('Conversation cleared') }}
                className="w-9 h-9 rounded-full flex items-center justify-center
                           text-[#636366] hover:text-[#FF453A]
                           hover:bg-surface-tertiary transition-all text-sm">
          🗑
        </button>

        <button onClick={onGoHome}
                className="text-[#636366] text-xs hover:text-[#F2F2F7]
                           transition-colors px-2 py-1 rounded-lg hover:bg-surface-tertiary">
          Switch
        </button>
      </div>

      {/* Toasts */}
      <ToastContainer toasts={toast.toasts} onDismiss={toast.dismiss} />

      {/* Keyboard shortcuts help */}
      {showHelp && (
        <ShortcutsHelp role={role} onClose={() => setShowHelp(false)} />
      )}
    </div>
  )
}