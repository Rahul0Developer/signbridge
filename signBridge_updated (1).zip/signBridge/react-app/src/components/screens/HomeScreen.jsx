// src/components/screens/HomeScreen.jsx
import { useState, useEffect } from 'react'
import { useNavigate }        from 'react-router-dom'
import { useTheme } from '../../context/ThemeContext'
import { useAuth }  from '../../context/AuthContext'
import ThemeToggle  from '../ThemeToggle'
import LanguageSelector from '../LanguageSelector'

export default function HomeScreen({ onSelectRole, onStartMeeting, onJoinMeeting, onLogout, modelStatus }) {
  const { isDark, setTheme } = useTheme()
  const { user }            = useAuth()
  const navigate            = useNavigate()
  const [animated,     setAnimated]     = useState(false)
  const [selectedRole, setSelectedRole] = useState(null)
  const [meetingMode,  setMeetingMode]  = useState(null)
  const [roomCode,     setRoomCode]     = useState('')

  // Force light theme on HomeScreen for clean UI
  // Restore user's saved preference when leaving
  useEffect(() => {
    const saved = localStorage.getItem('sb-theme') || 'light'
    setTheme('light')
    return () => setTheme(saved)
  }, [])

  useEffect(() => {
    const t = setTimeout(() => setAnimated(true), 100)
    return () => clearTimeout(t)
  }, [])

  const handleInPerson = () => {
    if (!selectedRole) { alert('Please select your role first'); return }
    onSelectRole(selectedRole)
  }
  const handleStartMeeting = () => {
    if (!selectedRole) { alert('Please select your role first'); return }
    onStartMeeting(selectedRole)
  }
  const handleJoinMeeting = () => {
    if (!selectedRole) { alert('Please select your role first'); return }
    if (!roomCode.trim()) { alert('Please enter a room code'); return }
    onJoinMeeting(selectedRole, roomCode.trim().toUpperCase())
  }

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden"
         style={{ background: 'var(--bg-primary)', transition: 'background 0.3s ease' }}>

      {/* ── HEADER ── */}
      <header className="flex items-center justify-between px-5 py-3
                         border-b flex-shrink-0"
              style={{
                background:   'var(--header-bg)',
                borderColor:  'var(--header-border)',
                opacity:      animated ? 1 : 0,
                transition:   'opacity 0.5s ease, background 0.3s ease',
                backdropFilter: 'blur(12px)',
              }}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center text-lg"
               style={{ background: 'linear-gradient(135deg,#0A84FF,#00C6FF)' }}>
            🤟
          </div>
          <div>
            <h1 className="font-bold text-base leading-none"
                style={{ color: 'var(--text-primary)' }}>SignBridge</h1>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
              Breaking barriers one sign at a time
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Model status */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border"
               style={{ background: 'var(--pill-bg)', borderColor: 'var(--pill-border)' }}>
            <div className={modelStatus?.isLoaded
              ? 'w-2 h-2 rounded-full bg-[#30D158]'
              : 'w-2 h-2 rounded-full bg-[#FF9F0A] animate-pulse'} />
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
              {modelStatus?.isLoading ? 'Loading AI...'
               : modelStatus?.isLoaded ? 'AI Ready' : 'AI Error'}
            </span>
          </div>

          {/* Sign language picker */}
          <LanguageSelector />

          {/* Theme toggle */}
          <ThemeToggle />

          {/* User avatar + name + logout */}
          {user && (
            <div className="flex items-center gap-2">
              {/* Avatar — click to go to profile */}
              <button onClick={() => navigate('/app/profile')}
                      className="flex-shrink-0 hover:scale-110 transition-transform"
                      style={{ background:'none', border:'none', cursor:'pointer', padding:0 }}
                      title="View profile">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="avatar"
                       className="w-8 h-8 rounded-full border-2"
                       style={{ borderColor: 'var(--border)' }} />
                ) : (
                  <div className="w-8 h-8 rounded-full flex items-center justify-center
                                  text-white text-sm font-bold"
                       style={{ background: 'linear-gradient(135deg,#0A84FF,#00C6FF)' }}>
                    {user.displayName?.charAt(0)?.toUpperCase() || user.email?.charAt(0)?.toUpperCase()}
                  </div>
                )}
              </button>
              {/* Name or email */}
              <span className="text-xs font-medium max-w-[80px] truncate hidden sm:block"
                    style={{ color: 'var(--text-secondary)' }}>
                {user.displayName || user.email?.split('@')[0]}
              </span>
              {/* Logout button */}
              <button
                onClick={onLogout}
                className="text-xs px-2.5 py-1 rounded-lg border transition-all
                           hover:border-red-300 hover:text-red-500"
                style={{ color: 'var(--text-muted)', borderColor: 'var(--border)' }}
              >
                Logout
              </button>
            </div>
          )}
        </div>
      </header>

      {/* ── SCROLLABLE CONTENT ── */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-5 py-5 space-y-5 max-w-sm mx-auto">

          {/* Hero */}
          <div className="text-center space-y-1.5"
               style={{
                 opacity:   animated ? 1 : 0,
                 transform: animated ? 'translateY(0)' : 'translateY(16px)',
                 transition:'all 0.5s ease 0.1s',
               }}>
            <h2 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
              Who are you today?
            </h2>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Select your role to get started.
            </p>
          </div>

          {/* Role cards */}
          <div className="grid grid-cols-2 gap-3"
               style={{
                 opacity:   animated ? 1 : 0,
                 transform: animated ? 'translateY(0)' : 'translateY(16px)',
                 transition:'all 0.5s ease 0.15s',
               }}>
            {[
              { role: 'deaf',    icon: '🤟', label: "I'm Deaf",   desc: 'Sign → text & speech',  color: '#0A84FF' },
              { role: 'hearing', icon: '🎤', label: 'I Can Hear', desc: 'Speech → text & signs', color: '#30D158' },
            ].map(({ role, icon, label, desc, color }) => (
              <button
                key={role}
                onClick={() => setSelectedRole(role)}
                className="relative rounded-2xl p-4 text-left border-2
                           transition-all duration-200 hover:scale-105 active:scale-95"
                style={{
                  background:  selectedRole === role
                    ? `${color}15`
                    : 'var(--bg-card)',
                  borderColor: selectedRole === role ? color : 'var(--border)',
                  boxShadow:   selectedRole === role ? `0 0 20px ${color}33` : 'var(--shadow)',
                }}
              >
                {selectedRole === role && (
                  <div className="absolute top-2.5 right-2.5 w-4 h-4 rounded-full
                                  flex items-center justify-center text-white text-xs"
                       style={{ background: color }}>✓</div>
                )}
                <div className="text-3xl mb-2">{icon}</div>
                <h3 className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>
                  {label}
                </h3>
                <p className="text-xs mt-0.5 leading-snug" style={{ color: 'var(--text-secondary)' }}>
                  {desc}
                </p>
              </button>
            ))}
          </div>

          {/* Mode buttons */}
          <div className="space-y-2"
               style={{
                 opacity:   animated ? 1 : 0,
                 transform: animated ? 'translateY(0)' : 'translateY(16px)',
                 transition:'all 0.5s ease 0.2s',
               }}>

            {/* Practice / Learn — Duolingo-style lessons */}
            <button
              onClick={() => navigate('/app/learn')}
              className="w-full flex items-center gap-3 p-3.5 rounded-2xl
                         border-2 transition-all duration-200 group hover:scale-[1.02]"
              style={{
                background: 'linear-gradient(135deg,#7C5CFF10,#0A84FF10)',
                borderColor: '#7C5CFF40',
                boxShadow: 'var(--shadow)',
              }}
            >
              <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
                   style={{ background: 'linear-gradient(135deg,#7C5CFF,#0A84FF)' }}>
                🎓
              </div>
              <div className="flex-1 text-left">
                <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>
                  Learn to Sign
                </p>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                  Bite-sized lessons · practice with the camera
                </p>
              </div>
              <span style={{ color: 'var(--text-muted)' }}>›</span>
            </button>

            <div className="flex items-center gap-3">
              <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
              <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Choose mode</span>
              <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
            </div>

            {/* In-Person */}
            <button
              onClick={handleInPerson}
              className="w-full flex items-center gap-3 p-3.5 rounded-2xl
                         border transition-all duration-200 group hover:scale-[1.02]"
              style={{ background: 'var(--bg-card)', borderColor: 'var(--border)',
                       boxShadow: 'var(--shadow)' }}
            >
              <div className="w-9 h-9 rounded-xl bg-[#0A84FF]/20 flex items-center
                              justify-center text-lg group-hover:bg-[#0A84FF]/30 transition-colors">
                💬
              </div>
              <div className="flex-1 text-left">
                <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>
                  In-Person Mode
                </p>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                  Communicate face to face
                </p>
              </div>
              <span style={{ color: 'var(--text-muted)' }}>›</span>
            </button>

            {/* Start Meeting */}
            <button
              onClick={() => setMeetingMode(meetingMode === 'start' ? null : 'start')}
              className="w-full flex items-center gap-3 p-3.5 rounded-2xl
                         border transition-all duration-200 group hover:scale-[1.02]"
              style={{
                background:  meetingMode === 'start' ? '#30D15810' : 'var(--bg-card)',
                borderColor: meetingMode === 'start' ? '#30D15850' : 'var(--border)',
                boxShadow:   'var(--shadow)',
              }}
            >
              <div className="w-9 h-9 rounded-xl bg-[#30D158]/20 flex items-center
                              justify-center text-lg group-hover:bg-[#30D158]/30 transition-colors">
                📹
              </div>
              <div className="flex-1 text-left">
                <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>
                  Start a Meeting
                </p>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                  Create a room, share the code
                </p>
              </div>
              <span style={{ color: 'var(--text-muted)',
                             transform: meetingMode === 'start' ? 'rotate(90deg)' : 'none',
                             transition: 'transform 0.2s' }}>›</span>
            </button>

            {meetingMode === 'start' && (
              <div className="rounded-2xl border p-4 space-y-3"
                   style={{ background: '#30D15808', borderColor: '#30D15840' }}>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  You'll get a room code to share with the other person.
                </p>
                <button onClick={handleStartMeeting}
                        className="w-full py-2.5 rounded-xl font-semibold text-sm
                                   text-white transition-all hover:scale-105 active:scale-95"
                        style={{ background: 'linear-gradient(135deg,#30D158,#25A244)' }}>
                  + Create Room
                </button>
              </div>
            )}

            {/* Join Meeting */}
            <button
              onClick={() => setMeetingMode(meetingMode === 'join' ? null : 'join')}
              className="w-full flex items-center gap-3 p-3.5 rounded-2xl
                         border transition-all duration-200 group hover:scale-[1.02]"
              style={{
                background:  meetingMode === 'join' ? '#FF9F0A10' : 'var(--bg-card)',
                borderColor: meetingMode === 'join' ? '#FF9F0A50' : 'var(--border)',
                boxShadow:   'var(--shadow)',
              }}
            >
              <div className="w-9 h-9 rounded-xl bg-[#FF9F0A]/20 flex items-center
                              justify-center text-lg group-hover:bg-[#FF9F0A]/30 transition-colors">
                🔗
              </div>
              <div className="flex-1 text-left">
                <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>
                  Join a Meeting
                </p>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                  Enter a room code to join
                </p>
              </div>
              <span style={{ color: 'var(--text-muted)',
                             transform: meetingMode === 'join' ? 'rotate(90deg)' : 'none',
                             transition: 'transform 0.2s' }}>›</span>
            </button>

            {meetingMode === 'join' && (
              <div className="rounded-2xl border p-4 space-y-3"
                   style={{ background: '#FF9F0A08', borderColor: '#FF9F0A40' }}>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                  Enter the room code from the person who started the meeting.
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={roomCode}
                    onChange={e => setRoomCode(
                      e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 7)
                    )}
                    placeholder="ABC-123"
                    maxLength={7}
                    onKeyDown={e => e.key === 'Enter' && handleJoinMeeting()}
                    className="flex-1 text-sm py-2.5 px-3 rounded-xl border
                               uppercase tracking-[0.2em] font-mono text-center
                               outline-none focus:ring-2 focus:ring-[#FF9F0A]/40
                               transition-all"
                    style={{
                      background:  'var(--input-bg)',
                      borderColor: 'var(--input-border)',
                      color:       'var(--input-text)',
                    }}
                  />
                  <button onClick={handleJoinMeeting}
                          className="px-4 py-2.5 rounded-xl font-semibold text-sm
                                     text-white transition-all hover:scale-105 active:scale-95"
                          style={{ background: 'linear-gradient(135deg,#FF9F0A,#E8890A)' }}>
                    Join
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Feature pills */}
          <div className="flex items-center justify-center gap-2 flex-wrap pb-4"
               style={{ opacity: animated ? 1 : 0, transition: 'opacity 0.5s ease 0.3s' }}>
            {[
              { icon: '🧠', text: '99% accurate' },
              { icon: '⚡', text: 'Real-time'    },
              { icon: '🔒', text: 'Private'      },
              { icon: '🌐', text: 'No install'   },
            ].map(({ icon, text }) => (
              <div key={text}
                   className="flex items-center gap-1.5 px-3 py-1 rounded-full border"
                   style={{ background: 'var(--pill-bg)', borderColor: 'var(--pill-border)' }}>
                <span className="text-xs">{icon}</span>
                <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{text}</span>
              </div>
            ))}
          </div>

        </div>
      </div>
    </div>
  )
}