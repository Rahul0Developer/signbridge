// src/components/screens/AuthPage.jsx
import { useState } from 'react'
import {
  signInWithPopup,
  signInWithRedirect,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
} from 'firebase/auth'
import { auth, googleProvider } from '../../firebase'
import { useTheme }             from '../../context/ThemeContext'
import { useAuth }              from '../../context/AuthContext'
import ThemeToggle              from '../ThemeToggle'

export default function AuthPage({ onBack, onAuthSuccess }) {
  const { isDark }       = useTheme()
  const { markRedirecting } = useAuth()

  const [mode,     setMode]     = useState('login')
  const [name,     setName]     = useState('')
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [confirm,  setConfirm]  = useState('')
  const [showPass, setShowPass] = useState(false)
  const [error,    setError]    = useState('')
  const [message,  setMessage]  = useState('')
  const [loading,  setLoading]  = useState(false)

  const clearState = () => {
    setError(''); setMessage('')
    setName(''); setEmail(''); setPassword(''); setConfirm('')
  }
  const switchMode = (m) => { clearState(); setMode(m) }

  const friendlyError = (code) => ({
    'auth/user-not-found':         'No account found with this email.',
    'auth/wrong-password':         'Incorrect password. Please try again.',
    'auth/invalid-credential':     'Incorrect email or password.',
    'auth/email-already-in-use':   'An account with this email already exists.',
    'auth/weak-password':          'Password must be at least 6 characters.',
    'auth/invalid-email':          'Please enter a valid email address.',
    'auth/too-many-requests':      'Too many attempts. Please try again later.',
    'auth/network-request-failed': 'Network error. Check your connection.',
  }[code] || 'Something went wrong. Please try again.')

  // ── Google Sign In ──
  // Try popup first (better UX — no page reload)
  // If browser blocks popup → fallback to redirect automatically
  const handleGoogle = () => {
    setError(''); setLoading(true)
    signInWithPopup(auth, googleProvider)
      .then((result) => {
        if (result?.user) {
          setLoading(false)
          onAuthSuccess()
        }
      })
      .catch((err) => {
        const code = err?.code || ''
        if (code === 'auth/popup-blocked' || code === 'auth/popup-closed-by-user' || !code) {
          // Popup blocked or closed → silently fall back to redirect
          console.log('[SignBridge] Popup blocked, falling back to redirect...')
          markRedirecting()
          signInWithRedirect(auth, googleProvider)
        } else {
          setLoading(false)
          setError(friendlyError(code))
        }
      })
  }

  // ── Email Login ──
  const handleLogin = async (e) => {
    e.preventDefault()
    if (!email || !password) { setError('Please fill in all fields.'); return }
    setLoading(true); setError('')
    try {
      await signInWithEmailAndPassword(auth, email, password)
      onAuthSuccess()
    } catch (err) {
      setError(friendlyError(err.code))
    } finally {
      setLoading(false)
    }
  }

  // ── Email Signup ──
  const handleSignup = async (e) => {
    e.preventDefault()
    if (!name || !email || !password || !confirm) { setError('Please fill in all fields.'); return }
    if (password !== confirm) { setError('Passwords do not match.'); return }
    if (password.length < 6)  { setError('Password must be at least 6 characters.'); return }
    setLoading(true); setError('')
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password)
      await updateProfile(cred.user, { displayName: name })
      onAuthSuccess()
    } catch (err) {
      setError(friendlyError(err.code))
    } finally {
      setLoading(false)
    }
  }

  // ── Password Reset ──
  const handleReset = async (e) => {
    e.preventDefault()
    if (!email) { setError('Please enter your email address.'); return }
    setLoading(true); setError('')
    try {
      await sendPasswordResetEmail(auth, email)
      setMessage('Reset email sent! Check your inbox.')
    } catch (err) {
      setError(friendlyError(err.code))
    } finally {
      setLoading(false)
    }
  }

  const inp = {
    background:   'var(--input-bg)',
    border:       '1px solid var(--input-border)',
    color:        'var(--input-text)',
    borderRadius: '12px',
    padding:      '12px 16px',
    fontSize:     '14px',
    width:        '100%',
    outline:      'none',
    transition:   'border-color 0.2s',
    boxSizing:    'border-box',
  }

  const btn = {
    width:         '100%',
    padding:       '13px',
    borderRadius:  '14px',
    border:        'none',
    background:    'linear-gradient(135deg,#0A84FF,#00C6FF)',
    color:         'white',
    fontWeight:    '700',
    fontSize:      '14px',
    cursor:        'pointer',
    boxShadow:     '0 8px 24px rgba(10,132,255,0.35)',
    transition:    'opacity 0.2s',
  }

  return (
    <div style={{
      background:  'var(--bg-secondary)',
      transition:  'background 0.3s',
      position:    'fixed',
      inset:       0,
      overflowY:   'auto',
      fontFamily:  "'DM Sans', sans-serif",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Serif+Display&display=swap"
            rel="stylesheet" />

      {/* Top bar */}
      <div style={{ display:'flex', alignItems:'center',
                    justifyContent:'space-between', padding:'16px 20px' }}>
        <button onClick={onBack}
                style={{ background:'none', border:'none', cursor:'pointer',
                         color:'var(--text-secondary)', fontSize:'14px' }}>
          ← Back
        </button>
        <ThemeToggle />
      </div>

      {/* Centered column */}
      <div style={{ display:'flex', flexDirection:'column',
                    alignItems:'center', padding:'8px 16px 48px' }}>

        {/* Card */}
        <div style={{
          width:'100%', maxWidth:'400px',
          background:   'var(--bg-card)',
          border:       '1px solid var(--border)',
          borderRadius: '24px',
          padding:      '32px',
          boxShadow:    isDark
            ? '0 24px 64px rgba(0,0,0,0.5)'
            : '0 8px 40px rgba(0,0,0,0.10)',
        }}>

          {/* Logo + title */}
          <div style={{ textAlign:'center', marginBottom:'28px' }}>
            <div style={{
              width:'56px', height:'56px', borderRadius:'16px',
              margin:'0 auto 16px', fontSize:'28px',
              background:'linear-gradient(135deg,#0A84FF,#00C6FF)',
              boxShadow:'0 8px 24px rgba(10,132,255,0.35)',
              display:'flex', alignItems:'center', justifyContent:'center',
            }}>🤟</div>
            <h1 style={{
              fontFamily:"'DM Serif Display', serif",
              fontSize:'24px', fontWeight:'bold',
              color:'var(--text-primary)', margin:'0 0 6px',
            }}>
              {mode === 'login'  && 'Welcome back'}
              {mode === 'signup' && 'Create account'}
              {mode === 'reset'  && 'Reset password'}
            </h1>
            <p style={{ color:'var(--text-secondary)', fontSize:'14px', margin:0 }}>
              {mode === 'login'  && 'Sign in to continue to SignBridge'}
              {mode === 'signup' && "Join SignBridge — it's free"}
              {mode === 'reset'  && "We'll send a reset link to your email"}
            </p>
          </div>

          {/* Google button — login + signup only */}
          {mode !== 'reset' && (
            <>
              <button
                onClick={handleGoogle}
                style={{
                  width:'100%', display:'flex', alignItems:'center',
                  justifyContent:'center', gap:'10px', padding:'12px',
                  borderRadius:'14px', cursor:'pointer',
                  background:'var(--bg-card)',
                  border:'1px solid var(--border-strong)',
                  color:'var(--text-primary)', fontWeight:'600',
                  fontSize:'14px', marginBottom:'16px',
                  transition:'opacity 0.2s',
                }}
              >
                <svg width="18" height="18" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                </svg>
                Continue with Google
              </button>

              <div style={{ display:'flex', alignItems:'center', gap:'12px', marginBottom:'16px' }}>
                <div style={{ flex:1, height:'1px', background:'var(--border)' }} />
                <span style={{ color:'var(--text-muted)', fontSize:'12px' }}>or</span>
                <div style={{ flex:1, height:'1px', background:'var(--border)' }} />
              </div>
            </>
          )}

          {/* Error / Success banners */}
          {error && (
            <div style={{
              background:'#FF453A15', border:'1px solid #FF453A40',
              color:'#FF453A', borderRadius:'12px', padding:'12px 16px',
              fontSize:'13px', marginBottom:'16px',
              display:'flex', gap:'8px', alignItems:'flex-start',
            }}>
              <span>⚠️</span><span>{error}</span>
            </div>
          )}
          {message && (
            <div style={{
              background:'#30D15815', border:'1px solid #30D15840',
              color:'#30D158', borderRadius:'12px', padding:'12px 16px',
              fontSize:'13px', marginBottom:'16px',
              display:'flex', gap:'8px',
            }}>
              <span>✓</span><span>{message}</span>
            </div>
          )}

          {/* LOGIN */}
          {mode === 'login' && (
            <form onSubmit={handleLogin}
                  style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
              <input type="email" placeholder="Email address"
                     value={email} onChange={e => setEmail(e.target.value)}
                     style={inp}
                     onFocus={e => e.target.style.borderColor='#0A84FF'}
                     onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
              <div style={{ position:'relative' }}>
                <input
                  type={showPass ? 'text' : 'password'}
                  placeholder="Password"
                  value={password} onChange={e => setPassword(e.target.value)}
                  style={{ ...inp, paddingRight:'44px' }}
                  onFocus={e => e.target.style.borderColor='#0A84FF'}
                  onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
                <button type="button" onClick={() => setShowPass(!showPass)}
                        style={{ position:'absolute', right:'12px', top:'50%',
                                 transform:'translateY(-50%)', background:'none',
                                 border:'none', cursor:'pointer', fontSize:'16px' }}>
                  {showPass ? '🙈' : '👁️'}
                </button>
              </div>
              <div style={{ textAlign:'right' }}>
                <button type="button" onClick={() => switchMode('reset')}
                        style={{ background:'none', border:'none', cursor:'pointer',
                                 color:'#0A84FF', fontSize:'12px' }}>
                  Forgot password?
                </button>
              </div>
              <button type="submit" disabled={loading}
                      style={{ ...btn, opacity: loading ? 0.6 : 1 }}>
                {loading ? 'Signing in...' : 'Sign In →'}
              </button>
            </form>
          )}

          {/* SIGNUP */}
          {mode === 'signup' && (
            <form onSubmit={handleSignup}
                  style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
              <input type="text" placeholder="Full name"
                     value={name} onChange={e => setName(e.target.value)}
                     style={inp}
                     onFocus={e => e.target.style.borderColor='#0A84FF'}
                     onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
              <input type="email" placeholder="Email address"
                     value={email} onChange={e => setEmail(e.target.value)}
                     style={inp}
                     onFocus={e => e.target.style.borderColor='#0A84FF'}
                     onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
              <div style={{ position:'relative' }}>
                <input
                  type={showPass ? 'text' : 'password'}
                  placeholder="Password (min 6 characters)"
                  value={password} onChange={e => setPassword(e.target.value)}
                  style={{ ...inp, paddingRight:'44px' }}
                  onFocus={e => e.target.style.borderColor='#0A84FF'}
                  onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
                <button type="button" onClick={() => setShowPass(!showPass)}
                        style={{ position:'absolute', right:'12px', top:'50%',
                                 transform:'translateY(-50%)', background:'none',
                                 border:'none', cursor:'pointer', fontSize:'16px' }}>
                  {showPass ? '🙈' : '👁️'}
                </button>
              </div>
              <input type="password" placeholder="Confirm password"
                     value={confirm} onChange={e => setConfirm(e.target.value)}
                     style={inp}
                     onFocus={e => e.target.style.borderColor='#0A84FF'}
                     onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
              <button type="submit" disabled={loading}
                      style={{ ...btn, opacity: loading ? 0.6 : 1 }}>
                {loading ? 'Creating account...' : 'Create Account →'}
              </button>
            </form>
          )}

          {/* RESET */}
          {mode === 'reset' && (
            <form onSubmit={handleReset}
                  style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
              <input type="email" placeholder="Your email address"
                     value={email} onChange={e => setEmail(e.target.value)}
                     style={inp}
                     onFocus={e => e.target.style.borderColor='#0A84FF'}
                     onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
              <button type="submit" disabled={loading}
                      style={{ ...btn, opacity: loading ? 0.6 : 1 }}>
                {loading ? 'Sending...' : 'Send Reset Email →'}
              </button>
            </form>
          )}

          {/* Switch mode links */}
          <div style={{ textAlign:'center', marginTop:'24px',
                        fontSize:'14px', color:'var(--text-secondary)' }}>
            {mode === 'login' && (
              <>Don't have an account?{' '}
                <button onClick={() => switchMode('signup')}
                        style={{ background:'none', border:'none', cursor:'pointer',
                                 color:'#0A84FF', fontWeight:'600', fontSize:'14px' }}>
                  Sign up free
                </button>
              </>
            )}
            {mode === 'signup' && (
              <>Already have an account?{' '}
                <button onClick={() => switchMode('login')}
                        style={{ background:'none', border:'none', cursor:'pointer',
                                 color:'#0A84FF', fontWeight:'600', fontSize:'14px' }}>
                  Sign in
                </button>
              </>
            )}
            {mode === 'reset' && (
              <button onClick={() => switchMode('login')}
                      style={{ background:'none', border:'none', cursor:'pointer',
                               color:'#0A84FF', fontWeight:'600', fontSize:'14px' }}>
                ← Back to sign in
              </button>
            )}
          </div>
        </div>

        {/* Terms */}
        <p style={{ color:'var(--text-muted)', fontSize:'12px',
                    textAlign:'center', marginTop:'20px', maxWidth:'360px' }}>
          By continuing you agree to SignBridge's Terms of Use and Privacy Policy.
        </p>
      </div>
    </div>
  )
}