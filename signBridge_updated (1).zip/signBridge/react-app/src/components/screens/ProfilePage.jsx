// src/components/screens/ProfilePage.jsx
import { useState, useRef } from 'react'
import { useNavigate }      from 'react-router-dom'
import {
  updateProfile,
  updatePassword,
  deleteUser,
  EmailAuthProvider,
  reauthenticateWithCredential,
  sendEmailVerification,
} from 'firebase/auth'
import { auth }          from '../../firebase'
import { useAuth }       from '../../context/AuthContext'
import { useTheme }      from '../../context/ThemeContext'
import ThemeToggle       from '../ThemeToggle'

export default function ProfilePage() {
  const navigate            = useNavigate()
  const { user, logout }    = useAuth()
  const { isDark }          = useTheme()

  // ── Editable fields ──
  const [displayName,  setDisplayName]  = useState(user?.displayName || '')
  const [newPassword,  setNewPassword]  = useState('')
  const [confirmPass,  setConfirmPass]  = useState('')
  const [currentPass,  setCurrentPass]  = useState('')
  const [defaultRole,  setDefaultRole]  = useState(
    localStorage.getItem('sb-default-role') || 'deaf'
  )

  // ── UI state ──
  const [editingName,  setEditingName]  = useState(false)
  const [showPassForm, setShowPassForm] = useState(false)
  const [showDelete,   setShowDelete]   = useState(false)
  const [deleteConfirm,setDeleteConfirm]= useState('')
  const [showCurrPass, setShowCurrPass] = useState(false)
  const [showNewPass,  setShowNewPass]  = useState(false)
  const [loading,      setLoading]      = useState('')
  const [success,      setSuccess]      = useState('')
  const [error,        setError]        = useState('')

  const nameInputRef = useRef(null)

  const isGoogleUser = user?.providerData?.[0]?.providerId === 'google.com'

  const joined = user?.metadata?.creationTime
    ? new Date(user.metadata.creationTime).toLocaleDateString('en-US', {
        month: 'long', year: 'numeric'
      })
    : 'Unknown'

  const showMessage = (type, msg) => {
    if (type === 'success') { setSuccess(msg); setError('') }
    else                    { setError(msg);   setSuccess('') }
    setTimeout(() => { setSuccess(''); setError('') }, 4000)
  }

  // ── Update display name ──
  const handleSaveName = async () => {
    if (!displayName.trim()) { showMessage('error', 'Name cannot be empty.'); return }
    setLoading('name')
    try {
      await updateProfile(auth.currentUser, { displayName: displayName.trim() })
      showMessage('success', 'Name updated successfully!')
      setEditingName(false)
    } catch (e) {
      showMessage('error', 'Failed to update name. Please try again.')
    } finally {
      setLoading('')
    }
  }

  // ── Change password ──
  const handleChangePassword = async (e) => {
    e.preventDefault()
    if (!currentPass)              { showMessage('error', 'Enter your current password.'); return }
    if (newPassword.length < 6)    { showMessage('error', 'New password must be at least 6 characters.'); return }
    if (newPassword !== confirmPass){ showMessage('error', 'Passwords do not match.'); return }
    setLoading('password')
    try {
      const credential = EmailAuthProvider.credential(user.email, currentPass)
      await reauthenticateWithCredential(auth.currentUser, credential)
      await updatePassword(auth.currentUser, newPassword)
      showMessage('success', 'Password changed successfully!')
      setShowPassForm(false)
      setCurrentPass(''); setNewPassword(''); setConfirmPass('')
    } catch (e) {
      if (e.code === 'auth/wrong-password' || e.code === 'auth/invalid-credential') {
        showMessage('error', 'Current password is incorrect.')
      } else {
        showMessage('error', 'Failed to change password. Please try again.')
      }
    } finally {
      setLoading('')
    }
  }

  // ── Send email verification ──
  const handleVerifyEmail = async () => {
    setLoading('verify')
    try {
      await sendEmailVerification(auth.currentUser)
      showMessage('success', 'Verification email sent! Check your inbox.')
    } catch (e) {
      showMessage('error', 'Failed to send verification email.')
    } finally {
      setLoading('')
    }
  }

  // ── Save default role ──
  const handleRoleChange = (role) => {
    setDefaultRole(role)
    localStorage.setItem('sb-default-role', role)
    showMessage('success', 'Default role updated!')
  }

  // ── Delete account ──
  const handleDeleteAccount = async () => {
    if (deleteConfirm !== 'DELETE') {
      showMessage('error', 'Type DELETE to confirm.')
      return
    }
    setLoading('delete')
    try {
      await deleteUser(auth.currentUser)
      navigate('/')
    } catch (e) {
      if (e.code === 'auth/requires-recent-login') {
        showMessage('error', 'Please log out and log back in before deleting your account.')
      } else {
        showMessage('error', 'Failed to delete account.')
      }
    } finally {
      setLoading('')
    }
  }

  // ── Logout ──
  const handleLogout = async () => {
    await logout()
    navigate('/')
  }

  // ── Styles ──
  const card = {
    background:   'var(--bg-card)',
    border:       '1px solid var(--border)',
    borderRadius: '20px',
    overflow:     'hidden',
    marginBottom: '12px',
  }

  const row = {
    display:        'flex',
    alignItems:     'center',
    justifyContent: 'space-between',
    padding:        '14px 20px',
    borderBottom:   '1px solid var(--border)',
  }

  const rowLast = { ...row, borderBottom: 'none' }

  const label = {
    fontSize:    '14px',
    color:       'var(--text-secondary)',
    display:     'flex',
    alignItems:  'center',
    gap:         '10px',
  }

  const value = {
    fontSize:   '14px',
    color:      'var(--text-primary)',
    fontWeight: '500',
  }

  const sectionTitle = {
    fontSize:     '11px',
    fontWeight:   '700',
    letterSpacing:'0.08em',
    textTransform:'uppercase',
    color:        'var(--text-muted)',
    padding:      '16px 4px 6px',
  }

  const inp = {
    background:   'var(--input-bg)',
    border:       '1px solid var(--input-border)',
    color:        'var(--input-text)',
    borderRadius: '10px',
    padding:      '10px 14px',
    fontSize:     '14px',
    outline:      'none',
    width:        '100%',
    boxSizing:    'border-box',
    transition:   'border-color 0.2s',
  }

  const initials = (user?.displayName || user?.email || '?')
    .charAt(0).toUpperCase()

  return (
    <div style={{
      position:   'fixed',
      inset:      0,
      overflowY:  'auto',
      background: 'var(--bg-secondary)',
      fontFamily: "'DM Sans', sans-serif",
      transition: 'background 0.3s',
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Serif+Display&display=swap"
            rel="stylesheet" />

      {/* ── HEADER ── */}
      <div style={{
        position:       'sticky',
        top:            0,
        zIndex:         10,
        display:        'flex',
        alignItems:     'center',
        justifyContent: 'space-between',
        padding:        '14px 20px',
        background:     'var(--header-bg)',
        borderBottom:   '1px solid var(--border)',
        backdropFilter: 'blur(12px)',
      }}>
        <button onClick={() => navigate('/app')}
                style={{ background:'none', border:'none', cursor:'pointer',
                         color:'var(--text-secondary)', fontSize:'14px',
                         display:'flex', alignItems:'center', gap:'6px' }}>
          ← Back
        </button>
        <span style={{ fontWeight:'700', fontSize:'16px', color:'var(--text-primary)' }}>
          Profile
        </span>
        <ThemeToggle />
      </div>

      {/* ── CONTENT ── */}
      <div style={{ maxWidth:'480px', margin:'0 auto', padding:'20px 16px 60px' }}>

        {/* ── AVATAR SECTION ── */}
        <div style={{
          ...card,
          display:       'flex',
          flexDirection: 'column',
          alignItems:    'center',
          padding:       '32px 20px',
          marginBottom:  '12px',
          background:    isDark
            ? 'linear-gradient(135deg, rgba(10,132,255,0.08), rgba(0,198,255,0.05))'
            : 'linear-gradient(135deg, rgba(10,132,255,0.06), rgba(0,198,255,0.03))',
        }}>
          {/* Avatar */}
          <div style={{
            width:'88px', height:'88px', borderRadius:'50%',
            background:'linear-gradient(135deg,#0A84FF,#00C6FF)',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:'36px', fontWeight:'800', color:'white',
            boxShadow:'0 8px 32px rgba(10,132,255,0.35)',
            marginBottom:'16px', position:'relative',
            border:'3px solid var(--bg-card)',
          }}>
            {user?.photoURL
              ? <img src={user.photoURL} alt="avatar"
                     style={{ width:'100%', height:'100%', borderRadius:'50%', objectFit:'cover' }} />
              : initials
            }
            {/* Provider badge */}
            <div style={{
              position:'absolute', bottom:0, right:0,
              width:'24px', height:'24px', borderRadius:'50%',
              background: isGoogleUser ? 'white' : '#0A84FF',
              border:'2px solid var(--bg-card)',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontSize:'12px',
            }}>
              {isGoogleUser ? (
                <svg width="14" height="14" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                </svg>
              ) : '✉️'}
            </div>
          </div>

          {/* Name */}
          <h2 style={{ margin:'0 0 4px', fontSize:'20px', fontWeight:'700',
                       color:'var(--text-primary)',
                       fontFamily:"'DM Serif Display', serif" }}>
            {user?.displayName || 'No name set'}
          </h2>
          <p style={{ margin:'0 0 8px', fontSize:'14px', color:'var(--text-secondary)' }}>
            {user?.email}
          </p>
          <div style={{ display:'flex', alignItems:'center', gap:'12px' }}>
            <span style={{
              fontSize:'12px', color:'var(--text-muted)',
              background:'var(--pill-bg)', border:'1px solid var(--border)',
              padding:'3px 10px', borderRadius:'20px',
            }}>
              Joined {joined}
            </span>
            {/* Email verified badge */}
            <span style={{
              fontSize:'12px',
              background: user?.emailVerified ? '#30D15820' : '#FF9F0A20',
              color:       user?.emailVerified ? '#30D158'   : '#FF9F0A',
              border:      `1px solid ${user?.emailVerified ? '#30D15840' : '#FF9F0A40'}`,
              padding:'3px 10px', borderRadius:'20px',
            }}>
              {user?.emailVerified ? '✓ Verified' : '⚠ Unverified'}
            </span>
          </div>
        </div>

        {/* ── GLOBAL MESSAGES ── */}
        {success && (
          <div style={{
            background:'#30D15815', border:'1px solid #30D15840', color:'#30D158',
            borderRadius:'12px', padding:'12px 16px', fontSize:'13px',
            marginBottom:'12px', display:'flex', gap:'8px',
          }}>
            <span>✓</span><span>{success}</span>
          </div>
        )}
        {error && (
          <div style={{
            background:'#FF453A15', border:'1px solid #FF453A40', color:'#FF453A',
            borderRadius:'12px', padding:'12px 16px', fontSize:'13px',
            marginBottom:'12px', display:'flex', gap:'8px',
          }}>
            <span>⚠️</span><span>{error}</span>
          </div>
        )}

        {/* ── ACCOUNT SECTION ── */}
        <p style={sectionTitle}>Account</p>
        <div style={card}>

          {/* Display name */}
          <div style={row}>
            <span style={label}><span>👤</span> Display Name</span>
            {editingName ? (
              <div style={{ display:'flex', gap:'8px', alignItems:'center', flex:1, marginLeft:'16px' }}>
                <input
                  ref={nameInputRef}
                  value={displayName}
                  onChange={e => setDisplayName(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSaveName()}
                  style={{ ...inp, padding:'7px 12px' }}
                  autoFocus
                  onFocus={e => e.target.style.borderColor='#0A84FF'}
                  onBlur={e  => e.target.style.borderColor='var(--input-border)'}
                />
                <button onClick={handleSaveName} disabled={loading === 'name'}
                        style={{ background:'#0A84FF', color:'white', border:'none',
                                 borderRadius:'8px', padding:'7px 14px', cursor:'pointer',
                                 fontSize:'13px', fontWeight:'600', whiteSpace:'nowrap' }}>
                  {loading === 'name' ? '...' : 'Save'}
                </button>
                <button onClick={() => { setEditingName(false); setDisplayName(user?.displayName || '') }}
                        style={{ background:'var(--pill-bg)', color:'var(--text-secondary)',
                                 border:'1px solid var(--border)', borderRadius:'8px',
                                 padding:'7px 10px', cursor:'pointer', fontSize:'13px' }}>
                  ✕
                </button>
              </div>
            ) : (
              <div style={{ display:'flex', alignItems:'center', gap:'10px' }}>
                <span style={value}>{user?.displayName || '—'}</span>
                <button onClick={() => setEditingName(true)}
                        style={{ background:'none', border:'none', cursor:'pointer',
                                 color:'#0A84FF', fontSize:'13px', fontWeight:'600' }}>
                  Edit
                </button>
              </div>
            )}
          </div>

          {/* Email */}
          <div style={row}>
            <span style={label}><span>✉️</span> Email</span>
            <span style={{ ...value, fontSize:'13px', color:'var(--text-secondary)' }}>
              {user?.email}
            </span>
          </div>

          {/* Email verification */}
          {!user?.emailVerified && !isGoogleUser && (
            <div style={row}>
              <span style={label}><span>🔔</span> Email Verification</span>
              <button onClick={handleVerifyEmail} disabled={loading === 'verify'}
                      style={{ background:'none', border:'none', cursor:'pointer',
                               color:'#FF9F0A', fontSize:'13px', fontWeight:'600' }}>
                {loading === 'verify' ? 'Sending...' : 'Send verification →'}
              </button>
            </div>
          )}

          {/* Login provider */}
          <div style={row}>
            <span style={label}><span>🔐</span> Login Method</span>
            <span style={{ ...value, fontSize:'13px' }}>
              {isGoogleUser ? 'Google Account' : 'Email & Password'}
            </span>
          </div>

          {/* Change password — email users only */}
          {!isGoogleUser && (
            <div style={{ borderTop:'1px solid var(--border)' }}>
              <div style={rowLast}>
                <span style={label}><span>🔑</span> Password</span>
                <button onClick={() => setShowPassForm(!showPassForm)}
                        style={{ background:'none', border:'none', cursor:'pointer',
                                 color:'#0A84FF', fontSize:'13px', fontWeight:'600' }}>
                  {showPassForm ? 'Cancel' : 'Change →'}
                </button>
              </div>
              {showPassForm && (
                <form onSubmit={handleChangePassword}
                      style={{ padding:'0 20px 20px',
                               display:'flex', flexDirection:'column', gap:'10px' }}>
                  <div style={{ position:'relative' }}>
                    <input type={showCurrPass ? 'text' : 'password'}
                           placeholder="Current password"
                           value={currentPass} onChange={e => setCurrentPass(e.target.value)}
                           style={{ ...inp, paddingRight:'40px' }}
                           onFocus={e => e.target.style.borderColor='#0A84FF'}
                           onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
                    <button type="button" onClick={() => setShowCurrPass(!showCurrPass)}
                            style={{ position:'absolute', right:'10px', top:'50%',
                                     transform:'translateY(-50%)', background:'none',
                                     border:'none', cursor:'pointer' }}>
                      {showCurrPass ? '🙈' : '👁️'}
                    </button>
                  </div>
                  <div style={{ position:'relative' }}>
                    <input type={showNewPass ? 'text' : 'password'}
                           placeholder="New password (min 6 chars)"
                           value={newPassword} onChange={e => setNewPassword(e.target.value)}
                           style={{ ...inp, paddingRight:'40px' }}
                           onFocus={e => e.target.style.borderColor='#0A84FF'}
                           onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
                    <button type="button" onClick={() => setShowNewPass(!showNewPass)}
                            style={{ position:'absolute', right:'10px', top:'50%',
                                     transform:'translateY(-50%)', background:'none',
                                     border:'none', cursor:'pointer' }}>
                      {showNewPass ? '🙈' : '👁️'}
                    </button>
                  </div>
                  <input type="password" placeholder="Confirm new password"
                         value={confirmPass} onChange={e => setConfirmPass(e.target.value)}
                         style={inp}
                         onFocus={e => e.target.style.borderColor='#0A84FF'}
                         onBlur={e  => e.target.style.borderColor='var(--input-border)'} />
                  <button type="submit" disabled={loading === 'password'}
                          style={{ background:'linear-gradient(135deg,#0A84FF,#00C6FF)',
                                   color:'white', border:'none', borderRadius:'10px',
                                   padding:'11px', fontSize:'14px', fontWeight:'600',
                                   cursor:'pointer', opacity: loading === 'password' ? 0.6 : 1 }}>
                    {loading === 'password' ? 'Updating...' : 'Update Password'}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        {/* ── PREFERENCES SECTION ── */}
        <p style={sectionTitle}>Preferences</p>
        <div style={card}>

          {/* Default role */}
          <div style={row}>
            <span style={label}><span>🤟</span> Default Role</span>
            <div style={{ display:'flex', gap:'6px' }}>
              {['deaf', 'hearing'].map(r => (
                <button key={r} onClick={() => handleRoleChange(r)}
                        style={{
                          padding:'5px 12px', borderRadius:'8px', cursor:'pointer',
                          fontSize:'12px', fontWeight:'600', border:'none',
                          background: defaultRole === r
                            ? 'linear-gradient(135deg,#0A84FF,#00C6FF)'
                            : 'var(--pill-bg)',
                          color: defaultRole === r ? 'white' : 'var(--text-secondary)',
                          border: defaultRole === r ? 'none' : '1px solid var(--border)',
                        }}>
                  {r === 'deaf' ? '🤟 Deaf' : '🎤 Hearing'}
                </button>
              ))}
            </div>
          </div>

          {/* Theme */}
          <div style={rowLast}>
            <span style={label}><span>🎨</span> Theme</span>
            <ThemeToggle />
          </div>
        </div>

        {/* ── PRIVACY & SECURITY ── */}
        <p style={sectionTitle}>Privacy & Security</p>
        <div style={card}>
          <div style={row}>
            <span style={label}><span>📷</span> Camera Data</span>
            <span style={{ fontSize:'12px', color:'#30D158', fontWeight:'600' }}>
              Never stored
            </span>
          </div>
          <div style={row}>
            <span style={label}><span>🔒</span> Sign Data</span>
            <span style={{ fontSize:'12px', color:'#30D158', fontWeight:'600' }}>
              Processed locally
            </span>
          </div>
          <div style={rowLast}>
            <span style={label}><span>☁️</span> Data Sharing</span>
            <span style={{ fontSize:'12px', color:'#30D158', fontWeight:'600' }}>
              Never shared
            </span>
          </div>
        </div>

        {/* ── ABOUT ── */}
        <p style={sectionTitle}>About</p>
        <div style={card}>
          <div style={row}>
            <span style={label}><span>📱</span> App Version</span>
            <span style={value}>1.0.0</span>
          </div>
          <div style={row}>
            <span style={label}><span>🤖</span> AI Model</span>
            <span style={value}>99.13% accuracy</span>
          </div>
          <div style={rowLast}>
            <span style={label}><span>✋</span> Signs Supported</span>
            <span style={value}>29 ASL signs</span>
          </div>
        </div>

        {/* ── ACCOUNT ACTIONS ── */}
        <p style={sectionTitle}>Account Actions</p>

        {/* Logout */}
        <button onClick={handleLogout}
                style={{
                  width:'100%', padding:'14px', borderRadius:'14px',
                  border:'1px solid var(--border)', background:'var(--bg-card)',
                  color:'var(--text-primary)', fontSize:'14px', fontWeight:'600',
                  cursor:'pointer', marginBottom:'10px',
                  display:'flex', alignItems:'center', justifyContent:'center', gap:'8px',
                  transition:'all 0.2s',
                }}>
          🚪 Log Out
        </button>

        {/* Delete account */}
        <button onClick={() => setShowDelete(!showDelete)}
                style={{
                  width:'100%', padding:'14px', borderRadius:'14px',
                  border:'1px solid #FF453A40', background:'#FF453A10',
                  color:'#FF453A', fontSize:'14px', fontWeight:'600',
                  cursor:'pointer', marginBottom: showDelete ? '0' : '0',
                  display:'flex', alignItems:'center', justifyContent:'center', gap:'8px',
                }}>
          🗑️ Delete Account
        </button>

        {/* Delete confirmation */}
        {showDelete && (
          <div style={{
            background:'#FF453A08', border:'1px solid #FF453A30',
            borderTop:'none', borderRadius:'0 0 14px 14px',
            padding:'16px', marginBottom:'0',
          }}>
            <p style={{ color:'var(--text-secondary)', fontSize:'13px',
                        margin:'0 0 12px', lineHeight:'1.5' }}>
              This will permanently delete your account and all associated data.
              This action <strong>cannot be undone</strong>. Type <strong>DELETE</strong> to confirm.
            </p>
            <input
              type="text" placeholder='Type DELETE to confirm'
              value={deleteConfirm} onChange={e => setDeleteConfirm(e.target.value)}
              style={{ ...inp, marginBottom:'10px',
                       borderColor: deleteConfirm === 'DELETE' ? '#FF453A' : 'var(--input-border)' }}
              onFocus={e => e.target.style.borderColor='#FF453A'}
              onBlur={e  => e.target.style.borderColor= deleteConfirm === 'DELETE' ? '#FF453A' : 'var(--input-border)'}
            />
            <button onClick={handleDeleteAccount}
                    disabled={deleteConfirm !== 'DELETE' || loading === 'delete'}
                    style={{
                      width:'100%', padding:'12px', borderRadius:'10px', border:'none',
                      background: deleteConfirm === 'DELETE' ? '#FF453A' : 'var(--pill-bg)',
                      color: deleteConfirm === 'DELETE' ? 'white' : 'var(--text-muted)',
                      fontSize:'14px', fontWeight:'600', cursor:'pointer',
                      opacity: loading === 'delete' ? 0.6 : 1,
                    }}>
              {loading === 'delete' ? 'Deleting...' : 'Permanently Delete Account'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}