// src/components/screens/MeetingScreen.jsx
import { useState, useEffect, useRef, useCallback } from 'react'
import { useCamera }    from '../../hooks/useCamera'
import { useMediaPipe } from '../../hooks/useMediaPipe'
import { useSignModel } from '../../hooks/useSignModel'
import { useLanguage }  from '../../context/LanguageContext'
import LanguageSelector from '../LanguageSelector'
import { useSpeech }    from '../../hooks/useSpeech'
import { usePeerCall }  from '../../hooks/usePeerCall'
import { WordBuilder }  from '../../utils/wordBuilder'
import ThemeToggle      from '../ThemeToggle'
import { useTheme }     from '../../context/ThemeContext'

export default function MeetingScreen({ role, roomCode: initialRoomCode, onGoHome }) {
  const { isDark, setTheme } = useTheme()

  // Force dark theme for better hand detection contrast
  // Restore saved preference when user leaves meeting
  useEffect(() => {
    const saved = localStorage.getItem('sb-theme') || 'light'
    setTheme('dark')
    return () => setTheme(saved)
  }, [])
  const camera    = useCamera()
  const { languageId } = useLanguage()
  const signModel = useSignModel(languageId)
  const speech    = useSpeech()
  const peer      = usePeerCall()

  const [messages,       setMessages]       = useState([])
  const [currentWord,    setCurrentWord]    = useState('')
  const [currentSent,    setCurrentSent]    = useState('')
  const [isSigning,      setIsSigning]      = useState(false)
  const [detectedLetter, setDetectedLetter] = useState(null)
  const [landmarks,      setLandmarks]      = useState(null)
  const [isMuted,        setIsMuted]        = useState(false)
  const [isCameraOff,    setIsCameraOff]    = useState(false)
  const [showChat,       setShowChat]       = useState(true)
  const [remoteWord,     setRemoteWord]     = useState('')
  const [remoteSent,     setRemoteSent]     = useState('')
  const [copied,         setCopied]         = useState(false)
  const [isListening,    setIsListening]    = useState(false)

  const wordBuilderRef = useRef(null)
  const canvasRef      = useRef(null)
  const chatBottomRef  = useRef(null)
  const signingRef     = useRef(false)
  const lastSendRef    = useRef(0)

  useEffect(() => {
    wordBuilderRef.current = new WordBuilder((state) => {
      setCurrentWord(state.currentWord)
      setCurrentSent(state.sentence)
      peer.sendWordUpdate(state.currentWord, state.sentence)
    })
    signModel.loadModel()
    peer.setOnRemoteSign((msg) => {
      if (msg.type === 'word_update') {
        setRemoteWord(msg.currentWord || '')
        setRemoteSent(msg.sentence    || '')
      }
    })
    peer.setOnRemoteMessage((msg) => {
      setMessages(prev => [...prev, { ...msg, fromRemote: true }])
      if (msg.role === 'deaf') speech.speak(msg.text)
    })
    if (initialRoomCode) peer.joinRoom(initialRoomCode, role)
    else                 peer.createRoom(role)
  }, [])

  useEffect(() => {
    if (camera.videoRef.current && peer.localVideoRef)
      peer.localVideoRef.current = camera.videoRef.current
  }, [camera.videoRef.current])

  const startEverything = useCallback(async () => {
    await Promise.all([camera.startCamera(), mediapipe.loadMediaPipe()])
  }, [])

  useEffect(() => { startEverything() }, [])

  const handleLandmarks = useCallback((lms) => {
    setLandmarks(lms)
    drawLandmarks(lms)
    if (!signingRef.current || !signModel.isLoaded) return
    const result = signModel.predict(lms)
    if (!result) return
    setDetectedLetter({
      letter:     result.letter,
      confidence: result.confidence,
      isValid:    result.isValid,
      isNothing:  result.isNothing,
    })
    wordBuilderRef.current?.process(result)
    if (result.isDel && result.isStable) wordBuilderRef.current?.deleteLastChar()
    const now = Date.now()
    if (now - lastSendRef.current > 100) {
      peer.sendSign({ letter: result.letter, confidence: result.confidence,
                      isValid: result.isValid, isNothing: result.isNothing })
      lastSendRef.current = now
    }
  }, [signModel.isLoaded, signModel.predict])

  const handleNoHand = useCallback(() => {
    setLandmarks(null); setDetectedLetter(null); clearCanvas()
    wordBuilderRef.current?.process({ isNothing: true, isValid: false })
  }, [])

  const mediapipe = useMediaPipe({ onLandmarks: handleLandmarks, onNoHand: handleNoHand, numHands: signModel.numHands || 1 })

  useEffect(() => {
    if (camera.isActive && mediapipe.isLoaded && camera.videoRef.current)
      mediapipe.startDetection(camera.videoRef.current)
  }, [camera.isActive, mediapipe.isLoaded])

  useEffect(() => () => {
    camera.cleanup(); mediapipe.stopDetection(); peer.endCall()
  }, [])

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Draws one hand's 21-point skeleton onto an already-sized canvas.
  // Extracted so multi-hand languages (ISL/BSL) can call it once per
  // detected hand — single-hand languages (ASL) still draw exactly
  // the same pixels as before via the one-hand branch below.
  const drawHandSkeleton = (ctx, hand, W, H) => {
    const connections = [
      [0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],
      [0,9],[9,10],[10,11],[11,12],[0,13],[13,14],[14,15],[15,16],
      [0,17],[17,18],[18,19],[19,20],[5,9],[9,13],[13,17],
    ]
    ctx.strokeStyle = '#0A84FF99'; ctx.lineWidth = 1.5
    for (const [a,b] of connections) {
      ctx.beginPath()
      ctx.moveTo((1-hand[a].x)*W, hand[a].y*H)
      ctx.lineTo((1-hand[b].x)*W, hand[b].y*H)
      ctx.stroke()
    }
    for (let i = 0; i < hand.length; i++) {
      const isTip = [4,8,12,16,20].includes(i)
      ctx.fillStyle = isTip ? '#0A84FF' : '#0A84FF77'
      ctx.beginPath()
      ctx.arc((1-hand[i].x)*W, hand[i].y*H, isTip ? 4 : 2, 0, Math.PI*2)
      ctx.fill()
    }
  }

  const drawLandmarks = (lms) => {
    const canvas = canvasRef.current
    const video  = camera.videoRef.current
    if (!canvas || !video || !lms) return
    const ctx = canvas.getContext('2d')
    canvas.width  = video.videoWidth  || 320
    canvas.height = video.videoHeight || 240
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    const W = canvas.width, H = canvas.height

    // Two-hand languages (numHands > 1) receive an array of hands from
    // useMediaPipe; single-hand languages (ASL) receive one hand's
    // 21-point array directly — same shape/behavior as before.
    if (signModel.numHands > 1 && Array.isArray(lms[0])) {
      for (const hand of lms) {
        if (hand) drawHandSkeleton(ctx, hand, W, H)
      }
    } else {
      drawHandSkeleton(ctx, lms, W, H)
    }
  }

  const clearCanvas = () => {
    const c = canvasRef.current
    if (c) c.getContext('2d')?.clearRect(0, 0, c.width, c.height)
  }

  const toggleSigning = () => {
    const next = !isSigning
    setIsSigning(next); signingRef.current = next
    if (!next) {
      const state = wordBuilderRef.current?.getState()
      if (state?.fullText) sendMessage()
    }
  }

  const sendMessage = () => {
    const state = wordBuilderRef.current?.getState()
    const text  = state?.fullText?.trim()
    if (!text) return
    const msg = {
      id: Date.now(), role, text, fromRemote: false,
      timestamp: new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
    }
    setMessages(prev => [...prev, msg])
    peer.sendMessage(text, role)
    if (role === 'deaf') speech.speak(text)
    wordBuilderRef.current?.clear()
    setCurrentWord(''); setCurrentSent('')
    setRemoteWord(''); setRemoteSent('')
    signModel.resetBuffer()
  }

  const toggleListening = () => {
    if (isListening) {
      speech.stopListening(); setIsListening(false)
      const text = speech.transcript?.trim()
      if (text) {
        const msg = {
          id: Date.now(), role: 'hearing', text, fromRemote: false,
          timestamp: new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
        }
        setMessages(prev => [...prev, msg])
        peer.sendMessage(text, 'hearing')
        speech.clearTranscript()
      }
    } else {
      speech.startListening(); setIsListening(true)
    }
  }

  const toggleMute = () => {
    const tracks = camera.videoRef.current?.srcObject?.getAudioTracks() || []
    tracks.forEach(t => { t.enabled = isMuted })
    setIsMuted(!isMuted)
  }

  const toggleCamera = () => {
    const tracks = camera.videoRef.current?.srcObject?.getVideoTracks() || []
    tracks.forEach(t => { t.enabled = isCameraOff })
    setIsCameraOff(!isCameraOff)
  }

  const copyRoomCode = () => {
    if (peer.roomCode) {
      navigator.clipboard.writeText(peer.roomCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const isConnected = peer.status === 'connected'
  const isHosting   = !initialRoomCode
  const confColor   = (c) => c >= 0.9 ? '#30D158' : c >= 0.7 ? '#FF9F0A' : '#FF453A'

  // ── Theme helpers ──
  const headerBg  = isDark ? 'rgba(10,10,12,0.95)'  : 'rgba(255,255,255,0.95)'
  const sidebarBg = isDark ? 'rgba(18,18,20,0.98)'  : 'rgba(248,250,255,0.98)'
  const panelBg   = isDark ? 'rgba(28,28,30,0.98)'  : 'rgba(248,250,255,0.98)'
  const ctrlBg    = isDark ? 'rgba(10,10,12,0.98)'  : 'rgba(255,255,255,0.98)'
  const btnIdle   = isDark ? '#2C2C2E'               : '#F3F4F6'
  const btnText   = isDark ? '#F2F2F7'               : '#374151'

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden"
         style={{ background: '#000', transition: 'background 0.3s' }}>

      {/* ── HEADER ── */}
      <header className="flex items-center justify-between px-4 py-2.5
                         border-b flex-shrink-0 z-20"
              style={{ background: headerBg, borderColor: 'var(--header-border)',
                       backdropFilter: 'blur(12px)' }}>
        <div className="flex items-center gap-3">
          <button
            onClick={() => { peer.endCall(); onGoHome() }}
            className="w-9 h-9 rounded-full flex items-center justify-center
                       transition-all hover:scale-110 text-base font-bold"
            style={{ background: isDark ? 'rgba(99,99,102,0.2)' : 'rgba(0,0,0,0.06)',
                     color: isDark ? '#F2F2F7' : '#374151',
                     border: `1px solid ${isDark ? 'rgba(99,99,102,0.3)' : 'rgba(0,0,0,0.1)'}` }}
          >
            ←
          </button>
          <div className="flex items-center gap-2">
            <span className="text-lg">📹</span>
            <div>
              <h1 className="font-semibold text-sm leading-none"
                  style={{ color: 'var(--text-primary)' }}>Meeting</h1>
              <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                {role === 'deaf' ? '🤟 Deaf Mode' : '🎤 Hearing Mode'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Connection status */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs"
               style={{
                 background: isConnected ? '#30D15820' : '#FF9F0A20',
                 border:     `1px solid ${isConnected ? '#30D15850' : '#FF9F0A50'}`,
               }}>
            <div className={`w-1.5 h-1.5 rounded-full ${
              isConnected ? 'bg-[#30D158]' : 'bg-[#FF9F0A] animate-pulse'}`} />
            <span style={{ color: isConnected ? '#30D158' : '#FF9F0A' }}>
              {peer.status === 'creating'   && 'Creating...'}
              {peer.status === 'waiting'    && 'Waiting for guest'}
              {peer.status === 'connecting' && 'Connecting...'}
              {peer.status === 'connected'  && 'Connected'}
              {peer.status === 'error'      && 'Error'}
              {peer.status === 'ended'      && 'Call ended'}
              {peer.status === 'idle'       && 'Idle'}
            </span>
          </div>

          {peer.roomCode && (
            <button
              onClick={copyRoomCode}
              className="flex items-center gap-2 px-3 py-1 rounded-full
                         transition-all text-xs border"
              style={{ background: 'var(--pill-bg)', borderColor: 'var(--pill-border)' }}
            >
              <span style={{ color: 'var(--text-muted)' }}>Room:</span>
              <span className="font-mono font-bold tracking-wider"
                    style={{ color: 'var(--text-primary)' }}>
                {peer.roomCode}
              </span>
              <span style={{ color: 'var(--text-muted)' }}>{copied ? '✓' : '⧉'}</span>
            </button>
          )}

          <button
            onClick={() => setShowChat(!showChat)}
            className="w-8 h-8 rounded-full flex items-center justify-center
                       transition-all text-sm"
            style={{
              background: showChat ? '#0A84FF20' : 'var(--pill-bg)',
              color:      showChat ? '#0A84FF'   : 'var(--text-muted)',
              border:     `1px solid ${showChat ? '#0A84FF40' : 'var(--pill-border)'}`,
            }}
          >
            💬
          </button>

        </div>
      </header>

      {/* ── BODY ── */}
      <div className="flex-1 flex overflow-hidden relative">

        {/* VIDEO AREA */}
        <div className="flex-1 relative bg-black">

          {/* Remote video */}
          <video ref={peer.remoteVideoRef}
                 className="w-full h-full object-cover"
                 playsInline autoPlay />

          {/* Waiting/status overlay */}
          {!isConnected && (
            <div className="absolute inset-0 flex flex-col items-center
                            justify-center gap-6 bg-black/85">
              {peer.status === 'waiting' && (
                <div className="text-center space-y-4">
                  <div className="text-6xl animate-bounce-subtle">👋</div>
                  <h2 className="text-white text-xl font-bold">
                    Waiting for someone to join
                  </h2>
                  <p className="text-gray-400 text-sm">
                    Share this room code:
                  </p>
                  <button
                    onClick={copyRoomCode}
                    className="mx-auto flex items-center gap-3 px-8 py-4
                               rounded-2xl border-2 border-[#0A84FF]/50
                               bg-[#0A84FF]/10 hover:bg-[#0A84FF]/20 transition-all"
                  >
                    <span className="text-white font-mono font-bold
                                     text-3xl tracking-[0.3em]">
                      {peer.roomCode}
                    </span>
                    <span className="text-[#0A84FF] text-sm">
                      {copied ? '✓ Copied!' : '⧉ Copy'}
                    </span>
                  </button>
                  <p className="text-gray-500 text-xs">
                    They go to SignBridge → Meeting Mode → Enter code
                  </p>
                </div>
              )}

              {(peer.status === 'connecting' || peer.status === 'creating') && (
                <div className="text-center space-y-4">
                  <div className="w-12 h-12 border-2 border-[#0A84FF]
                                  border-t-transparent rounded-full
                                  animate-spin mx-auto" />
                  <p className="text-white font-semibold">
                    {peer.status === 'creating' ? 'Setting up room...' : 'Connecting...'}
                  </p>
                </div>
              )}

              {peer.status === 'error' && (
                <div className="text-center space-y-4 max-w-sm px-6">
                  <div className="text-5xl">⚠️</div>
                  <p className="text-[#FF453A] font-semibold">{peer.error}</p>
                  <div className="flex gap-3 justify-center">
                    <button
                      onClick={() => isHosting
                        ? peer.createRoom(role)
                        : peer.joinRoom(initialRoomCode, role)}
                      className="px-5 py-2 rounded-xl text-white text-sm font-semibold"
                      style={{ background: '#0A84FF' }}
                    >
                      Retry
                    </button>
                    <button
                      onClick={() => { peer.endCall(); onGoHome() }}
                      className="px-5 py-2 rounded-xl text-sm font-semibold border"
                      style={{ color: 'var(--text-primary)',
                               borderColor: 'var(--border)',
                               background: 'var(--bg-secondary)' }}
                    >
                      Go Home
                    </button>
                  </div>
                </div>
              )}

              {peer.status === 'ended' && (
                <div className="text-center space-y-4">
                  <div className="text-5xl">👋</div>
                  <p className="text-white font-semibold">Call ended</p>
                  <button
                    onClick={() => { peer.endCall(); onGoHome() }}
                    className="px-5 py-2 rounded-xl text-white text-sm font-semibold"
                    style={{ background: '#0A84FF' }}
                  >
                    Go Home
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Remote sign translation overlay */}
          {isConnected && (remoteSent || remoteWord) && (
            <div className="absolute bottom-20 left-4 max-w-[280px]
                            px-4 py-3 rounded-2xl"
                 style={{ background: 'rgba(0,0,0,0.75)',
                          backdropFilter: 'blur(8px)',
                          border: '1px solid rgba(255,255,255,0.1)' }}>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs">🤟</span>
                <span className="text-gray-400 text-xs">Signing...</span>
              </div>
              <p className="font-mono text-sm text-white">
                <span className="text-gray-500">{remoteSent}</span>
                <span className="text-[#0A84FF]">{remoteWord}</span>
                <span className="animate-pulse text-[#0A84FF]">|</span>
              </p>
            </div>
          )}

          {/* Local PiP */}
          <div className="absolute bottom-4 right-4 w-32 h-24 rounded-xl
                          overflow-hidden border-2 shadow-2xl"
               style={{ borderColor: 'var(--border)',
                        background: isDark ? '#111' : '#222' }}>
            <video ref={camera.videoRef}
                   className="w-full h-full object-cover"
                   playsInline muted
                   style={{ transform: 'scaleX(-1)' }} />
            <canvas ref={canvasRef}
                    className="absolute inset-0 w-full h-full pointer-events-none" />
            {isCameraOff && (
              <div className="absolute inset-0 flex items-center justify-center"
                   style={{ background: isDark ? '#1C1C1E' : '#2C2C2C' }}>
                <span className="text-2xl opacity-30">📷</span>
              </div>
            )}
            {isSigning && (
              <div className="absolute top-1 left-1 w-2 h-2
                              rounded-full bg-[#0A84FF] animate-pulse" />
            )}
          </div>
        </div>

        {/* CHAT SIDEBAR */}
        {showChat && (
          <div className="w-72 flex flex-col border-l flex-shrink-0"
               style={{ background: sidebarBg, borderColor: 'var(--border)' }}>

            {/* Detection badge — deaf only */}
            {role === 'deaf' && (
              <div className="p-3 border-b space-y-2"
                   style={{ borderColor: 'var(--border)' }}>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl flex items-center
                                  justify-center text-2xl font-bold border-2
                                  transition-all duration-150 flex-shrink-0"
                       style={{
                         background:  detectedLetter?.isValid ? '#0A84FF15' : 'var(--bg-tertiary)',
                         borderColor: detectedLetter?.isValid ? '#0A84FF'   : 'var(--border)',
                         color:       detectedLetter?.isValid ? '#0A84FF'   : 'var(--text-muted)',
                       }}>
                    {!detectedLetter || detectedLetter.isNothing ? '—' : detectedLetter.letter}
                  </div>
                  <div className="space-y-1 flex-1 min-w-0">
                    <p className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>
                      {detectedLetter?.isValid ? 'Detected' : 'No sign'}
                    </p>
                    {detectedLetter && !detectedLetter.isNothing && (
                      <div className="flex items-center gap-1.5">
                        <div className="h-1.5 w-16 rounded-full overflow-hidden"
                             style={{ background: 'var(--confidence-bg)' }}>
                          <div className="h-full rounded-full transition-all"
                               style={{ width: `${detectedLetter.confidence*100}%`,
                                        background: confColor(detectedLetter.confidence) }} />
                        </div>
                        <span className="text-xs font-mono"
                              style={{ color: confColor(detectedLetter.confidence) }}>
                          {(detectedLetter.confidence*100).toFixed(0)}%
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="rounded-lg px-2.5 py-1.5 flex items-center gap-1.5"
                     style={{ background: 'var(--bg-tertiary)',
                              border: '1px solid var(--border)' }}>
                  <span className="text-xs flex-shrink-0" style={{ color: 'var(--text-muted)' }}>
                    Building:
                  </span>
                  <span className="text-xs font-mono font-semibold tracking-widest
                                   flex-1 overflow-hidden truncate">
                    <span style={{ color: 'var(--text-secondary)' }}>{currentSent}</span>
                    <span style={{ color: '#0A84FF' }}>{currentWord}</span>
                    {isSigning && <span className="animate-pulse" style={{ color: '#0A84FF' }}>|</span>}
                  </span>
                  {(currentWord || currentSent) && (
                    <button
                      onClick={() => wordBuilderRef.current?.deleteLastChar()}
                      className="text-xs hover:text-[#FF453A] transition-colors"
                      style={{ color: 'var(--text-muted)' }}
                    >⌫</button>
                  )}
                </div>
              </div>
            )}

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center
                                h-full gap-2 text-center py-8">
                  <div className="text-4xl opacity-20">💬</div>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                    Messages appear here
                  </p>
                </div>
              )}

              {messages.map(msg => (
                <div key={msg.id}
                     className={`flex flex-col gap-0.5
                       ${msg.fromRemote ? 'items-start' : 'items-end'}`}>
                  <div className="flex items-center gap-1 px-1">
                    <span className="text-xs">
                      {msg.role === 'deaf' ? '🤟' : '🎤'}
                    </span>
                    <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                      {msg.fromRemote ? 'Them' : 'You'}
                    </span>
                  </div>
                  <div className="px-3 py-2 rounded-2xl text-xs max-w-[85%]"
                       style={msg.fromRemote
                         ? { background: 'var(--bubble-deaf-bg)',
                             border: '1px solid var(--bubble-deaf-border)',
                             color: 'var(--bubble-deaf-text)' }
                         : { background: 'var(--bubble-hearing-bg)',
                             border: '1px solid var(--bubble-hearing-border)',
                             color: 'var(--bubble-hearing-text)' }
                       }>
                    <p className="leading-relaxed">{msg.text}</p>
                  </div>
                  <span className="text-xs px-1" style={{ color: 'var(--text-muted)' }}>
                    {msg.timestamp}
                  </span>
                </div>
              ))}
              <div ref={chatBottomRef} />
            </div>
          </div>
        )}
      </div>

      {/* ── CONTROL BAR ── */}
      <div className="flex-shrink-0 border-t px-4 py-3 flex items-center
                      justify-between gap-2 z-20"
           style={{ background: ctrlBg, borderColor: 'var(--border)' }}>

        {/* Left: sign / speak */}
        <div className="flex items-center gap-2">
          {role === 'deaf' && (
            <>
              <button
                onClick={toggleSigning}
                disabled={!signModel.isLoaded}
                className="flex items-center gap-2 px-4 py-2 rounded-2xl
                           font-semibold text-sm transition-all hover:scale-105
                           active:scale-95 disabled:opacity-40"
                style={{
                  background: isSigning
                    ? 'linear-gradient(135deg,#0A84FF,#0066CC)'
                    : btnIdle,
                  color: isSigning ? '#fff' : btnText,
                  boxShadow: isSigning ? '0 0 16px #0A84FF44' : 'none',
                }}
              >
                <span>{isSigning ? '⏹' : '🤟'}</span>
                <span>{isSigning ? 'Stop' : 'Sign'}</span>
                {isSigning && <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />}
              </button>

              <button
                onClick={sendMessage}
                disabled={!currentWord && !currentSent}
                className="w-10 h-10 rounded-full flex items-center justify-center
                           text-white transition-all hover:scale-110 active:scale-95
                           disabled:opacity-40"
                style={{ background: 'linear-gradient(135deg,#0A84FF,#0066CC)',
                         boxShadow: '0 4px 12px #0A84FF44' }}
              >↑</button>
            </>
          )}

          {role === 'hearing' && (
            <button
              onClick={toggleListening}
              disabled={!speech.supported.stt}
              className="flex items-center gap-2 px-4 py-2 rounded-2xl
                         font-semibold text-sm transition-all hover:scale-105
                         active:scale-95 disabled:opacity-40"
              style={{
                background: isListening
                  ? 'linear-gradient(135deg,#30D158,#25A244)'
                  : btnIdle,
                color: isListening ? '#fff' : btnText,
                boxShadow: isListening ? '0 0 16px #30D15844' : 'none',
              }}
            >
              <span>🎤</span>
              <span>{isListening ? 'Listening...' : 'Speak'}</span>
            </button>
          )}
        </div>

        {/* Center: call controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleMute}
            className="w-10 h-10 rounded-full flex items-center justify-center
                       transition-all hover:scale-110 active:scale-95 text-sm"
            style={{
              background: isMuted ? '#FF453A30' : 'var(--pill-bg)',
              color:      isMuted ? '#FF453A'   : 'var(--text-secondary)',
              border:     `1px solid ${isMuted ? '#FF453A50' : 'var(--pill-border)'}`,
            }}
          >
            {isMuted ? '🔇' : '🔊'}
          </button>

          <button
            onClick={toggleCamera}
            className="w-10 h-10 rounded-full flex items-center justify-center
                       transition-all hover:scale-110 active:scale-95 text-sm"
            style={{
              background: isCameraOff ? '#FF453A30' : 'var(--pill-bg)',
              color:      isCameraOff ? '#FF453A'   : 'var(--text-secondary)',
              border:     `1px solid ${isCameraOff ? '#FF453A50' : 'var(--pill-border)'}`,
            }}
          >
            {isCameraOff ? '🚫' : '📷'}
          </button>

          <button
            onClick={() => { peer.endCall(); onGoHome() }}
            className="w-12 h-10 rounded-full flex items-center justify-center
                       bg-[#FF453A] hover:bg-[#FF3025] text-white transition-all
                       hover:scale-110 active:scale-95 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {/* Right: room code */}
        <div className="flex items-center gap-2">
          {peer.roomCode && (
            <button
              onClick={copyRoomCode}
              className="text-xs transition-colors font-mono"
              style={{ color: 'var(--text-muted)' }}
            >
              {copied ? '✓ Copied' : peer.roomCode}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}