// src/components/screens/LandingPage.jsx
// ─────────────────────────────────────────────
// Full landing page for SignBridge
// White + Gradient Hero (Stripe-style)
// Sections: Header, Hero, Problem, How It Works,
//           Features, Scenarios, Privacy, Free, FAQ,
//           Final CTA, Footer
// ─────────────────────────────────────────────

import { useState, useEffect, useRef } from 'react'

// ── Scroll animation hook ──
function useScrollReveal() {
  const ref = useRef(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true) },
      { threshold: 0.15 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return { ref, visible }
}

// ── Reveal wrapper ──
function Reveal({ children, delay = 0, className = '' }) {
  const { ref, visible } = useScrollReveal()
  return (
    <div ref={ref} className={className} style={{
      opacity:    visible ? 1 : 0,
      transform:  visible ? 'translateY(0)' : 'translateY(32px)',
      transition: `opacity 0.7s ease ${delay}s, transform 0.7s ease ${delay}s`,
    }}>
      {children}
    </div>
  )
}

// ── Counter animation ──
function CountUp({ target, suffix = '', duration = 2000 }) {
  const [count, setCount] = useState(0)
  const { ref, visible } = useScrollReveal()
  const started = useRef(false)

  useEffect(() => {
    if (!visible || started.current) return
    started.current = true
    const steps = 60
    const increment = target / steps
    let current = 0
    const timer = setInterval(() => {
      current += increment
      if (current >= target) { setCount(target); clearInterval(timer) }
      else setCount(Math.floor(current))
    }, duration / steps)
    return () => clearInterval(timer)
  }, [visible])

  return <span ref={ref}>{count.toLocaleString()}{suffix}</span>
}

// ── FAQ Item ──
function FAQItem({ q, a }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b border-gray-200 last:border-0">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between py-5 text-left
                   hover:text-blue-600 transition-colors group"
      >
        <span className="font-semibold text-gray-900 text-base pr-4">{q}</span>
        <span className="text-2xl text-gray-400 group-hover:text-blue-500
                         transition-all duration-200 flex-shrink-0"
              style={{ transform: open ? 'rotate(45deg)' : 'none' }}>
          +
        </span>
      </button>
      {open && (
        <p className="text-gray-600 pb-5 leading-relaxed text-sm">{a}</p>
      )}
    </div>
  )
}

export default function LandingPage({ onGetStarted }) {
  const [scrolled,       setScrolled]       = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handler)
    return () => window.removeEventListener('scroll', handler)
  }, [])

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    setMobileMenuOpen(false)
  }

  return (
    <div style={{
           fontFamily: "'DM Sans', sans-serif",
           background: '#ffffff',
           width: '100vw',
           minHeight: '100vh',
           overflowX: 'hidden',
           overflowY: 'auto',
           position: 'fixed',
           inset: 0,
         }}
         className="landing-scroll"
    >

      {/* Google Font */}
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap"
            rel="stylesheet" />

      {/* ══════════════════════════════════════
          HEADER
      ══════════════════════════════════════ */}
      <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
              style={{
                background: scrolled ? 'rgba(255,255,255,0.95)' : 'transparent',
                backdropFilter: scrolled ? 'blur(12px)' : 'none',
                boxShadow: scrolled ? '0 1px 0 rgba(0,0,0,0.08)' : 'none',
              }}>
        <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between">

          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xl"
                 style={{ background: 'linear-gradient(135deg, #0A84FF, #00C6FF)' }}>
              🤟
            </div>
            <span className="font-bold text-xl text-gray-900">SignBridge</span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {[
              { label: 'Home',         id: 'hero'     },
              { label: 'How It Works', id: 'howitworks' },
              { label: 'Features',     id: 'features' },
              { label: 'About',        id: 'about'    },
            ].map(({ label, id }) => (
              <button key={id} onClick={() => scrollTo(id)}
                      className="text-gray-600 hover:text-blue-600 font-medium
                                 text-sm transition-colors">
                {label}
              </button>
            ))}
          </nav>

          {/* CTA */}
          <div className="flex items-center gap-3">
            <button
              onClick={onGetStarted}
              className="hidden md:flex items-center gap-2 px-5 py-2.5 rounded-xl
                         text-white font-semibold text-sm transition-all
                         hover:scale-105 active:scale-95 hover:shadow-lg"
              style={{ background: 'linear-gradient(135deg, #0A84FF, #00C6FF)',
                       boxShadow: '0 4px 16px rgba(10,132,255,0.35)' }}
            >
              Get Started →
            </button>

            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden w-9 h-9 flex flex-col items-center
                         justify-center gap-1.5"
            >
              <div className="w-5 h-0.5 bg-gray-700 transition-all"
                   style={{ transform: mobileMenuOpen ? 'rotate(45deg) translate(2px, 2px)' : 'none' }} />
              <div className="w-5 h-0.5 bg-gray-700 transition-all"
                   style={{ opacity: mobileMenuOpen ? 0 : 1 }} />
              <div className="w-5 h-0.5 bg-gray-700 transition-all"
                   style={{ transform: mobileMenuOpen ? 'rotate(-45deg) translate(2px, -2px)' : 'none' }} />
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 px-5 py-4 space-y-3">
            {[
              { label: 'Home',         id: 'hero'       },
              { label: 'How It Works', id: 'howitworks' },
              { label: 'Features',     id: 'features'   },
              { label: 'About',        id: 'about'      },
            ].map(({ label, id }) => (
              <button key={id} onClick={() => scrollTo(id)}
                      className="block w-full text-left text-gray-700
                                 font-medium py-2">
                {label}
              </button>
            ))}
            <button onClick={onGetStarted}
                    className="w-full py-3 rounded-xl text-white font-semibold text-sm"
                    style={{ background: 'linear-gradient(135deg, #0A84FF, #00C6FF)' }}>
              Get Started
            </button>
          </div>
        )}
      </header>

      {/* ══════════════════════════════════════
          HERO
      ══════════════════════════════════════ */}
      <section id="hero" className="relative pt-24 pb-20 overflow-hidden">

        {/* Gradient background */}
        <div className="absolute inset-0" style={{
          background: 'linear-gradient(160deg, #EBF4FF 0%, #F0FFFE 40%, #ffffff 70%)',
        }} />

        {/* Decorative circles */}
        <div className="absolute top-20 right-10 w-72 h-72 rounded-full opacity-20"
             style={{ background: 'radial-gradient(circle, #0A84FF, transparent)' }} />
        <div className="absolute bottom-0 left-10 w-48 h-48 rounded-full opacity-10"
             style={{ background: 'radial-gradient(circle, #30D158, transparent)' }} />

        <div className="relative max-w-5xl mx-auto px-5 text-center">

          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full
                          border border-blue-200 bg-blue-50 mb-8"
               style={{ animation: 'fadeIn 0.6s ease' }}>
            <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
            <span className="text-blue-700 text-xs font-semibold tracking-wide uppercase">
              AI-Powered Sign Language Translation
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 leading-tight mb-6"
              style={{ fontFamily: "'DM Serif Display', serif",
                       animation: 'slideUp 0.7s ease 0.1s both' }}>
            Sign language,
            <br />
            <span style={{ background: 'linear-gradient(135deg, #0A84FF, #00C6FF)',
                           WebkitBackgroundClip: 'text',
                           WebkitTextFillColor: 'transparent' }}>
              understood instantly.
            </span>
          </h1>

          {/* Subtext */}
          <p className="text-gray-500 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
             style={{ animation: 'slideUp 0.7s ease 0.2s both' }}>
            SignBridge uses AI to translate ASL signs into text and speech in real-time —
            breaking the barrier between deaf and hearing individuals.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4"
               style={{ animation: 'slideUp 0.7s ease 0.3s both' }}>
            <button
              onClick={onGetStarted}
              className="flex items-center gap-2 px-8 py-4 rounded-2xl text-white
                         font-bold text-base transition-all hover:scale-105
                         active:scale-95"
              style={{ background: 'linear-gradient(135deg, #0A84FF, #00C6FF)',
                       boxShadow: '0 8px 32px rgba(10,132,255,0.35)' }}
            >
              🤟 Get Started — It's Free
            </button>
            <button
              onClick={() => scrollTo('howitworks')}
              className="flex items-center gap-2 px-8 py-4 rounded-2xl
                         text-gray-700 font-semibold text-base border-2
                         border-gray-200 hover:border-blue-300
                         hover:text-blue-600 transition-all"
            >
              See How It Works ↓
            </button>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap items-center justify-center gap-6 mt-12 opacity-60">
            {['No signup required', 'Works in browser', '100% Free', 'Camera stays private'].map(t => (
              <div key={t} className="flex items-center gap-1.5 text-gray-500 text-sm">
                <span className="text-green-500">✓</span>
                <span>{t}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          STATS BAR
      ══════════════════════════════════════ */}
      <section className="py-12 border-y border-gray-100"
               style={{ background: '#F8FAFF' }}>
        <div className="max-w-5xl mx-auto px-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: 99, suffix: '%',  label: 'Detection Accuracy' },
              { value: 850, suffix: 'M+', label: 'Deaf People Worldwide' },
              { value: 26, suffix: '',   label: 'ASL Signs Supported'  },
              { value: 0,  suffix: 'ms', label: 'Processing Delay'     },
            ].map(({ value, suffix, label }) => (
              <div key={label} className="space-y-1">
                <p className="text-4xl font-bold text-gray-900">
                  <CountUp target={value} suffix={suffix} />
                </p>
                <p className="text-gray-500 text-sm">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          PROBLEM STATEMENT
      ══════════════════════════════════════ */}
      <section className="py-24 px-5">
        <div className="max-w-4xl mx-auto text-center">
          <Reveal>
            <p className="text-blue-600 font-semibold text-sm uppercase tracking-widest mb-4">
              The Problem
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight mb-8"
                style={{ fontFamily: "'DM Serif Display', serif" }}>
              850 million people struggle
              <span className="italic text-gray-400"> to be heard</span> every day.
            </h2>
            <p className="text-gray-500 text-lg leading-relaxed max-w-2xl mx-auto mb-12">
              Deaf and hard-of-hearing individuals face communication barriers at the
              doctor's office, at work, with family — everywhere. Interpreters are
              expensive, unavailable, and slow. SignBridge changes that instantly.
            </p>
          </Reveal>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: '💸', title: 'Interpreters cost $100+/hr', desc: 'Professional sign language interpreters are out of reach for most people.' },
              { icon: '⏳', title: 'Long waiting times',          desc: 'Booking an interpreter can take days. Communication cannot wait.' },
              { icon: '😔', title: 'Isolation & frustration',    desc: 'Without communication tools, many feel excluded from everyday life.' },
            ].map(({ icon, title, desc }, i) => (
              <Reveal key={title} delay={i * 0.1}>
                <div className="p-6 rounded-2xl border border-red-100 text-left"
                     style={{ background: '#FFF5F5' }}>
                  <div className="text-3xl mb-3">{icon}</div>
                  <h3 className="font-bold text-gray-900 mb-2">{title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          HOW IT WORKS
      ══════════════════════════════════════ */}
      <section id="howitworks" className="py-24 px-5"
               style={{ background: '#F8FAFF' }}>
        <div className="max-w-5xl mx-auto">
          <Reveal className="text-center mb-16">
            <p className="text-blue-600 font-semibold text-sm uppercase tracking-widest mb-4">
              How It Works
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900"
                style={{ fontFamily: "'DM Serif Display', serif" }}>
              Simple as 1, 2, 3
            </h2>
          </Reveal>

          <div className="grid md:grid-cols-3 gap-8 relative">
            {/* Connector line */}
            <div className="hidden md:block absolute top-12 left-1/4 right-1/4 h-0.5"
                 style={{ background: 'linear-gradient(90deg, #0A84FF, #00C6FF)' }} />

            {[
              { step: '01', icon: '👤', title: 'Select Your Role',    desc: 'Choose whether you are Deaf or Hearing. SignBridge adapts the experience for you.' },
              { step: '02', icon: '🤟', title: 'Sign or Speak',       desc: 'Deaf users sign in front of the camera. Hearing users speak naturally into the mic.' },
              { step: '03', icon: '💬', title: 'Communicate Freely',  desc: 'SignBridge translates in real-time. Everyone understands. Everyone is heard.' },
            ].map(({ step, icon, title, desc }, i) => (
              <Reveal key={step} delay={i * 0.15}>
                <div className="relative text-center p-8 rounded-3xl bg-white
                                border border-gray-100 shadow-sm hover:shadow-md
                                transition-shadow">
                  {/* Step number */}
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2
                                  w-8 h-8 rounded-full text-white text-xs
                                  font-bold flex items-center justify-center"
                       style={{ background: 'linear-gradient(135deg, #0A84FF, #00C6FF)' }}>
                    {step}
                  </div>
                  <div className="text-5xl mb-5 mt-2">{icon}</div>
                  <h3 className="font-bold text-gray-900 text-lg mb-3">{title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          FEATURES
      ══════════════════════════════════════ */}
      <section id="features" className="py-24 px-5">
        <div className="max-w-5xl mx-auto">
          <Reveal className="text-center mb-16">
            <p className="text-blue-600 font-semibold text-sm uppercase tracking-widest mb-4">
              Features
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900"
                style={{ fontFamily: "'DM Serif Display', serif" }}>
              Everything you need
            </h2>
          </Reveal>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: '🧠', color: '#EBF4FF', accent: '#0A84FF', title: 'AI-Powered Detection',    desc: '99% accurate ASL detection trained on thousands of real signs.' },
              { icon: '⚡', color: '#FFFBEB', accent: '#F59E0B', title: 'Real-Time Translation',   desc: 'Signs are detected and translated instantly with zero noticeable delay.' },
              { icon: '📹', color: '#F0FFF4', accent: '#30D158', title: 'Video Meeting Mode',      desc: 'Join remote video calls and communicate with sign translation live.' },
              { icon: '🎤', color: '#FFF5F5', accent: '#FF453A', title: 'Speech Recognition',     desc: 'Hearing users speak naturally — their words appear as text instantly.' },
              { icon: '🔒', color: '#F5F3FF', accent: '#7C3AED', title: 'Fully Private',          desc: 'Your camera and audio never leave your device. Nothing is recorded.' },
              { icon: '🌐', color: '#ECFEFF', accent: '#06B6D4', title: 'No Download Needed',     desc: 'Works directly in your browser. Open and start — that is all.' },
            ].map(({ icon, color, accent, title, desc }, i) => (
              <Reveal key={title} delay={(i % 3) * 0.1}>
                <div className="p-6 rounded-2xl border border-gray-100
                                hover:shadow-md transition-all hover:-translate-y-1 duration-200">
                  <div className="w-12 h-12 rounded-2xl flex items-center
                                  justify-center text-2xl mb-4"
                       style={{ background: color }}>
                    {icon}
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">{title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          REAL LIFE SCENARIOS
      ══════════════════════════════════════ */}
      <section className="py-24 px-5" style={{ background: '#F8FAFF' }}>
        <div className="max-w-5xl mx-auto">
          <Reveal className="text-center mb-16">
            <p className="text-blue-600 font-semibold text-sm uppercase tracking-widest mb-4">
              Real Life
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900"
                style={{ fontFamily: "'DM Serif Display', serif" }}>
              Where SignBridge helps
            </h2>
            <p className="text-gray-500 mt-4 max-w-xl mx-auto">
              Every day moments that used to be stressful — now simple.
            </p>
          </Reveal>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              { icon: '👨‍⚕️', scenario: 'At the Doctor\'s Office', before: 'Struggling to explain symptoms without an interpreter', after: 'Sign naturally — the doctor reads the translation instantly' },
              { icon: '💼', scenario: 'At Work',                  before: 'Missing out in meetings, unable to join the conversation', after: 'Participate fully in any meeting, in-person or remote' },
              { icon: '🛒', scenario: 'Everyday Errands',         before: 'Frustration asking for help at stores or counters', after: 'Communicate with anyone, anywhere, in seconds' },
              { icon: '👨‍👩‍👧', scenario: 'With Family',              before: 'Feeling disconnected from hearing family members', after: 'Have real conversations with the people you love' },
            ].map(({ icon, scenario, before, after }, i) => (
              <Reveal key={scenario} delay={(i % 2) * 0.1}>
                <div className="p-6 rounded-2xl bg-white border border-gray-100
                                hover:shadow-md transition-all">
                  <div className="flex items-center gap-3 mb-5">
                    <span className="text-3xl">{icon}</span>
                    <h3 className="font-bold text-gray-900 text-lg">{scenario}</h3>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-xl"
                         style={{ background: '#FFF5F5' }}>
                      <span className="text-red-400 mt-0.5 flex-shrink-0">✕</span>
                      <p className="text-gray-600 text-sm">{before}</p>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-xl"
                         style={{ background: '#F0FFF4' }}>
                      <span className="text-green-500 mt-0.5 flex-shrink-0">✓</span>
                      <p className="text-gray-600 text-sm">{after}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          PRIVACY + FREE (side by side)
      ══════════════════════════════════════ */}
      <section className="py-24 px-5">
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">

          {/* Privacy */}
          <Reveal>
            <div className="p-10 rounded-3xl h-full"
                 style={{ background: 'linear-gradient(135deg, #F5F3FF, #EDE9FE)' }}>
              <div className="text-5xl mb-6">🔒</div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4"
                  style={{ fontFamily: "'DM Serif Display', serif" }}>
                Your privacy is sacred
              </h2>
              <div className="space-y-3">
                {[
                  'Camera footage never leaves your device',
                  'No video is recorded or stored anywhere',
                  'No account or personal data required',
                  'All processing happens in your browser',
                ].map(point => (
                  <div key={point} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-purple-500 flex items-center
                                    justify-center flex-shrink-0">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <p className="text-gray-700 text-sm">{point}</p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          {/* Free */}
          <Reveal delay={0.1}>
            <div className="p-10 rounded-3xl h-full"
                 style={{ background: 'linear-gradient(135deg, #ECFDF5, #D1FAE5)' }}>
              <div className="text-5xl mb-6">🎉</div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4"
                  style={{ fontFamily: "'DM Serif Display', serif" }}>
                100% free, always
              </h2>
              <div className="space-y-3">
                {[
                  'No subscription or payment required',
                  'No hidden fees or premium tiers',
                  'No account creation needed',
                  'Open and start in seconds',
                ].map(point => (
                  <div key={point} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-green-500 flex items-center
                                    justify-center flex-shrink-0">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <p className="text-gray-700 text-sm">{point}</p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ══════════════════════════════════════
          FAQ
      ══════════════════════════════════════ */}
      <section className="py-24 px-5" style={{ background: '#F8FAFF' }}>
        <div className="max-w-3xl mx-auto">
          <Reveal className="text-center mb-16">
            <p className="text-blue-600 font-semibold text-sm uppercase tracking-widest mb-4">
              FAQ
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900"
                style={{ fontFamily: "'DM Serif Display', serif" }}>
              Questions? Answered.
            </h2>
          </Reveal>

          <Reveal>
            <div className="bg-white rounded-3xl border border-gray-100 px-8 py-4 shadow-sm">
              {[
                { q: 'Do I need to know sign language to use SignBridge?',
                  a: 'No! Hearing users do not need to know any sign language. You simply speak and your words are shown as text to the deaf person. SignBridge handles the translation automatically.' },
                { q: 'Does it work on my phone?',
                  a: 'Yes, SignBridge works on any modern smartphone browser including Chrome on Android and Safari on iPhone. No app download required.' },
                { q: 'Is my camera footage safe?',
                  a: 'Absolutely. Your camera feed is processed entirely on your device using AI. Nothing is sent to any server. No footage is ever recorded or stored.' },
                { q: 'Which signs does SignBridge support?',
                  a: 'Currently SignBridge supports the full ASL fingerspelling alphabet (A-Z) with 99% accuracy. Support for full ASL words and phrases is coming soon.' },
                { q: 'Does it work without internet?',
                  a: 'You need internet to load the app initially. Once loaded, the AI detection works locally on your device. The video meeting feature requires internet for the connection.' },
                { q: 'Is SignBridge really free?',
                  a: 'Yes, completely free. No subscription, no credit card, no account needed. Just open SignBridge and start communicating.' },
              ].map(faq => (
                <FAQItem key={faq.q} q={faq.q} a={faq.a} />
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ══════════════════════════════════════
          ABOUT
      ══════════════════════════════════════ */}
      <section id="about" className="py-24 px-5">
        <div className="max-w-3xl mx-auto text-center">
          <Reveal>
            <p className="text-blue-600 font-semibold text-sm uppercase tracking-widest mb-4">
              About
            </p>
            <h2 className="text-4xl font-bold text-gray-900 mb-6"
                style={{ fontFamily: "'DM Serif Display', serif" }}>
              Built to break barriers
            </h2>
            <p className="text-gray-500 text-lg leading-relaxed">
              SignBridge was built with one goal — to make communication between deaf and
              hearing people effortless, instant, and free. Using modern AI and
              browser technology, we believe no one should ever feel unheard.
            </p>
          </Reveal>
        </div>
      </section>

      {/* ══════════════════════════════════════
          FINAL CTA
      ══════════════════════════════════════ */}
      <section className="py-24 px-5 mx-5 mb-12 rounded-3xl overflow-hidden relative"
               style={{ background: 'linear-gradient(135deg, #0A84FF 0%, #00C6FF 50%, #30D158 100%)' }}>

        {/* Decorative */}
        <div className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-10"
             style={{ background: 'white', transform: 'translate(30%, -30%)' }} />
        <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full opacity-10"
             style={{ background: 'white', transform: 'translate(-30%, 30%)' }} />

        <Reveal className="relative text-center">
          <div className="text-6xl mb-6">🤟</div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4"
              style={{ fontFamily: "'DM Serif Display', serif" }}>
            Ready to bridge the gap?
          </h2>
          <p className="text-white/80 text-lg mb-10 max-w-xl mx-auto">
            Join thousands of people already using SignBridge to communicate
            freely. No signup, no cost, no barriers.
          </p>
          <button
            onClick={onGetStarted}
            className="inline-flex items-center gap-2 px-10 py-4 rounded-2xl
                       bg-white font-bold text-blue-600 text-lg
                       transition-all hover:scale-105 active:scale-95
                       hover:shadow-2xl"
          >
            Get Started Free →
          </button>
        </Reveal>
      </section>

      {/* ══════════════════════════════════════
          FOOTER
      ══════════════════════════════════════ */}
      <footer style={{ background: '#0A0A0C' }} className="px-5 pt-16 pb-8">
        <div className="max-w-6xl mx-auto">

          {/* Top row */}
          <div className="grid md:grid-cols-4 gap-10 pb-12 border-b border-white/10">

            {/* Brand */}
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xl"
                     style={{ background: 'linear-gradient(135deg, #0A84FF, #00C6FF)' }}>
                  🤟
                </div>
                <span className="font-bold text-xl text-white">SignBridge</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
                Breaking the communication barrier between deaf and hearing individuals
                using real-time AI sign language translation.
              </p>
            </div>

            {/* Navigation */}
            <div>
              <h4 className="text-white font-semibold text-sm mb-4">Navigation</h4>
              <div className="space-y-2.5">
                {[
                  { label: 'Home',         id: 'hero'       },
                  { label: 'How It Works', id: 'howitworks' },
                  { label: 'Features',     id: 'features'   },
                  { label: 'About',        id: 'about'      },
                ].map(({ label, id }) => (
                  <button key={id} onClick={() => scrollTo(id)}
                          className="block text-gray-400 text-sm hover:text-white transition-colors">
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-white font-semibold text-sm mb-4">Legal</h4>
              <div className="space-y-2.5">
                {['Privacy Policy', 'Terms of Use', 'Cookie Policy'].map(item => (
                  <p key={item} className="text-gray-400 text-sm cursor-pointer
                                           hover:text-white transition-colors">
                    {item}
                  </p>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom row */}
          <div className="flex flex-col md:flex-row items-center justify-between
                          gap-4 pt-8">
            <p className="text-gray-500 text-sm">
              © {new Date().getFullYear()} SignBridge. All rights reserved.
            </p>
            <p className="text-gray-600 text-xs">
              Built to empower the deaf community worldwide.
            </p>
          </div>
        </div>
      </footer>

      {/* ── Global animations ── */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(24px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}