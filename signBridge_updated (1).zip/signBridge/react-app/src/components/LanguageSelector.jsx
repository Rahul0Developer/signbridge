// src/components/LanguageSelector.jsx
// ─────────────────────────────────────────────
// Small header pill (matches ThemeToggle's footprint) that opens a
// dropdown of sign languages. Available languages are selectable;
// languages without a trained model yet show a "Soon" badge and
// are disabled — visible so people know more are coming, but can't
// be picked into a broken state.
// ─────────────────────────────────────────────
import { useState, useRef, useEffect } from 'react'
import { useLanguage } from '../context/LanguageContext'

export default function LanguageSelector() {
  const { language, languages, setLanguageId } = useLanguage()
  const [open, setOpen] = useState(false)
  const rootRef = useRef(null)

  useEffect(() => {
    const onClickOutside = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onClickOutside)
    return () => document.removeEventListener('mousedown', onClickOutside)
  }, [])

  return (
    <div ref={rootRef} className="relative flex-shrink-0">
      <button
        onClick={() => setOpen(o => !o)}
        title="Choose sign language"
        className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border transition-all"
        style={{ background: 'var(--pill-bg)', borderColor: 'var(--pill-border)' }}
      >
        <span className="text-sm leading-none">{language.flag}</span>
        <span className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>
          {language.shortName}
        </span>
        <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>▾</span>
      </button>

      {open && (
        <div
          className="absolute right-0 mt-2 w-64 rounded-2xl border overflow-hidden z-50"
          style={{ background: 'var(--bg-card)', borderColor: 'var(--border)', boxShadow: 'var(--shadow-lg)' }}
        >
          <div className="px-3 py-2 border-b" style={{ borderColor: 'var(--border)' }}>
            <p className="text-xs font-semibold" style={{ color: 'var(--text-primary)' }}>Sign language</p>
            <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
              Choose which alphabet the AI recognizes
            </p>
          </div>

          {languages.map((lang) => {
            const isSelected = lang.id === language.id
            const isUsable   = lang.status === 'available'
            return (
              <button
                key={lang.id}
                disabled={!isUsable}
                onClick={() => { setLanguageId(lang.id); setOpen(false) }}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 text-left transition-colors"
                style={{
                  background: isSelected ? 'var(--bg-tertiary)' : 'transparent',
                  cursor:     isUsable ? 'pointer' : 'not-allowed',
                  opacity:    isUsable ? 1 : 0.5,
                }}
              >
                <span className="text-lg leading-none">{lang.flag}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
                      {lang.name}
                    </span>
                    {!isUsable && (
                      <span
                        className="text-[9px] font-bold px-1.5 py-0.5 rounded-full flex-shrink-0"
                        style={{ background: '#FF9F0A22', color: '#FF9F0A' }}
                      >
                        SOON
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] truncate" style={{ color: 'var(--text-muted)' }}>
                    {lang.description}
                  </p>
                </div>
                {isSelected && <span style={{ color: '#0A84FF' }}>✓</span>}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
