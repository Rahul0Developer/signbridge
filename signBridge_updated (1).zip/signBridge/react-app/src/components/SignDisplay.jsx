// src/components/SignDisplay.jsx
// ─────────────────────────────────────────────
// Shows spoken text as fingerspelling
// Uses SVG hand shapes — no external URLs, no CORS issues
// Works offline, instant load
// ─────────────────────────────────────────────

import { useState, useEffect, useRef } from 'react'

// ── SVG hand shape data for each letter ──
// Each letter = array of finger states + thumb position
// Rendered as a simple but clear hand diagram
// Based on ASL manual alphabet

export const HAND_SHAPES = {
  A: { desc: 'Fist with thumb on side',      fingers: [0,0,0,0,0], thumb: 'side'   },
  B: { desc: 'Flat hand, fingers together',  fingers: [1,1,1,1,1], thumb: 'across' },
  C: { desc: 'Curved C shape',               fingers: [2,2,2,2,2], thumb: 'curve'  },
  D: { desc: 'Index up, others curved',      fingers: [1,2,2,2,0], thumb: 'touch'  },
  E: { desc: 'All fingers bent down',        fingers: [2,2,2,2,0], thumb: 'under'  },
  F: { desc: 'Index-thumb circle, rest up',  fingers: [0,1,1,1,0], thumb: 'circle' },
  G: { desc: 'Index points sideways',        fingers: [1,0,0,0,0], thumb: 'side'   },
  H: { desc: 'Index+middle point sideways',  fingers: [1,1,0,0,0], thumb: 'side'   },
  I: { desc: 'Pinky up, others closed',      fingers: [0,0,0,0,1], thumb: 'side'   },
  J: { desc: 'Pinky up, trace J motion',     fingers: [0,0,0,0,1], thumb: 'side', motion: true },
  K: { desc: 'Index+middle up, thumb out',   fingers: [1,1,0,0,0], thumb: 'up'     },
  L: { desc: 'L-shape: index up, thumb out', fingers: [1,0,0,0,0], thumb: 'out'    },
  M: { desc: '3 fingers over thumb',         fingers: [2,2,2,0,0], thumb: 'under'  },
  N: { desc: '2 fingers over thumb',         fingers: [2,2,0,0,0], thumb: 'under'  },
  O: { desc: 'All fingers form O',           fingers: [2,2,2,2,2], thumb: 'o'      },
  P: { desc: 'K shape pointing down',        fingers: [1,1,0,0,0], thumb: 'down'   },
  Q: { desc: 'G shape pointing down',        fingers: [1,0,0,0,0], thumb: 'down'   },
  R: { desc: 'Index+middle crossed',         fingers: [1,1,0,0,0], thumb: 'cross'  },
  S: { desc: 'Fist with thumb in front',     fingers: [0,0,0,0,0], thumb: 'front'  },
  T: { desc: 'Thumb between index+middle',   fingers: [0,0,0,0,0], thumb: 'between'},
  U: { desc: 'Index+middle up together',     fingers: [1,1,0,0,0], thumb: 'side'   },
  V: { desc: 'Index+middle spread (peace)',  fingers: [1,1,0,0,0], thumb: 'v'      },
  W: { desc: '3 fingers up spread',          fingers: [1,1,1,0,0], thumb: 'side'   },
  X: { desc: 'Index hooked',                 fingers: [2,0,0,0,0], thumb: 'side'   },
  Y: { desc: 'Thumb+pinky out',              fingers: [0,0,0,0,1], thumb: 'out'    },
  Z: { desc: 'Index traces Z',               fingers: [1,0,0,0,0], thumb: 'side', motion: true },
}

// ── Draw hand SVG ──
// finger states: 0=closed, 1=extended, 2=bent
export function HandSVG({ letter, size = 128 }) {
  if (!letter || !HAND_SHAPES[letter]) {
    return (
      <div style={{ width: size, height: size }}
           className="flex items-center justify-center">
        <span className="text-[#636366] text-4xl font-bold">?</span>
      </div>
    )
  }

  const shape  = HAND_SHAPES[letter]
  const s      = size
  const cx     = s / 2
  const palmY  = s * 0.62
  const palmW  = s * 0.44
  const palmH  = s * 0.32

  // Finger base positions (index to pinky, left to right)
  const fingerBases = [
    cx - palmW * 0.38,  // index
    cx - palmW * 0.13,  // middle
    cx + palmW * 0.13,  // ring
    cx + palmW * 0.38,  // pinky
  ]

  const fingerWidths = [
    s * 0.09,  // index
    s * 0.09,  // middle
    s * 0.08,  // ring
    s * 0.07,  // pinky
  ]

  const fingerMaxH = [
    s * 0.42,  // index
    s * 0.46,  // middle (tallest)
    s * 0.42,  // ring
    s * 0.34,  // pinky (shortest)
  ]

  const renderFinger = (i) => {
    const state  = shape.fingers[i]
    const bx     = fingerBases[i]
    const fw     = fingerWidths[i]
    const fh     = fingerMaxH[i]
    const baseY  = palmY - palmH * 0.25
    const rx     = fw / 2

    if (state === 0) {
      // Closed — just a small nub at palm
      return (
        <rect key={i}
              x={bx - fw/2} y={baseY - fw * 0.3}
              width={fw} height={fw * 0.5}
              rx={rx} fill="#E8C49A" stroke="#C4956A" strokeWidth="1" />
      )
    } else if (state === 1) {
      // Extended — full finger up
      return (
        <g key={i}>
          <rect x={bx - fw/2} y={baseY - fh}
                width={fw} height={fh}
                rx={rx} fill="#F5D5A8" stroke="#C4956A" strokeWidth="1.5" />
          {/* Knuckle lines */}
          <line x1={bx - fw/2 + 1} y1={baseY - fh * 0.35}
                x2={bx + fw/2 - 1} y2={baseY - fh * 0.35}
                stroke="#C4956A" strokeWidth="0.8" opacity="0.6" />
          <line x1={bx - fw/2 + 1} y1={baseY - fh * 0.65}
                x2={bx + fw/2 - 1} y2={baseY - fh * 0.65}
                stroke="#C4956A" strokeWidth="0.8" opacity="0.6" />
        </g>
      )
    } else {
      // Bent — curved finger
      const bendH = fh * 0.5
      return (
        <g key={i}>
          <rect x={bx - fw/2} y={baseY - bendH}
                width={fw} height={bendH}
                rx={rx} fill="#F5D5A8" stroke="#C4956A" strokeWidth="1.5" />
          {/* Bent tip */}
          <ellipse cx={bx + fw * 0.3} cy={baseY - bendH + fw * 0.3}
                   rx={fw * 0.55} ry={fw * 0.45}
                   fill="#E8C49A" stroke="#C4956A" strokeWidth="1.2" />
        </g>
      )
    }
  }

  const renderThumb = () => {
    const thumbPos = shape.thumb
    const tw = s * 0.10
    const th = s * 0.24

    // Thumb base is left of index finger
    const thumbBaseX = cx - palmW * 0.52
    const thumbBaseY = palmY - palmH * 0.1

    let tx = thumbBaseX, ty = thumbBaseY
    let rotate = -35

    switch (thumbPos) {
      case 'out':    tx = cx - palmW * 0.68; rotate = -60;  break
      case 'up':     tx = cx - palmW * 0.60; rotate = -50;  break
      case 'side':   tx = cx - palmW * 0.60; rotate = -30;  break
      case 'front':  tx = cx - palmW * 0.38; rotate = -10;  break
      case 'across': tx = cx - palmW * 0.20; rotate =  0;   break
      case 'under':  tx = cx - palmW * 0.30; rotate = -15;  break
      case 'circle': tx = cx - palmW * 0.50; rotate = -40;  break
      case 'touch':  tx = cx - palmW * 0.55; rotate = -45;  break
      case 'curve':  tx = cx - palmW * 0.62; rotate = -50;  break
      case 'o':      tx = cx - palmW * 0.55; rotate = -55;  break
      case 'down':   tx = cx - palmW * 0.60; rotate =  20;  break
      case 'cross':  tx = cx - palmW * 0.52; rotate = -30;  break
      case 'between':tx = cx - palmW * 0.35; rotate = -20;  break
      case 'v':      tx = cx - palmW * 0.58; rotate = -35;  break
    }

    return (
      <g transform={`translate(${tx}, ${ty}) rotate(${rotate}, ${tw/2}, ${th/2})`}>
        <rect x={0} y={0} width={tw} height={th}
              rx={tw/2} fill="#F5D5A8" stroke="#C4956A" strokeWidth="1.5" />
        <line x1={2} y1={th * 0.4} x2={tw-2} y2={th * 0.4}
              stroke="#C4956A" strokeWidth="0.8" opacity="0.6" />
      </g>
    )
  }

  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      {/* Motion indicator */}
      {shape.motion && (
        <g opacity="0.4">
          <path d={`M ${cx+10} ${s*0.15} Q ${cx+25} ${s*0.25} ${cx+15} ${s*0.35}`}
                stroke="#0A84FF" strokeWidth="2" fill="none"
                strokeDasharray="4,3" />
          <polygon points={`${cx+13},${s*0.36} ${cx+18},${s*0.32} ${cx+17},${s*0.38}`}
                   fill="#0A84FF" />
        </g>
      )}

      {/* Palm */}
      <rect x={cx - palmW/2} y={palmY - palmH}
            width={palmW} height={palmH * 1.3}
            rx={s * 0.05}
            fill="#F5D5A8" stroke="#C4956A" strokeWidth="1.5" />

      {/* Wrist */}
      <rect x={cx - palmW * 0.38} y={palmY + palmH * 0.2}
            width={palmW * 0.76} height={s * 0.12}
            rx={s * 0.03}
            fill="#E8C49A" stroke="#C4956A" strokeWidth="1" />

      {/* Fingers (index to pinky) */}
      {[0, 1, 2, 3].map(i => renderFinger(i))}

      {/* Thumb */}
      {renderThumb()}

      {/* Palm lines */}
      <path d={`M ${cx - palmW*0.25} ${palmY - palmH*0.2}
                Q ${cx} ${palmY - palmH*0.35}
                  ${cx + palmW*0.2} ${palmY - palmH*0.15}`}
            stroke="#C4956A" strokeWidth="0.8" fill="none" opacity="0.4" />
    </svg>
  )
}

// ── Tokenizer ──
const isSignable = (c) => /^[a-zA-Z]$/.test(c)
const tokenize   = (text) =>
  text.split('').map(char => ({
    type: char === ' ' ? 'space' : isSignable(char) ? 'letter' : 'punct',
    char: char.toUpperCase(),
  }))

// ── Main component ──
export default function SignDisplay({ text, autoPlay = true }) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPlaying,    setIsPlaying]    = useState(false)
  const timerRef = useRef(null)

  const tokens  = tokenize(text || '')
  const letters = tokens.filter(t => t.type === 'letter' || t.type === 'space')

  useEffect(() => {
    if (!text || !autoPlay) return
    setCurrentIndex(0)
    setIsPlaying(true)
  }, [text])

  useEffect(() => {
    if (!isPlaying || letters.length === 0) return
    const current = letters[currentIndex]
    if (!current) { setIsPlaying(false); return }

    timerRef.current = setTimeout(() => {
      if (currentIndex < letters.length - 1) {
        setCurrentIndex(prev => prev + 1)
      } else {
        setIsPlaying(false)
      }
    }, current.type === 'space' ? 400 : 700)

    return () => clearTimeout(timerRef.current)
  }, [isPlaying, currentIndex, letters.length])

  if (!text) return null

  const currentToken  = letters[currentIndex]
  const currentLetter = currentToken?.char
  const isSpace       = currentToken?.type === 'space'
  const progress      = letters.length > 0
    ? ((currentIndex + 1) / letters.length) * 100 : 0

  const handlePlayPause = () => {
    if (isPlaying) {
      setIsPlaying(false)
    } else {
      if (currentIndex >= letters.length - 1) setCurrentIndex(0)
      setIsPlaying(true)
    }
  }

  return (
    <div className="rounded-2xl overflow-hidden border border-surface-border"
         style={{ background: 'rgba(28,28,30,0.95)' }}>

      {/* Header */}
      <div className="px-4 py-2.5 border-b border-surface-border
                      flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm">🤟</span>
          <span className="text-[#F2F2F7] text-xs font-medium">Fingerspelling</span>
          {isPlaying && (
            <div className="flex items-end gap-0.5 h-3">
              {[0,1,2].map(i => (
                <div key={i} className="w-0.5 bg-brand-500 rounded-full animate-bounce"
                     style={{ height:`${6+i*3}px`, animationDelay:`${i*0.15}s`, animationDuration:'0.6s' }} />
              ))}
            </div>
          )}
        </div>
        <span className="text-[#636366] text-xs">{currentIndex + 1} / {letters.length}</span>
      </div>

      {/* Full text with highlight */}
      <div className="px-4 pt-3 pb-2">
        <div className="p-2.5 rounded-xl bg-surface-tertiary border border-surface-border
                        min-h-[40px] flex items-center flex-wrap gap-x-0.5">
          {tokens.map((token, i) => {
            let lPos = -1, lCount = 0
            for (let j = 0; j < tokens.length; j++) {
              if (tokens[j].type === 'letter' || tokens[j].type === 'space') {
                if (j === i) { lPos = lCount; break }
                lCount++
              }
            }
            const isCur  = lPos === currentIndex
            const isPast = lPos >= 0 && lPos < currentIndex
            return (
              <span key={i} className="transition-colors duration-200 text-sm font-semibold"
                    style={{ color: isCur ? '#0A84FF' : isPast ? '#F2F2F7' : '#3A3A3C' }}>
                {token.char}
              </span>
            )
          })}
        </div>
      </div>

      {/* Hand shape display */}
      <div className="px-4 pb-3 flex flex-col items-center gap-3">

        {/* Hand SVG */}
        <div className="w-32 h-32 rounded-2xl flex items-center justify-center border-2"
             style={{
               borderColor: isSpace ? '#38383A' : '#0A84FF',
               background:  isSpace ? '#1C1C1E' : '#0A84FF08',
             }}>
          {isSpace ? (
            <div className="flex flex-col items-center gap-1">
              <span className="text-3xl opacity-30">⎵</span>
              <span className="text-[#636366] text-xs">space</span>
            </div>
          ) : (
            <HandSVG letter={currentLetter} size={110} />
          )}
        </div>

        {/* Letter + description */}
        <div className="text-center">
          <span className="text-4xl font-bold block transition-all duration-200"
                style={{ color: isSpace ? '#636366' : '#0A84FF' }}>
            {isSpace ? '·' : currentLetter}
          </span>
          {currentLetter && !isSpace && HAND_SHAPES[currentLetter] && (
            <span className="text-[#636366] text-xs mt-0.5 block">
              {HAND_SHAPES[currentLetter].desc}
            </span>
          )}
        </div>

        {/* Progress bar */}
        <div className="w-full h-1 rounded-full bg-surface-tertiary overflow-hidden">
          <div className="h-full rounded-full transition-all duration-300"
               style={{ width:`${progress}%`, background:'linear-gradient(90deg,#0A84FF,#30D158)' }} />
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          <button onClick={() => { setIsPlaying(false); setCurrentIndex(p => Math.max(0, p-1)) }}
                  disabled={currentIndex === 0}
                  className="w-8 h-8 rounded-full flex items-center justify-center
                             bg-surface-tertiary text-[#636366] text-sm
                             hover:text-[#F2F2F7] disabled:opacity-30 transition-all">‹</button>

          <button onClick={handlePlayPause}
                  className="w-10 h-10 rounded-full flex items-center justify-center
                             text-white text-sm transition-all hover:scale-110 active:scale-95"
                  style={{ background: isPlaying
                    ? 'linear-gradient(135deg,#FF9F0A,#E8890A)'
                    : 'linear-gradient(135deg,#0A84FF,#0066CC)' }}>
            {isPlaying ? '⏸' : '▶'}
          </button>

          <button onClick={() => { setIsPlaying(false); setCurrentIndex(p => Math.min(letters.length-1, p+1)) }}
                  disabled={currentIndex >= letters.length - 1}
                  className="w-8 h-8 rounded-full flex items-center justify-center
                             bg-surface-tertiary text-[#636366] text-sm
                             hover:text-[#F2F2F7] disabled:opacity-30 transition-all">›</button>

          <button onClick={() => { setCurrentIndex(0); setIsPlaying(true) }}
                  className="w-8 h-8 rounded-full flex items-center justify-center
                             bg-surface-tertiary text-[#636366] text-xs
                             hover:text-[#F2F2F7] transition-all ml-1" title="Replay">↺</button>
        </div>

        {/* Letter strip */}
        <div className="flex items-center gap-1 flex-wrap justify-center max-w-full">
          {letters.slice(0, 20).map((token, i) => (
            <button key={i}
                    onClick={() => { setIsPlaying(false); setCurrentIndex(i) }}
                    className="w-6 h-6 rounded-md flex items-center justify-center
                               text-xs font-mono font-bold transition-all"
                    style={{
                      background: i===currentIndex ? '#0A84FF' : i<currentIndex ? '#0A84FF30' : '#2C2C2E',
                      color:      i===currentIndex ? '#fff'    : i<currentIndex ? '#0A84FF'   : '#636366',
                      transform:  i===currentIndex ? 'scale(1.2)' : 'scale(1)',
                    }}>
              {token.type === 'space' ? '·' : token.char}
            </button>
          ))}
          {letters.length > 20 && (
            <span className="text-[#636366] text-xs">+{letters.length - 20}</span>
          )}
        </div>
      </div>
    </div>
  )
}