// src/components/ErrorBoundary.jsx
// ─────────────────────────────────────────────
// Catches any React render/runtime error
// Shows friendly screen instead of blank white crash
// ─────────────────────────────────────────────

import { Component } from 'react'

export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null, errorInfo: null }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error }
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo })
    console.error('SignBridge Error:', error, errorInfo)
  }

  handleReload = () => {
    window.location.reload()
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null })
  }

  render() {
    if (!this.state.hasError) return this.props.children

    const msg = this.state.error?.message || 'Unknown error'
    const isMediaError   = msg.includes('camera') || msg.includes('media') || msg.includes('getUserMedia')
    const isNetworkError = msg.includes('fetch') || msg.includes('network') || msg.includes('CDN')
    const isModelError   = msg.includes('model') || msg.includes('tensor')

    const hint = isMediaError   ? 'This is usually a camera permission issue. Allow camera access and try again.'
               : isNetworkError ? 'Could not load a required resource. Check your internet connection.'
               : isModelError   ? 'The AI model failed to load. Reload the page to try again.'
               : 'Something unexpected happened. Reloading usually fixes this.'

    return (
      <div className="h-screen w-screen bg-surface-primary flex flex-col
                      items-center justify-center p-6 text-center">

        {/* Ambient glow */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
                          w-96 h-96 bg-[#FF453A]/5 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-sm space-y-6">
          {/* Icon */}
          <div className="text-6xl">😔</div>

          {/* Title */}
          <div className="space-y-2">
            <h1 className="text-[#F2F2F7] text-xl font-bold">
              Something went wrong
            </h1>
            <p className="text-[#636366] text-sm leading-relaxed">{hint}</p>
          </div>

          {/* Error detail (collapsible) */}
          <details className="text-left">
            <summary className="text-[#636366] text-xs cursor-pointer
                                hover:text-[#F2F2F7] transition-colors">
              Show error details
            </summary>
            <div className="mt-2 p-3 rounded-xl bg-surface-secondary
                            border border-surface-border">
              <p className="text-[#FF453A] text-xs font-mono break-all">
                {msg}
              </p>
            </div>
          </details>

          {/* Actions */}
          <div className="flex gap-3 justify-center">
            <button
              onClick={this.handleReset}
              className="btn-secondary text-sm px-5 py-2.5"
            >
              Try Again
            </button>
            <button
              onClick={this.handleReload}
              className="btn-primary text-sm px-5 py-2.5"
            >
              Reload App
            </button>
          </div>

          {/* Brand */}
          <div className="flex items-center justify-center gap-2 pt-2">
            <span className="text-lg">🤟</span>
            <span className="text-[#636366] text-xs">SignBridge</span>
          </div>
        </div>
      </div>
    )
  }
}