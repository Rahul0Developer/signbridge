// src/App.jsx
import { useEffect, useState } from 'react'
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useNavigate,
  useLocation,
} from 'react-router-dom'
import { useAuth }        from './context/AuthContext'
import { useLanguage }    from './context/LanguageContext'
import { useSignModel }   from './hooks/useSignModel'
import LandingPage        from './components/screens/LandingPage'
import AuthPage           from './components/screens/AuthPage'
import HomeScreen         from './components/screens/HomeScreen'
import SoloScreen         from './components/screens/SoloScreen'
import MobileSoloScreen   from './components/screens/MobileSoloScreen'
import MeetingScreen      from './components/screens/MeetingScreen'
import ProfilePage        from './components/screens/ProfilePage'
import PracticeScreen     from './components/screens/PracticeScreen'
const isMobile = () => window.innerWidth < 768

// ── Spinner shown while Firebase checks session ──
function LoadingScreen() {
  return (
    <div style={{
      height:'100vh', width:'100vw', display:'flex',
      flexDirection:'column', alignItems:'center', justifyContent:'center',
      background:'var(--bg-primary)', gap:'16px',
    }}>
      <div style={{ fontSize:'40px' }}>🤟</div>
      <div style={{
        width:'28px', height:'28px',
        border:'3px solid #0A84FF',
        borderTopColor:'transparent',
        borderRadius:'50%',
        animation:'spin 0.8s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  )
}

// ── Protected route: requires login ──
function ProtectedRoute({ children }) {
  const { user, loading, redirecting } = useAuth()
  const location = useLocation()

  if (loading || redirecting) return <LoadingScreen />

  if (!user) {
    return <Navigate to="/auth" state={{ from: location }} replace />
  }

  return children
}

// ── Public route: redirects logged-in users away from /auth ──
function PublicRoute({ children }) {
  const { user, loading, redirecting } = useAuth()

  if (loading || redirecting) return <LoadingScreen />

  if (user) return <Navigate to="/app" replace />

  return children
}

// ── Main app with routing ──
function AppRoutes() {
  const navigate  = useNavigate()
  const { logout } = useAuth()
  const [role,     setRole]     = useState(null)
  const [roomCode, setRoomCode] = useState(null)
  const [mobile,   setMobile]   = useState(isMobile())

  // Preload AI model for the currently selected language in background.
  // useSignModel() auto-reloads whenever languageId changes (e.g. the
  // user switches ASL → ISL from the header picker), disposing the
  // previous model first.
  const { languageId } = useLanguage()
  const { loadModel, isLoaded, isLoading, error: modelError } = useSignModel(languageId)
  useEffect(() => { loadModel() }, [languageId])

  // Resize listener
  useEffect(() => {
    const handler = () => setMobile(isMobile())
    window.addEventListener('resize', handler)
    return () => window.removeEventListener('resize', handler)
  }, [])

  // Body class for scroll control
  const location = useLocation()
  useEffect(() => {
    if (location.pathname === '/' || location.pathname === '/auth') {
      document.body.classList.remove('app-mode')
    } else {
      document.body.classList.add('app-mode')
    }
  }, [location.pathname])

  const handleLogout = async () => {
    await logout()
    navigate('/')
  }

  const handleSelectRole = (r) => {
    setRole(r)
    navigate('/app/solo')
  }

  const handleStartMeeting = (r) => {
    setRole(r)
    setRoomCode(null)
    navigate('/app/meeting')
  }

  const handleJoinMeeting = (r, c) => {
    setRole(r)
    setRoomCode(c)
    navigate('/app/meeting')
  }

  const handleGoHome = () => {
    setRole(null)
    setRoomCode(null)
    navigate('/app')
  }

  const SoloComponent = mobile ? MobileSoloScreen : SoloScreen

  return (
    <Routes>

      {/* ── PUBLIC ROUTES ── */}

      {/* Landing — everyone sees this first */}
      <Route path="/" element={
        <LandingPage onGetStarted={() => navigate('/auth')} />
      } />

      {/* Auth — redirects to /app if already logged in */}
      <Route path="/auth" element={
        <PublicRoute>
          <AuthPage
            onAuthSuccess={() => navigate('/app')}
            onBack={() => navigate('/')}
          />
        </PublicRoute>
      } />

      {/* ── PROTECTED ROUTES ── */}

      <Route path="/app" element={
        <ProtectedRoute>
          <HomeScreen
            onSelectRole={handleSelectRole}
            onStartMeeting={handleStartMeeting}
            onJoinMeeting={handleJoinMeeting}
            onLogout={handleLogout}
            modelStatus={{ isLoaded, isLoading, error: modelError }}
          />
        </ProtectedRoute>
      } />

      <Route path="/app/solo" element={
        <ProtectedRoute>
          <SoloComponent role={role} onGoHome={handleGoHome} />
        </ProtectedRoute>
      } />

      <Route path="/app/meeting" element={
        <ProtectedRoute>
          <MeetingScreen role={role} roomCode={roomCode} onGoHome={handleGoHome} />
        </ProtectedRoute>
      } />

      <Route path="/app/profile" element={
        <ProtectedRoute>
          <ProfilePage />
        </ProtectedRoute>
      } />

      <Route path="/app/learn" element={
        <ProtectedRoute>
          <PracticeScreen onGoHome={handleGoHome} />
        </ProtectedRoute>
      } />

      {/* Catch-all → landing */}
      <Route path="*" element={<Navigate to="/" replace />} />

    </Routes>
  )
}

// ── Root: wrap everything in BrowserRouter ──
export default function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  )
}