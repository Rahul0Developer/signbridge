// src/hooks/useMediaPipe.js
// ─────────────────────────────────────────────
// Loads MediaPipe via CDN <script> tag
// NO npm import — @mediapipe/hands npm package
// does not expose Hands as an ES module constructor
// CDN version sets window.Hands correctly
// ─────────────────────────────────────────────

import { useRef, useState, useCallback, useEffect } from 'react'

// MediaPipe CDN — loads WASM + model files
const MP_SCRIPT_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js'
const MP_CDN        = 'https://cdn.jsdelivr.net/npm/@mediapipe/hands'

// ── Global singleton ──
let globalHands       = null
let globalLoadPromise = null
let globalNumHands    = 1

// ── Inject CDN script and wait for window.Hands ──
const injectScript = () => new Promise((resolve, reject) => {
  // Already available
  if (window.Hands) { resolve(); return }

  // Script already injected — wait for it
  if (document.getElementById('mp-hands-cdn')) {
    let attempts = 0
    const poll = setInterval(() => {
      attempts++
      if (window.Hands) {
        clearInterval(poll)
        resolve()
      } else if (attempts > 150) {
        clearInterval(poll)
        reject(new Error('Timed out waiting for MediaPipe'))
      }
    }, 100)
    return
  }

  // Inject fresh script tag
  const script    = document.createElement('script')
  script.id       = 'mp-hands-cdn'
  script.src      = MP_SCRIPT_URL
  script.async    = true

  script.onload = () => {
    // Brief delay for window.Hands to be set
    let attempts = 0
    const poll = setInterval(() => {
      attempts++
      if (window.Hands) {
        clearInterval(poll)
        resolve()
      } else if (attempts > 30) {
        clearInterval(poll)
        reject(new Error('window.Hands not found after script loaded'))
      }
    }, 100)
  }

  script.onerror = () =>
    reject(new Error('Failed to load MediaPipe from CDN'))

  document.head.appendChild(script)
})

// ── Initialize MediaPipe Hands instance ──
// numHands: 1 for one-handed alphabets (ASL), 2 for two-handed ones
// (ISL/BSL once trained — see src/config/languages.js). Reconfigures
// the existing singleton in place via setOptions() if it's already
// running with a different hand count, rather than reloading the
// whole WASM runtime.
const preloadMediaPipe = (numHands = 1) => {
  if (globalHands) {
    if (globalNumHands !== numHands) {
      globalHands.setOptions({ maxNumHands: numHands })
      globalNumHands = numHands
    }
    return Promise.resolve(globalHands)
  }
  if (globalLoadPromise) return globalLoadPromise

  globalLoadPromise = (async () => {
    try {
      console.log('⏳ Loading MediaPipe from CDN...')

      // Step 1: inject script → wait for window.Hands
      await injectScript()
      console.log('✅ Script loaded, window.Hands:', typeof window.Hands)

      // Step 2: create instance using window.Hands (NOT imported Hands)
      const hands = new window.Hands({
        locateFile: (file) => `${MP_CDN}/${file}`,
      })

      // Step 3: configure
      hands.setOptions({
        maxNumHands:            numHands,
        modelComplexity:        0,   // lite = faster
        minDetectionConfidence: 0.5,
        minTrackingConfidence:  0.3,
      })
      globalNumHands = numHands

      // Step 4: initialize (downloads WASM + model)
      await hands.initialize()

      globalHands = hands
      console.log('✅ MediaPipe Hands ready!')
      return hands

    } catch (err) {
      console.error('❌ MediaPipe failed:', err.message)
      globalLoadPromise = null  // reset so retry works
      return null
    }
  })()

  return globalLoadPromise
}

// Start preloading as soon as this module is imported
// (while user is still on HomeScreen)
preloadMediaPipe()

// ── Hook ──
// numHands: how many hands to track — 1 (default, ASL) or 2 (two-handed
// languages). When numHands > 1, onLandmarks receives the FULL
// multiHandLandmarks array instead of a single hand's 21 points, so
// callers must branch on this (see useSignModel's pipeline.build).
export function useMediaPipe({ onLandmarks, onNoHand, numHands = 1 }) {
  const frameRef     = useRef(null)
  const frameCount   = useRef(0)
  const isRunningRef = useRef(false)
  const numHandsRef  = useRef(numHands)
  useEffect(() => { numHandsRef.current = numHands }, [numHands])

  const [isLoaded,  setIsLoaded]  = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error,     setError]     = useState(null)

  // Keep callbacks in refs — no need to restart loop
  const onLandmarksRef = useRef(onLandmarks)
  const onNoHandRef    = useRef(onNoHand)
  useEffect(() => { onLandmarksRef.current = onLandmarks }, [onLandmarks])
  useEffect(() => { onNoHandRef.current    = onNoHand    }, [onNoHand])

  // ── loadMediaPipe ──
  const loadMediaPipe = useCallback(async () => {
    if (globalHands) {
      setIsLoaded(true)
      setIsLoading(false)
      return
    }

    setIsLoading(true)
    try {
      const hands = await preloadMediaPipe(numHandsRef.current)
      if (hands) {
        setIsLoaded(true)
      } else {
        setError('MediaPipe failed — check internet connection')
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Check if preload already finished on mount
  useEffect(() => {
    preloadMediaPipe(numHandsRef.current).then(hands => {
      if (hands) {
        setIsLoaded(true)
        setIsLoading(false)
      } else {
        setIsLoading(false)
      }
    })
  }, [])

  // ── Register result callback on globalHands ──
  const registerCallback = useCallback(() => {
    if (!globalHands) return
    globalHands.onResults((results) => {
      if (!isRunningRef.current) return
      if (results.multiHandLandmarks?.length > 0) {
        if (numHandsRef.current > 1) {
          onLandmarksRef.current?.(results.multiHandLandmarks)
        } else {
          onLandmarksRef.current?.(results.multiHandLandmarks[0])
        }
      } else {
        onNoHandRef.current?.()
      }
    })
  }, [])

  // ── startDetection ──
  const startDetection = useCallback(async (videoElement) => {
    if (!videoElement || isRunningRef.current) return

    if (!globalHands) {
      const hands = await preloadMediaPipe(numHandsRef.current)
      if (!hands) { setError('MediaPipe unavailable'); return }
    }

    registerCallback()
    isRunningRef.current = true
    frameCount.current   = 0

    const detect = async () => {
      if (!isRunningRef.current) return

      frameCount.current++

      // Every 2nd frame → ~15fps
      // Halves CPU usage, signs held long enough to catch
      if (frameCount.current % 2 === 0 &&
          videoElement.readyState >= 2 &&
          videoElement.videoWidth  > 0) {
        try {
          await globalHands.send({ image: videoElement })
        } catch (_) { /* ignore per-frame errors */ }
      }

      frameRef.current = requestAnimationFrame(detect)
    }

    detect()
    console.log('✅ Detection loop started')
  }, [registerCallback])

  // ── stopDetection ──
  const stopDetection = useCallback(() => {
    isRunningRef.current = false
    if (frameRef.current) {
      cancelAnimationFrame(frameRef.current)
      frameRef.current = null
    }
  }, [])

  // Cleanup on unmount — keep globalHands alive for reuse
  useEffect(() => () => stopDetection(), [stopDetection])

  return {
    isLoaded,
    isLoading,
    error,
    loadMediaPipe,
    startDetection,
    stopDetection,
  }
}