// src/hooks/useToast.js
// ─────────────────────────────────────────────
// Lightweight toast system — no external library
// Usage:
//   const toast = useToast()
//   toast.success('Message sent!')
//   toast.error('Camera denied')
//   toast.info('Signing started')
// ─────────────────────────────────────────────

import { useState, useCallback, useRef } from 'react'

let toastId = 0

export function useToast() {
  const [toasts, setToasts] = useState([])
  const timersRef = useRef({})

  const dismiss = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id))
    clearTimeout(timersRef.current[id])
    delete timersRef.current[id]
  }, [])

  const show = useCallback((message, type = 'info', duration = 3000) => {
    const id = ++toastId
    setToasts(prev => [...prev.slice(-3), { id, message, type }])
    // Auto dismiss
    timersRef.current[id] = setTimeout(() => dismiss(id), duration)
    return id
  }, [dismiss])

  const success = useCallback((msg, dur) => show(msg, 'success', dur), [show])
  const error   = useCallback((msg, dur) => show(msg, 'error',   dur ?? 4000), [show])
  const info    = useCallback((msg, dur) => show(msg, 'info',    dur), [show])
  const warning = useCallback((msg, dur) => show(msg, 'warning', dur), [show])

  return { toasts, show, success, error, info, warning, dismiss }
}