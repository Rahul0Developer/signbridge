// src/hooks/useCamera.js
// ─────────────────────────────────────────────
// Handles ONLY webcam access
// Returns: video ref, stream status, start/stop functions
// Used by: CameraFeed component
// ─────────────────────────────────────────────

import { useRef, useState, useCallback } from 'react'

export function useCamera() {
  const videoRef   = useRef(null)   // points to <video> element
  const streamRef  = useRef(null)   // holds the MediaStream object

  const [isActive,  setIsActive]  = useState(false)
  const [error,     setError]     = useState(null)
  const [isLoading, setIsLoading] = useState(false)

  // ── Start camera ──
  const startCamera = useCallback(async () => {
    setIsLoading(true)
    setError(null)

    try {
      // Request webcam access from browser
      // width/height: we want at least 640×480 for good detection
      // facingMode: 'user' = front camera (selfie mode)
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width:      { ideal: 640 },
          height:     { ideal: 480 },
          facingMode: 'user',
        },
        audio: false, // we don't need mic here
      })

      // Store stream reference so we can stop it later
      streamRef.current = stream

      // Connect stream to video element
      if (videoRef.current) {
        videoRef.current.srcObject = stream

        // Wait for video to be ready to play
        // 'loadeddata' fires when first frame is available
        await new Promise((resolve) => {
          videoRef.current.onloadeddata = resolve
        })

        await videoRef.current.play()
      }

      setIsActive(true)
    } catch (err) {
      // Common errors:
      // NotAllowedError  → user denied camera permission
      // NotFoundError    → no camera found on device
      // NotReadableError → camera in use by another app
      if (err.name === 'NotAllowedError') {
        setError('Camera permission denied. Please allow camera access.')
      } else if (err.name === 'NotFoundError') {
        setError('No camera found on this device.')
      } else {
        setError(`Camera error: ${err.message}`)
      }
    } finally {
      setIsLoading(false)
    }
  }, [])

  // ── Stop camera ──
  const stopCamera = useCallback(() => {
    // Stop all tracks (releases camera hardware)
    // Important: without this, camera light stays on
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    setIsActive(false)
  }, [])

  // ── Cleanup on unmount ──
  // If component unmounts while camera is on, stop it
  const cleanup = useCallback(() => {
    stopCamera()
  }, [stopCamera])

  return {
    videoRef,      // attach to <video ref={videoRef}>
    isActive,      // boolean: is camera running?
    isLoading,     // boolean: is camera starting?
    error,         // string: error message or null
    startCamera,   // function: call to start
    stopCamera,    // function: call to stop
    cleanup,       // function: call on unmount
  }
}