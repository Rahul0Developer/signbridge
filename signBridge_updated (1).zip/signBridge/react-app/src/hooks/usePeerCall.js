// src/hooks/usePeerCall.js
// ─────────────────────────────────────────────
// WebRTC via PeerJS
// Handles: video call + data channel (sign events)
// Architecture:
//   Host creates room → gets roomCode
//   Guest enters roomCode → connects to host
//   Both get: local video, remote video, data channel
// ─────────────────────────────────────────────

import { useRef, useState, useCallback, useEffect } from 'react'

// PeerJS cloud signaling server (free, no setup needed)
// Handles the initial handshake between peers
// After connection: video/data is peer-to-peer
const PEER_CONFIG = {
  host:   '0.peerjs.com',
  port:   443,
  secure: true,
  path:   '/',
  config: {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      // STUN servers help peers find each other
      // across NAT (home routers)
    ]
  }
}

// Generate readable room code: ABC-123 style
const generateRoomCode = () => {
  const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ'  // no I/O (confusing)
  const digits  = '23456789'                   // no 0/1 (confusing)
  const L = () => letters[Math.floor(Math.random() * letters.length)]
  const D = () => digits[Math.floor(Math.random() * digits.length)]
  return `${L()}${L()}${L()}-${D()}${D()}${D()}`
}

export function usePeerCall() {
  const peerRef       = useRef(null)  // Peer instance
  const connRef       = useRef(null)  // DataConnection (messages)
  const callRef       = useRef(null)  // MediaConnection (video)
  const localStreamRef = useRef(null) // our camera stream

  const remoteVideoRef = useRef(null) // <video> for remote feed
  const localVideoRef  = useRef(null) // <video> for local feed

  const [status,      setStatus]      = useState('idle')
  // idle | creating | waiting | connecting | connected | error | ended

  const [roomCode,    setRoomCode]    = useState(null)
  const [error,       setError]       = useState(null)
  const [remoteRole,  setRemoteRole]  = useState(null)
  // remoteRole: 'deaf' | 'hearing' (sent over data channel)

  // Message handlers stored in ref — updatable without reconnect
  const onRemoteSignRef    = useRef(null)  // remote sign detected
  const onRemoteMessageRef = useRef(null)  // remote text message

  const setOnRemoteSign    = useCallback((fn) => { onRemoteSignRef.current    = fn }, [])
  const setOnRemoteMessage = useCallback((fn) => { onRemoteMessageRef.current = fn }, [])

  // ── Get camera stream ──
  const getCameraStream = useCallback(async () => {
    if (localStreamRef.current) return localStreamRef.current

    const stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
      audio: true,
    })

    localStreamRef.current = stream

    // Show local video (mirrored)
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = stream
      await localVideoRef.current.play().catch(() => {})
    }

    return stream
  }, [])

  // ── Setup data connection ──
  // Data channel sends sign detections + messages as JSON
  const setupDataConn = useCallback((conn) => {
    connRef.current = conn

    conn.on('data', (raw) => {
      try {
        const msg = typeof raw === 'string' ? JSON.parse(raw) : raw

        if (msg.type === 'role') {
          setRemoteRole(msg.role)
        } else if (msg.type === 'sign') {
          onRemoteSignRef.current?.(msg)
          // msg = { type:'sign', letter, confidence, isValid, isNothing }
        } else if (msg.type === 'message') {
          onRemoteMessageRef.current?.(msg)
          // msg = { type:'message', text, role, timestamp }
        } else if (msg.type === 'word_update') {
          onRemoteSignRef.current?.(msg)
          // msg = { type:'word_update', currentWord, sentence }
        }
      } catch (e) {
        console.warn('Data channel parse error:', e)
      }
    })

    conn.on('close', () => {
      console.log('Data connection closed')
      setStatus('ended')
    })

    conn.on('error', (err) => {
      console.error('Data connection error:', err)
    })
  }, [])

  // ── Setup media call ──
  const setupCall = useCallback((call, stream) => {
    callRef.current = call

    call.on('stream', (remoteStream) => {
      console.log('✅ Remote stream received')
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStream
        remoteVideoRef.current.play().catch(() => {})
      }
      setStatus('connected')
    })

    call.on('close', () => {
      console.log('Call closed')
      setStatus('ended')
    })

    call.on('error', (err) => {
      console.error('Call error:', err)
      setError(`Call error: ${err.message}`)
      setStatus('error')
    })
  }, [])

  // ── Create room (HOST) ──
  // Generates a room code, waits for guest to connect
  const createRoom = useCallback(async (myRole) => {
    setStatus('creating')
    setError(null)

    try {
      const stream = await getCameraStream()
      const code   = generateRoomCode()

      // Load PeerJS dynamically
      const { Peer } = await import('peerjs')

      // Peer ID = room code (lowercased, no dash)
      // This is how guests find us
      const peerId = `signbridge-${code.replace('-', '').toLowerCase()}`
      const peer   = new Peer(peerId, PEER_CONFIG)
      peerRef.current = peer

      peer.on('open', (id) => {
        console.log('✅ Peer created:', id)
        setRoomCode(code)
        setStatus('waiting')
        // Now waiting for guest to call us
      })

      // Guest connects via data channel first
      peer.on('connection', (conn) => {
        console.log('✅ Guest data connection')
        setupDataConn(conn)

        // Send our role to guest
        conn.on('open', () => {
          conn.send(JSON.stringify({ type: 'role', role: myRole }))
        })
      })

      // Guest starts the video call
      peer.on('call', (call) => {
        console.log('✅ Incoming call from guest')
        call.answer(stream)
        setupCall(call, stream)
        setStatus('connecting')
      })

      peer.on('error', (err) => {
        console.error('Peer error:', err)
        setError(`Connection error: ${err.type}`)
        setStatus('error')
      })

    } catch (err) {
      setError(`Failed to create room: ${err.message}`)
      setStatus('error')
    }
  }, [getCameraStream, setupDataConn, setupCall])

  // ── Join room (GUEST) ──
  // Connects to host using room code
  const joinRoom = useCallback(async (code, myRole) => {
    setStatus('connecting')
    setError(null)

    try {
      const stream = await getCameraStream()
      const { Peer } = await import('peerjs')

      // Guest gets a random peer ID
      const peer     = new Peer(PEER_CONFIG)
      peerRef.current = peer

      // Host peer ID (derived from room code)
      const hostId = `signbridge-${code.replace('-', '').toLowerCase()}`

      peer.on('open', () => {
        console.log('✅ Peer open, connecting to host:', hostId)

        // Step 1: Open data channel to host
        const conn = peer.connect(hostId, { reliable: true })
        setupDataConn(conn)

        conn.on('open', () => {
          console.log('✅ Data channel open')
          // Send our role to host
          conn.send(JSON.stringify({ type: 'role', role: myRole }))

          // Step 2: Start video call to host
          const call = peer.call(hostId, stream)
          setupCall(call, stream)
        })

        conn.on('error', (err) => {
          setError(`Could not connect to room ${code}. Check the code and try again.`)
          setStatus('error')
        })
      })

      peer.on('error', (err) => {
        console.error('Guest peer error:', err)
        if (err.type === 'peer-unavailable') {
          setError(`Room ${code} not found. Check the code.`)
        } else {
          setError(`Connection error: ${err.type}`)
        }
        setStatus('error')
      })

    } catch (err) {
      setError(`Failed to join room: ${err.message}`)
      setStatus('error')
    }
  }, [getCameraStream, setupDataConn, setupCall])

  // ── Send sign detection to remote peer ──
  const sendSign = useCallback((signData) => {
    if (connRef.current?.open) {
      connRef.current.send(JSON.stringify({
        type: 'sign',
        ...signData,
      }))
    }
  }, [])

  // ── Send word update (live typing effect on remote) ──
  const sendWordUpdate = useCallback((currentWord, sentence) => {
    if (connRef.current?.open) {
      connRef.current.send(JSON.stringify({
        type: 'word_update',
        currentWord,
        sentence,
      }))
    }
  }, [])

  // ── Send text message ──
  const sendMessage = useCallback((text, role) => {
    if (connRef.current?.open) {
      connRef.current.send(JSON.stringify({
        type:      'message',
        text,
        role,
        timestamp: new Date().toLocaleTimeString([], {
          hour: '2-digit', minute: '2-digit'
        }),
      }))
    }
  }, [])

  // ── End call ──
  const endCall = useCallback(() => {
    callRef.current?.close()
    connRef.current?.close()

    // Stop camera tracks
    localStreamRef.current?.getTracks()
      .forEach(t => t.stop())

    peerRef.current?.destroy()

    callRef.current  = null
    connRef.current  = null
    peerRef.current  = null
    localStreamRef.current = null

    setStatus('ended')
    setRoomCode(null)
  }, [])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      callRef.current?.close()
      connRef.current?.close()
      localStreamRef.current?.getTracks().forEach(t => t.stop())
      peerRef.current?.destroy()
    }
  }, [])

  return {
    // Refs for video elements
    remoteVideoRef,
    localVideoRef,

    // State
    status,
    roomCode,
    error,
    remoteRole,

    // Actions
    createRoom,
    joinRoom,
    endCall,
    sendSign,
    sendWordUpdate,
    sendMessage,

    // Event handlers
    setOnRemoteSign,
    setOnRemoteMessage,
  }
}