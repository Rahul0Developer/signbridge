// src/hooks/useSignModel.js
// ─────────────────────────────────────────────
// Loads the trained TF.js model for the SELECTED LANGUAGE and runs
// inference. Takes hand landmarks → returns predicted letter.
// FORMAT: layers-model (fixed Keras v3 export)
// LOADER: tf.loadLayersModel()
// INFER:  model.predict()
//
// Multi-language: pass a languageId (see src/config/languages.js).
// Everything below is otherwise IDENTICAL in behavior to the
// original single-model (ASL-only) version — same thresholds, same
// stability buffer, same returned prediction shape — so existing
// screens don't need to change how they consume this hook, only
// which languageId they pass in.
// ─────────────────────────────────────────────

import { useRef, useState, useCallback, useEffect } from 'react'
import * as tf from '@tensorflow/tfjs'
import { getPipeline } from '../utils/normalize'
import { getLanguage, DEFAULT_LANGUAGE_ID } from '../config/languages'

// ── Constants ──
const CONFIDENCE_THRESHOLD = 0.80
// Only accept prediction if model is THIS confident
// Below 80% → treated as uncertain → ignored

const STABILITY_FRAMES = 8
// Require same prediction across 8 frames
// Prevents flickering between similar letters
// At 30fps → ~0.27 seconds of stability needed

export function useSignModel(languageId = DEFAULT_LANGUAGE_ID) {
  const modelRef    = useRef(null)  // TF.js loaded model
  const classNames   = useRef([])   // ['A','B',...,'Z','del','nothing','space']
  const predBuffer   = useRef([])   // rolling buffer of last N frame predictions
  const loadedLangRef = useRef(null) // which language is currently loaded in modelRef
  const pipelineRef  = useRef(getPipeline('single-hand-78'))

  const [isLoaded,   setIsLoaded]   = useState(false)
  const [isLoading,  setIsLoading]  = useState(false)
  const [error,      setError]      = useState(null)
  const [prediction, setPrediction] = useState(null)
  // prediction shape:
  // { letter, confidence, isStable, isNothing, isSpace, isDel, isValid, allProbs }

  // ─────────────────────────────────────────
  // LOAD MODEL
  // Re-runs automatically if languageId changes (e.g. user switches
  // language in the picker) — disposes the old model first so we
  // don't leak GPU/CPU memory when swapping languages mid-session.
  // ─────────────────────────────────────────
  const loadModel = useCallback(async (overrideLanguageId) => {
    const targetLangId = overrideLanguageId || languageId
    const lang = getLanguage(targetLangId)

    if (modelRef.current && loadedLangRef.current === lang.id) return  // already loaded this language

    if (lang.status !== 'available') {
      setError(`${lang.name} isn't available yet — no trained model. Check ${lang.modelDir}/PLACEHOLDER.md`)
      setIsLoaded(false)
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      // Dispose any previously loaded model before loading the new one
      if (modelRef.current) {
        modelRef.current.dispose()
        modelRef.current = null
        setIsLoaded(false)
      }

      // ── Step 1: Load label encoder ──
      // Maps output neuron index → class name
      // e.g. index 0 = 'A', index 26 = 'del', index 27 = 'nothing', index 28 = 'space'
      const encoderRes  = await fetch(`${lang.modelDir}/label_encoder.json`)
      if (!encoderRes.ok) throw new Error(`label_encoder.json not found in ${lang.modelDir}/`)
      const encoderData = await encoderRes.json()
      classNames.current = encoderData.classes

      console.log(`✅ [${lang.shortName}] Label encoder loaded`)
      console.log('   Classes:', classNames.current.length, classNames.current)

      // ── Step 2: Load layers model ──
      // We use loadLayersModel because:
      //   - Model was exported with save_keras_model (layers format)
      //   - model.json has modelTopology with layer configs
      //   - batch_input_shape is now fixed (batch_shape → batch_input_shape)
      const model = await tf.loadLayersModel(`${lang.modelDir}/model.json`)

      console.log(`✅ [${lang.shortName}] Layers model loaded successfully`)
      console.log('   Input shape:', model.inputs[0].shape)
      console.log('   Output shape:', model.outputs[0].shape)

      modelRef.current    = model
      loadedLangRef.current = lang.id
      pipelineRef.current  = getPipeline(lang.pipeline)

      // ── Step 3: Warmup prediction ──
      // TF.js compiles the model on first inference (slow ~500ms)
      // Running a fake prediction now means real first prediction is instant
      const numFeatures = pipelineRef.current.numFeatures
      const warmup    = tf.zeros([1, numFeatures])
      const warmupOut = model.predict(warmup)

      // Always dispose tensors you don't need — prevents memory leak
      if (Array.isArray(warmupOut)) {
        warmupOut.forEach(t => t.dispose())
      } else {
        warmupOut.dispose()
      }
      warmup.dispose()

      console.log(`✅ [${lang.shortName}] Warmup complete — model is ready`)
      predBuffer.current = []
      setPrediction(null)
      setIsLoaded(true)

    } catch (err) {
      const msg = `Model failed to load: ${err.message}`
      setError(msg)
      console.error('❌ Model load error:', err)
    } finally {
      setIsLoading(false)
    }
  }, [languageId])

  // Auto (re)load whenever the requested language changes
  useEffect(() => {
    loadModel(languageId)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [languageId])

  // Dispose model on unmount
  useEffect(() => () => {
    if (modelRef.current) {
      modelRef.current.dispose()
      modelRef.current = null
    }
  }, [])

  // ─────────────────────────────────────────
  // PREDICT
  // Called every frame (~30fps) with landmarks.
  // For single-hand languages: pass the 21-point landmark array.
  // For two-hand languages: pass [hand0Landmarks, hand1Landmarks].
  // Returns prediction object or null
  // ─────────────────────────────────────────
  const predict = useCallback((landmarks) => {
    if (!modelRef.current || !landmarks) return null

    // tf.tidy() automatically disposes all tensors created inside
    // CRITICAL at 30fps — without this, memory fills up in minutes
    return tf.tidy(() => {

      // ── Step 1+2: Build the feature vector for this language's pipeline ──
      // Must be IDENTICAL to whatever preprocessing the model was trained with.
      const pipeline = pipelineRef.current
      const features = pipeline.build(landmarks)

      // ── Step 3: Create input tensor ──
      const inputTensor = tf.tensor2d([Array.from(features)])

      // ── Step 4: Run inference ──
      // layers model uses .predict() (not .execute())
      const outputRaw = modelRef.current.predict(inputTensor)

      // predict() returns single tensor for sequential/functional models
      // but can return array for multi-output models — handle both
      const outputTensor = Array.isArray(outputRaw) ? outputRaw[0] : outputRaw

      // Convert tensor to plain JavaScript array
      // Float32Array: N values, each 0.0-1.0, all sum to 1.0 (softmax)
      const probabilities = outputTensor.dataSync()

      // ── Step 5: Find winning class ──
      let maxProb  = 0
      let maxIndex = 0
      for (let i = 0; i < probabilities.length; i++) {
        if (probabilities[i] > maxProb) {
          maxProb  = probabilities[i]
          maxIndex = i
        }
      }

      const letter     = classNames.current[maxIndex] || 'unknown'
      const confidence = maxProb

      // ── Step 6: Stability buffer ──
      // Add this frame's prediction to rolling buffer
      predBuffer.current.push(maxIndex)
      if (predBuffer.current.length > STABILITY_FRAMES) {
        predBuffer.current.shift()  // remove oldest frame
      }

      // Count consecutive agreements on same prediction
      const agreementCount = predBuffer.current
        .filter(p => p === maxIndex).length

      // ── Step 7: Build result object ──
      const result = {
        letter,
        confidence,

        // isStable: 75% of recent frames predict same letter
        // Prevents false triggers on brief hand movements
        isStable: agreementCount >= STABILITY_FRAMES * 0.75,

        // isNothing: model sees no clear sign
        // Used to detect pauses between letters
        isNothing: letter === 'nothing',

        // isSpace: user showed space sign
        // Triggers word boundary in WordBuilder
        isSpace: letter === 'space',

        // isDel: user showed delete sign
        // Triggers delete last character
        isDel: letter === 'del',

        // isValid: confident enough + is a real letter
        // Only isValid=true letters get added to words
        // Excludes: nothing (pause), del (action), space (handled separately)
        isValid: confidence >= CONFIDENCE_THRESHOLD &&
                 letter !== 'nothing' &&
                 letter !== 'del',

        // allProbs: sorted probabilities for all classes
        // Useful for: debugging, showing top-3, confidence UI
        allProbs: Array.from(probabilities)
          .map((p, i) => ({
            letter: classNames.current[i] || `class_${i}`,
            prob:   p,
          }))
          .sort((a, b) => b.prob - a.prob),
      }

      // ── Step 8: Update React state ──
      // Only update when at least 2 frames agree
      // Prevents re-rendering on every single frame (~30/sec)
      if (agreementCount >= 2) {
        setPrediction(result)
      }

      return result
    })
  }, [])

  // ─────────────────────────────────────────
  // RESET BUFFER
  // Call this when user pauses between signs
  // Clears old predictions so new sign starts fresh
  // ─────────────────────────────────────────
  const resetBuffer = useCallback(() => {
    predBuffer.current = []
    setPrediction(null)
  }, [])

  // ─────────────────────────────────────────
  // CLEAR PREDICTION
  // Resets both buffer and displayed prediction
  // ─────────────────────────────────────────
  const clearPrediction = useCallback(() => {
    predBuffer.current = []
    setPrediction(null)
  }, [])

  return {
    // ── State ──
    isLoaded,    // boolean: model ready to use
    isLoading,   // boolean: model currently loading
    error,       // string | null: error message

    // ── Current prediction ──
    prediction,  // object | null: latest stable prediction

    // ── Actions ──
    loadModel,       // call once on mount (or with an id to force-switch) to load model
    predict,         // call every frame with landmarks
    resetBuffer,     // call when user pauses
    clearPrediction, // call to reset displayed prediction

    // ── Info ──
    classNames: classNames.current,
    languageId: loadedLangRef.current,
    numHands:   pipelineRef.current.numHands,
  }
}
