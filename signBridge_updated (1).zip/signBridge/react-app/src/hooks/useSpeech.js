// src/hooks/useSpeech.js
// ─────────────────────────────────────────────
// Text-to-Speech: speak detected signs aloud
// Speech-to-Text: transcribe hearing person's voice
// Uses browser's built-in Web Speech API
// No API key needed — works in Chrome
// ─────────────────────────────────────────────

import { useRef, useState, useCallback, useEffect } from 'react'

export function useSpeech() {
  const recognitionRef = useRef(null)
  const synthRef       = useRef(window.speechSynthesis)

  const [isListening,  setIsListening]  = useState(false)
  const [isSpeaking,   setIsSpeaking]   = useState(false)
  const [transcript,   setTranscript]   = useState('')
  const [interim,      setInterim]      = useState('')
  const [voices,       setVoices]       = useState([])
  const [supported,    setSupported]    = useState({
    tts: 'speechSynthesis' in window,
    stt: 'SpeechRecognition' in window ||
         'webkitSpeechRecognition' in window,
  })

  // ── Load available voices ──
  useEffect(() => {
    const loadVoices = () => {
      const v = window.speechSynthesis?.getVoices() || []
      setVoices(v)
    }
    loadVoices()
    window.speechSynthesis?.addEventListener('voiceschanged', loadVoices)
    return () => {
      window.speechSynthesis?.removeEventListener('voiceschanged', loadVoices)
    }
  }, [])

  // ── Text to Speech ──
  // Speaks text aloud — used when deaf person sends a sign message
  const speak = useCallback((text, options = {}) => {
    if (!supported.tts || !text.trim()) return

    // Cancel any ongoing speech first
    synthRef.current.cancel()

    const utterance = new SpeechSynthesisUtterance(text)

    // Find a good English voice
    const englishVoice = voices.find(v =>
      v.lang.startsWith('en') && v.localService
    ) || voices.find(v => v.lang.startsWith('en'))

    if (englishVoice) utterance.voice = englishVoice

    utterance.rate   = options.rate   || 0.95  // slightly slower = clearer
    utterance.pitch  = options.pitch  || 1.0
    utterance.volume = options.volume || 1.0

    utterance.onstart = () => setIsSpeaking(true)
    utterance.onend   = () => setIsSpeaking(false)
    utterance.onerror = () => setIsSpeaking(false)

    synthRef.current.speak(utterance)
  }, [supported.tts, voices])

  // ── Stop speaking ──
  const stopSpeaking = useCallback(() => {
    synthRef.current?.cancel()
    setIsSpeaking(false)
  }, [])

  // ── Start Speech to Text ──
  const startListening = useCallback((onResult) => {
    if (!supported.stt) return

    const SR = window.SpeechRecognition ||
               window.webkitSpeechRecognition
    const recognition = new SR()

    recognition.continuous      = true
    // continuous = keep listening until stopped
    // not just one utterance

    recognition.interimResults  = true
    // Show words as user speaks (before sentence complete)
    // Makes UI feel responsive

    recognition.lang            = 'en-US'

    recognition.onresult = (event) => {
      let finalText   = ''
      let interimText = ''

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const text = event.results[i][0].transcript
        if (event.results[i].isFinal) {
          finalText += text
        } else {
          interimText += text
        }
      }

      if (finalText) {
        setTranscript(prev => {
          const updated = (prev + ' ' + finalText).trim()
          onResult?.(updated)
          return updated
        })
      }

      setInterim(interimText)
    }

    recognition.onerror = (e) => {
      if (e.error !== 'no-speech') {
        console.error('Speech error:', e.error)
      }
      setIsListening(false)
    }

    recognition.onend = () => {
      setIsListening(false)
      setInterim('')
    }

    recognitionRef.current = recognition
    recognition.start()
    setIsListening(true)
  }, [supported.stt])

  // ── Stop listening ──
  const stopListening = useCallback(() => {
    recognitionRef.current?.stop()
    setIsListening(false)
    setInterim('')
  }, [])

  // ── Clear transcript ──
  const clearTranscript = useCallback(() => {
    setTranscript('')
    setInterim('')
  }, [])

  // ── Cleanup ──
  useEffect(() => {
    return () => {
      recognitionRef.current?.stop()
      synthRef.current?.cancel()
    }
  }, [])

  return {
    // TTS
    speak,
    stopSpeaking,
    isSpeaking,
    voices,

    // STT
    startListening,
    stopListening,
    isListening,
    transcript,
    interim,
    clearTranscript,

    // Info
    supported,
  }
}