// src/hooks/useKeyboardShortcuts.js
// ─────────────────────────────────────────────
// Global keyboard shortcuts
// Space     → toggle signing (deaf) / toggle listening (hearing)
// Enter     → send message
// Escape    → stop signing / stop listening
// Backspace → delete last char (when signing)
// ?         → show shortcuts help
// ─────────────────────────────────────────────

import { useEffect, useCallback } from 'react'

export function useKeyboardShortcuts({
  role,
  isSigning,
  isListening,
  onToggleSigning,
  onToggleListening,
  onSend,
  onDeleteChar,
  onShowHelp,
  enabled = true,
}) {
  const handleKey = useCallback((e) => {
    if (!enabled) return

    // Don't fire when user is typing in an input
    const tag = e.target?.tagName?.toLowerCase()
    if (tag === 'input' || tag === 'textarea') return

    switch (e.key) {
      case ' ':
        e.preventDefault()
        if (role === 'deaf')    onToggleSigning?.()
        if (role === 'hearing') onToggleListening?.()
        break

      case 'Enter':
        e.preventDefault()
        onSend?.()
        break

      case 'Escape':
        e.preventDefault()
        if (isSigning)    onToggleSigning?.()
        if (isListening)  onToggleListening?.()
        break

      case 'Backspace':
        if (isSigning) {
          e.preventDefault()
          onDeleteChar?.()
        }
        break

      case '?':
        onShowHelp?.()
        break

      default:
        break
    }
  }, [enabled, role, isSigning, isListening,
      onToggleSigning, onToggleListening,
      onSend, onDeleteChar, onShowHelp])

  useEffect(() => {
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [handleKey])
}

// Shortcuts help overlay component
export function ShortcutsHelp({ role, onClose }) {
  const shortcuts = role === 'deaf'
    ? [
        { key: 'Space',     action: 'Start / Stop signing'    },
        { key: 'Enter',     action: 'Send message'            },
        { key: 'Esc',       action: 'Stop signing'            },
        { key: 'Backspace', action: 'Delete last character'   },
        { key: '?',         action: 'Show this help'          },
      ]
    : [
        { key: 'Space',     action: 'Start / Stop listening'  },
        { key: 'Enter',     action: 'Send message'            },
        { key: 'Esc',       action: 'Stop listening'          },
        { key: '?',         action: 'Show this help'          },
      ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center
                    bg-black/60 backdrop-blur-sm"
         onClick={onClose}>
      <div className="bg-surface-secondary border border-surface-border
                      rounded-2xl p-6 max-w-sm w-full mx-4 space-y-4"
           onClick={e => e.stopPropagation()}>

        <div className="flex items-center justify-between">
          <h2 className="text-[#F2F2F7] font-bold text-base">
            Keyboard Shortcuts
          </h2>
          <button onClick={onClose}
                  className="text-[#636366] hover:text-[#F2F2F7] transition-colors">
            ✕
          </button>
        </div>

        <div className="space-y-2">
          {shortcuts.map(({ key, action }) => (
            <div key={key} className="flex items-center justify-between
                                      py-2 border-b border-surface-border
                                      last:border-0">
              <span className="text-[#636366] text-sm">{action}</span>
              <kbd className="px-2.5 py-1 rounded-lg bg-surface-tertiary
                              border border-surface-border
                              text-[#F2F2F7] text-xs font-mono">
                {key}
              </kbd>
            </div>
          ))}
        </div>

        <p className="text-[#636366] text-xs text-center">
          Press <kbd className="px-1.5 py-0.5 rounded bg-surface-tertiary
                                border border-surface-border text-xs font-mono">?</kbd> anytime to show this
        </p>
      </div>
    </div>
  )
}