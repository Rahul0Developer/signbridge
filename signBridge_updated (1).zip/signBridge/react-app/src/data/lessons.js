// src/data/lessons.js
// ─────────────────────────────────────────────
// Duolingo-style lesson content. Each language gets its own list of
// bite-sized units — a unit is a handful of signs practiced together.
// PracticeScreen reads this to build the lesson map + quiz flow.
//
// Only ASL has real content because it's the only language with a
// working model right now (see src/config/languages.js). Adding a
// unit here for another language is purely content — it does not by
// itself make that language practiceable; the model has to exist too.
// ─────────────────────────────────────────────

export const LESSONS = {
  asl: [
    { id: 'asl-u1', title: 'First Signs',   letters: ['A', 'B', 'C', 'D', 'E'] },
    { id: 'asl-u2', title: 'Getting Going', letters: ['F', 'G', 'H', 'I', 'J'] },
    { id: 'asl-u3', title: 'Halfway There', letters: ['K', 'L', 'M', 'N', 'O'] },
    { id: 'asl-u4', title: 'Keep Moving',   letters: ['P', 'Q', 'R', 'S', 'T'] },
    { id: 'asl-u5', title: 'Almost Done',   letters: ['U', 'V', 'W', 'X', 'Y'] },
    { id: 'asl-u6', title: 'Final Stretch', letters: ['Z', 'space', 'del'] },
  ],
  isl: [],
  bsl: [],
}

export function getLessons(languageId) {
  return LESSONS[languageId] || []
}

// XP + streak are simple, local, per-language progress —
// no backend needed for a first version.
const STORAGE_PREFIX = 'sb-progress-'

export function loadProgress(languageId) {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + languageId)
    if (!raw) return { completedUnits: [], xp: 0, streak: 0, lastPracticedDate: null }
    return JSON.parse(raw)
  } catch {
    return { completedUnits: [], xp: 0, streak: 0, lastPracticedDate: null }
  }
}

export function saveProgress(languageId, progress) {
  localStorage.setItem(STORAGE_PREFIX + languageId, JSON.stringify(progress))
}

// Called when a unit is finished — awards XP, updates streak, unlocks next unit.
export function completeUnit(languageId, unitId, xpEarned) {
  const progress = loadProgress(languageId)
  const today = new Date().toDateString()

  if (!progress.completedUnits.includes(unitId)) {
    progress.completedUnits = [...progress.completedUnits, unitId]
  }
  progress.xp = (progress.xp || 0) + xpEarned

  if (progress.lastPracticedDate !== today) {
    const yesterday = new Date(Date.now() - 86400000).toDateString()
    progress.streak = progress.lastPracticedDate === yesterday ? (progress.streak || 0) + 1 : 1
    progress.lastPracticedDate = today
  }

  saveProgress(languageId, progress)
  return progress
}
