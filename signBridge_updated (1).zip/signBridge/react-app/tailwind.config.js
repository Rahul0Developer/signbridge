// tailwind.config.js
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      // Our custom color system
      // Designed specifically for accessibility
      colors: {
        // Primary brand blue — calm, trusted
        brand: {
          50:  '#eff6ff',
          100: '#dbeafe',
          500: '#0A84FF',
          600: '#0066CC',
          700: '#004499',
        },
        // Deaf user side — blue tint
        deaf: {
          bg:     '#0A84FF',
          light:  '#1a1f2e',
          border: '#0A84FF44',
          text:   '#60a5fa',
        },
        // Hearing user side — green tint
        hearing: {
          bg:     '#30D158',
          light:  '#1a2e1f',
          border: '#30D15844',
          text:   '#4ade80',
        },
        // App surfaces — dark mode like WhatsApp
        surface: {
          primary:   '#0a0a0f',  // main background
          secondary: '#1C1C1E',  // cards, panels
          tertiary:  '#2C2C2E',  // input fields
          border:    '#38383A',  // dividers
        },
      },
      // Custom fonts for clean readable UI
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      // Animation for sign detection feedback
      animation: {
        'pulse-slow':   'pulse 2s cubic-bezier(0.4,0,0.6,1) infinite',
        'bounce-subtle':'bounce 1s ease-in-out 3',
        'fade-in':      'fadeIn 0.3s ease-in-out',
        'slide-up':     'slideUp 0.3s ease-out',
        'sign-pop':     'signPop 0.4s cubic-bezier(0.34,1.56,0.64,1)',
      },
      keyframes: {
        fadeIn: {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%':   { transform: 'translateY(12px)', opacity: '0' },
          '100%': { transform: 'translateY(0)',    opacity: '1' },
        },
        signPop: {
          '0%':   { transform: 'scale(0.5) rotate(-8deg)', opacity: '0' },
          '60%':  { transform: 'scale(1.1) rotate(2deg)' },
          '100%': { transform: 'scale(1) rotate(0deg)',   opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}